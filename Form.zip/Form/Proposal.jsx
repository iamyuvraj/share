import React from "react";
import { motion } from "framer-motion"; // ✅ Required for animation

const Input = ({ label, placeholder, type = "text", required = false }) => (
  <div>
    {label && (
      <label className="block text-sm font-medium mb-1 text-yellow-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
    )}
    <input
      type={type}
      placeholder={placeholder}
      required={required}
      className="w-full p-2 border border-yellow-400 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600 bg-white"
    />
  </div>
);
const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const Proposal = () => {
  return (
    <motion.div
      className=" flex justify-center py-10"
      variants={boxVariants}
    initial="hidden"
    animate="visible"
    transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-6xl space-y-6">
        <form
          className="bg-white p-8"
          onSubmit={(e) => e.preventDefault()}
        >
          <h2 className="text-3xl font-bold text-yellow-800 mb-8 text-center border-b-2 border-yellow-700 pb-2">
            Proposal Summary
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-4">
              <Input label="Current TRL" required />
              <Input label="Abstract of the Proposal" />
              <Input label="End to End Solution" />
              <Input label="Technical Feasibility" />
              <Input label="Commercialisation Strategy" />

              <div>
                <label className="block text-sm font-medium mb-1 text-yellow-800">
                  Are there any alternate competitive technologies/products available? <span className="text-red-600">*</span>
                </label>
                <select
                  required
                  className="w-full p-2 border border-yellow-400 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600 bg-white"
                >
                  <option value="">Select an option</option>
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
                </select>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              <Input label="Expected URL" />
              <Input label="Novelty of Proposal" />
              <Input label="Potential Impact" />
              <Input label="Cyber Security (Write NA if none)" required />
              <Input label="Mention Detail of Support Required" required />
            </div>
          </div>
        </form>
      </div>
    </motion.div>
  );
};
export default Proposal;
