import React, { useState, useEffect, useCallback } from "react";
import { Plus, Trash2, Copy } from "lucide-react";

const IPRDetails = ({ initialFormData = {}, onFormDataChange }) => {
  
  const [forms, setForms] = useState(() => {
    // If initialFormData exists and is valid, use it; otherwise use defaults
    if (initialFormData && Array.isArray(initialFormData) && initialFormData.length > 0) {
      return initialFormData.map(form => ({
        ...form,
        
        essenceOfProposal: {
          nationalImportance: "",
          commercializationPotential: "",
          riskFactors: "",
          preliminaryWorkDone: "",
          technologyStatus: "",
          businessStrategy: "",
          ...form.essenceOfProposal, // Override with actual data
        },
        ipRegulatoryDetails: {
          basedOnIPR: "",
          ipOwnershipDetails: "",
          ipProposal: "",
          regulatoryApprovals: "",
          statusApprovals: "",
          proofOfStatus: null,
          proofOfStatusPreview: null,
          ...form.ipRegulatoryDetails, // Override with actual data
        },
        telecomServiceProvider: {
          name: "",
          designation: "",
          mobileNumber: "",
          email: "",
          address: "",
          supportLetter: null,
          supportLetterPreview: null,
          ...form.telecomServiceProvider, // Override with actual data
        },
      }));
    }
    
    // Default single form
    return [
      {
        id: 1,
        essenceOfProposal: {
          nationalImportance: "",
          commercializationPotential: "",
          riskFactors: "",
          preliminaryWorkDone: "",
          technologyStatus: "",
          businessStrategy: "",
        },
        ipRegulatoryDetails: {
          basedOnIPR: "",
          ipOwnershipDetails: "",
          ipProposal: "",
          regulatoryApprovals: "",
          statusApprovals: "",
          proofOfStatus: null,
          proofOfStatusPreview: null,
        },
        telecomServiceProvider: {
          name: "",
          designation: "",
          mobileNumber: "",
          email: "",
          address: "",
          supportLetter: null,
          supportLetterPreview: null,
        },
      },
    ];
  });

  // 🔧 ENHANCED: Add effect to handle prop changes without losing data
  useEffect(() => {
    if (initialFormData && Array.isArray(initialFormData) && initialFormData.length > 0) {
      console.log("🔍 IPRDetails received new initialFormData:", initialFormData);
      
      setForms(prevForms => {
        // Merge new data with existing data to prevent loss
        const mergedForms = initialFormData.map((newForm, index) => {
          const existingForm = prevForms[index];
          
          if (existingForm) {
            // Merge existing form data with new data, preserving any local changes
            return {
              ...newForm,
              essenceOfProposal: {
                ...newForm.essenceOfProposal,
                // Preserve any local file uploads
                ...(existingForm.essenceOfProposal || {}),
              },
              ipRegulatoryDetails: {
                ...newForm.ipRegulatoryDetails,
                // Preserve any local file uploads
                proofOfStatus: existingForm.ipRegulatoryDetails?.proofOfStatus || newForm.ipRegulatoryDetails?.proofOfStatus || null,
                proofOfStatusPreview: existingForm.ipRegulatoryDetails?.proofOfStatusPreview || newForm.ipRegulatoryDetails?.proofOfStatusPreview || null,
              },
              telecomServiceProvider: {
                ...newForm.telecomServiceProvider,
                // Preserve any local file uploads
                supportLetter: existingForm.telecomServiceProvider?.supportLetter || newForm.telecomServiceProvider?.supportLetter || null,
                supportLetterPreview: existingForm.telecomServiceProvider?.supportLetterPreview || newForm.telecomServiceProvider?.supportLetterPreview || null,
              },
            };
          }
          
          return newForm;
        });
        
        console.log("🔍 IPRDetails merged forms:", mergedForms);
        return mergedForms;
      });
    }
  }, [initialFormData]);

  // 🔧 FIX: Use useCallback to prevent onFormDataChange from changing on every render
  const notifyParent = useCallback(() => {
    console.log("🔍 IPRDetails notifying parent with forms:", forms);
    onFormDataChange(forms);
  }, [forms, onFormDataChange]);

  // 🔧 FIX: Only update parent when forms actually change, with proper dependency
  useEffect(() => {
    notifyParent();
  }, [notifyParent]);

  // 🔧 ENHANCED: Better state management to prevent data loss
  const handleInputChange = (formId, section, field, value) => {
    console.log(`🔍 IPRDetails input change: Form ${formId} -> ${section}.${field} = "${value}"`);
    
    // Special logging for file fields
    if (field === 'supportLetter' && value instanceof File) {
      console.log(`📎 Support Letter file selected:`, {
        name: value.name,
        size: value.size,
        type: value.type,
        _iprIndex: value._iprIndex
      });
    }
    
    if (field === 'proofOfStatus' && value instanceof File) {
      console.log(`📎 Proof of Status file selected:`, {
        name: value.name,
        size: value.size,
        type: value.type,
        _iprIndex: value._iprIndex
      });
    }
    
    setForms((prev) => {
      const newForms = prev.map((form) => {
        if (form.id === formId) {
          // 🔧 CRITICAL: Preserve all existing section data
          const updatedForm = {
            ...form,
            [section]: {
              ...form[section], // Keep all existing fields in this section
              [field]: value,   // Only update the specific field
            },
          };
          
          console.log(`🔍 Updated form ${formId} section ${section}:`, updatedForm[section]);
          return updatedForm;
        }
        return form; // Return unchanged form for other forms
      });
      
      console.log("🔍 IPRDetails complete new forms state:", newForms);
      return newForms;
    });
  };

  const addNewForm = () => {
    const newId =
      forms.length > 0 ? Math.max(...forms.map((f) => f.id)) + 1 : 1;
    const newForm = {
      id: newId,
      essenceOfProposal: {
        nationalImportance: "",
        commercializationPotential: "",
        riskFactors: "",
        preliminaryWorkDone: "",
        technologyStatus: "",
        businessStrategy: "",
      },
      ipRegulatoryDetails: {
        basedOnIPR: "",
        ipOwnershipDetails: "",
        ipProposal: "",
        regulatoryApprovals: "",
        statusApprovals: "",
        proofOfStatus: null,
        proofOfStatusPreview: null,
      },
      telecomServiceProvider: {
        name: "",
        designation: "",
        mobileNumber: "",
        email: "",
        address: "",
        supportLetter: null,
        supportLetterPreview: null,
      },
    };
    setForms((prev) => [...prev, newForm]);
  };

  const duplicateForm = (formId) => {
    const formToDuplicate = forms.find((f) => f.id === formId);
    const newId =
      forms.length > 0 ? Math.max(...forms.map((f) => f.id)) + 1 : 1;
    const duplicatedForm = {
      ...JSON.parse(JSON.stringify(formToDuplicate)), // Deep clone
      id: newId,
      // 🔧 CRITICAL: Reset file objects in duplicated form since files can't be cloned
      ipRegulatoryDetails: {
        ...formToDuplicate.ipRegulatoryDetails,
        proofOfStatus: null,
        proofOfStatusPreview: null,
      },
      telecomServiceProvider: {
        ...formToDuplicate.telecomServiceProvider,
        supportLetter: null,
        supportLetterPreview: null,
      },
    };
    setForms((prev) => [...prev, duplicatedForm]);
  };

  const removeForm = (formId) => {
    if (forms.length > 1) {
      setForms((prev) => prev.filter((form) => form.id !== formId));
    }
  };

  const sections = [
    {
      id: "essenceOfProposal",
      title: "Essence of the Proposal",
      number: "1",
      fields: [
        {
          key: "nationalImportance",
          label: "National Importance/Social Relevance",
          type: "textarea",
          required: false,
        },
        {
          key: "commercializationPotential",
          label: "Commercialization Potential",
          type: "textarea",
          required: false,
        },
        {
          key: "riskFactors",
          label: "Risk Factors",
          type: "textarea",
          required: false,
        },
        {
          key: "preliminaryWorkDone",
          label: "Preliminary Work Done So Far",
          type: "textarea",
          required: false,
        },
        {
          key: "technologyStatus",
          label:
            "National and International Status of Proposed Technology or Product",
          type: "textarea",
          required: false,
        },
        {
          key: "businessStrategy",
          label: "Business Strategy",
          type: "textarea",
          required: false,
        },
      ],
    },
    {
      id: "ipRegulatoryDetails",
      title: "IP & Regulatory Details",
      number: "2",
      fields: [
        {
          key: "basedOnIPR",
          label:
            "Intellectual Property rights owned by the Applicant/Collaborator/Licensed From Abroad",
          type: "select",
          options: ["Yes", "No"],
          required: false,
        },
        {
          key: "ipOwnershipDetails",
          label: "IP Ownership Details",
          type: "textarea",
          required: false,
        },
        {
          key: "ipProposal",
          label: "IP Proposal",
          type: "textarea",
          required: false,
        },
        {
          key: "regulatoryApprovals",
          label: "In case the Technology is Licensed Regulatory Approvals",
          type: "textarea",
        },
        {
          key: "statusApprovals",
          label: "In case the Technology is Licensed Status Approvals",
          type: "textarea",
        },
        {
          key: "proofOfStatus",
          label: "In case the Technology is Licensed Proof of Status",
          type: "file",
        },
      ],
    },
    {
      id: "telecomServiceProvider",
      title: "Telecom Service Provider",
      number: "3",
      fields: [
        {
          key: "name",
          label: "Name",
          type: "text",
          required: false,
        },
        {
          key: "designation",
          label: "Designation",
          type: "text",
          required: false,
        },
        {
          key: "mobileNumber",
          label: "Mobile Number",
          type: "tel",
          required: false,
        },
        {
          key: "email",
          label: "Email",
          type: "email",
          required: false,
        },
        {
          key: "address",
          label: "Address",
          type: "textarea",
          required: false,
        },
        {
          key: "supportLetter",
          label: "Letter for Support",
          type: "file",
          required: false,
        },
      ],
    },
  ];

  const renderField = (form, section, field, formIndex) => {
    const value = form[section.id][field.key];
    const commonClasses =
      "w-full px-3 py-2 border-2 border-yellow-300 rounded-lg focus:border-yellow-400 focus:outline-none focus:ring-1 focus:ring-yellow-100 transition-all duration-300 text-sm";

    switch (field.type) {
      case "textarea":
        return (
          <textarea
            className={`${commonClasses} min-h-[80px] resize-y`}
            value={value}
            onChange={(e) =>
              handleInputChange(form.id, section.id, field.key, e.target.value)
            }
            placeholder={`Enter ${field.label.toLowerCase()}...`}
            required={field.required}
          />
        );
      case "select":
        return (
          <select
            className={commonClasses}
            value={value}
            onChange={(e) =>
              handleInputChange(form.id, section.id, field.key, e.target.value)
            }
            required={field.required}
          >
            <option value="">Select an option</option>
            {field.options?.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        );
      case "file":
        return (
          <div className="relative">
            <input
              type="file"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  // 🔧 CRITICAL FIX: Store the file with index information AND clear preview
                  console.log(`📎 File selected for ${field.key}:`, file.name, `Index: ${formIndex}`);
                  
                  // Create a file object with index information
                  const fileWithIndex = Object.assign(file, { _iprIndex: formIndex });
                  
                  // Update the file field
                  handleInputChange(form.id, section.id, field.key, fileWithIndex);
                  
                  // Also clear any existing preview to ensure the new file takes precedence
                  const previewKey = field.key + 'Preview';
                  handleInputChange(form.id, section.id, previewKey, null);
                  
                  console.log(`✅ File ${field.key} updated for form ${form.id}, index ${formIndex}`);
                }
              }}
              required={field.required && !value}
            />
            <div className="flex items-center justify-center px-3 py-4 border-2 border-dashed border-yellow-400 rounded-lg bg-yellow-50 hover:bg-yellow-100 transition-colors duration-300 cursor-pointer">
              <div className="text-center">
                <div className="w-8 h-8 mx-auto mb-2 bg-yellow-400 rounded-full flex items-center justify-center">
                  <svg
                    className="w-4 h-4 text-gray-900"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    />
                  </svg>
                </div>
                {/* 🔧 ENHANCED: Better file status display */}
                {value instanceof File ? (
                  <div>
                    <p className="text-xs font-medium text-green-700">
                      📎 {value.name}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Ready to upload • Click to change
                    </p>

                  </div>
                ) : (() => {
                  // Check for preview (existing file from database)
                  const previewKey = field.key + 'Preview';
                  const preview = form[section.id][previewKey];
                  if (preview && preview.url) {
                    return (
                      <div>
                        <p className="text-xs font-medium text-blue-700">
                          📎 Existing file uploaded
                        </p>
                        <a 
                          href={preview.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-blue-600 hover:text-blue-800 underline mt-1 inline-block"
                          onClick={(e) => e.stopPropagation()}
                        >
                          View current file
                        </a>
                        <p className="text-xs text-gray-500 mt-1">
                          Click to upload new file
                        </p>
                      </div>
                    );
                  } else {
                    return (
                      <div>
                        <p className="text-xs font-medium text-gray-700">
                          Click to upload {field.label}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          PDF, DOC, DOCX, JPG, PNG up to 10MB
                        </p>
                      </div>
                    );
                  }
                })()}
              </div>
            </div>
          </div>
        );
      default:
        return (
          <input
            type={field.type}
            className={commonClasses}
            value={value}
            onChange={(e) =>
              handleInputChange(form.id, section.id, field.key, e.target.value)
            }
            placeholder={`Enter ${field.label.toLowerCase()}...`}
            required={field.required}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">


        {/* Forms */}
        <div className="space-y-6">
          {forms.map((form, formIndex) => (
            <div
              key={form.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden"
            >
              {/* Form Header */}
              <div className="bg-gray-200 px-6 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-gray-900">
                        {formIndex + 1}
                      </span>
                    </div>
                    <h2 className="text-xl font-bold text-gray-900">
                      IPR Details ({formIndex + 1})
                    </h2>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onClick={addNewForm}
                      className="px-4 py-2 bg-gradient-to-r from-green-400 to-green-500 text-white rounded-lg font-semibold hover:from-green-500 hover:to-green-600 transition-all duration-300 transform hover:scale-101 flex items-center space-x-2 shadow-md"
                    >
                      <Plus className="w-5 h-5" />
                      <span>Add Another IPR Details</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => duplicateForm(form.id)}
                      className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors duration-200"
                      title="Duplicate Form"
                    >
                      <Copy className="w-4 h-4 text-gray-900" />
                    </button>

                    {forms.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeForm(form.id)}
                        className="p-2 bg-red-500/20 rounded-lg hover:bg-red-500/30 transition-colors duration-200"
                        title="Remove Form"
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Form Content */}
              <div className="p-6">
                <div className="space-y-8">
                  {sections.map((section) => (
                    <div
                      key={section.id}
                      className="border-b border-gray-200 pb-6 last:border-b-0 last:pb-0"
                    >
                      {/* Section Header */}
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                          <span className="text-sm font-bold text-white">
                            {section.number}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">
                            {section.title}
                          </h3>
                          <div className="w-16 h-0.5 bg-yellow-400 rounded-full mt-1"></div>
                        </div>
                      </div>

                      {/* Section Fields */}
                      <div className="ml-11">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {section.fields.map((field) => (
                            <div
                              key={field.key}
                              className={
                                field.type === "textarea"
                                  ? "md:col-span-2 lg:col-span-3"
                                  : section.id === "telecomServiceProvider" &&
                                    field.key === "address"
                                  ? "md:col-span-2 lg:col-span-3"
                                  : field.type === "file"
                                  ? "md:col-span-2 lg:col-span-3"
                                  : ""
                              }
                            >
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                {field.label}
                                {field.required && (
                                  <span className="text-red-500 ml-1">*</span>
                                )}
                              </label>
                              {renderField(form, section, field, formIndex)}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IPRDetails;