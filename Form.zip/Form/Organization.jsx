import React, { useState } from "react";
import { FiUploadCloud } from "react-icons/fi";
import { motion } from "framer-motion";

const LabelRequired = ({ label }) => (
  <label className="block text-sm font-medium mb-1 text-amber-800">
    {label} <span className="text-red-600">*</span>
  </label>
);

const Input = ({ label, placeholder, type = "text", required = false }) => (
  <div>
    {label && (
      <label className="block text-sm font-medium mb-1 text-amber-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
    )}
    <input
      type={type}
      placeholder={placeholder}
      required={required}
      className="w-full p-2 border border-amber-300 rounded focus:outline-none focus:ring-2 focus:ring-amber-400"
    />
  </div>
);

const FileUpload = ({ label, required = false, accept, height = "h-32" }) => {
  const [preview, setPreview] = useState(null);

  const handleChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith("image/")) {
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
    } else {
      setPreview(null);
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium mb-1 text-amber-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      <div
        className={`relative w-full border-2 border-dashed border-amber-300 rounded px-3 py-6 cursor-pointer text-amber-600 text-sm bg-amber-50 ${height}`}
      >
        <input
          type="file"
          required={required}
          accept={accept}
          onChange={handleChange}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        {!preview && (
          <div className="flex flex-col items-center justify-center text-amber-600 select-none pointer-events-none h-full">
            <FiUploadCloud className="text-4xl mb-2" />
            <span>Click or drag file to upload</span>
          </div>
        )}
        {preview && (
          <img
            src={preview}
            alt="Preview"
            className="absolute top-1 left-1/3 right-1/3 bottom-1 object-contain rounded max-w-full max-h-[90%]"
          />
        )}
      </div>
    </div>
  );
};
const boxVariants = {
  hidden: { opacity: 0, x: -100 },  
  visible: { opacity: 1, x: 0 },
}

const Organization = () => {
  return (
    <motion.div className="  flex justify-center py-10 px-4"
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}>
      <div className="w-full max-w-6xl bg-white p-8 space-y-6">
        <form onSubmit={(e) => e.preventDefault()}>
          <h2 className="text-2xl font-bold text-amber-900 mb-6 text-center">
            Organization/Institute Details
          </h2>

          <h3 className="text-lg font-bold text-amber-900 mb-6 border-b-2 border-amber-800">
            Address of the Applicant
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <Input label="Address Line 1" placeholder="Enter your address line" required />
              <Input label="Street/Village" placeholder="Enter your street name" />
              <Input label="Landline" placeholder="Enter landline number"  type="number" />
              <Input label="E-Mail" placeholder="your.email@example.com" type="email" required />
            </div>

            <div className="space-y-4">
              <Input label="City" placeholder="Enter your city" required />
              <Input label="District" placeholder="Enter your district" required />
              <Input label="State" placeholder="Enter your state" required />
              <Input label="Pin Code" placeholder="Enter your pin code" required type="number" />
            </div>
          </div>

          <h3 className="font-semibold text-amber-800 mt-8 mb-6 border-b-2 border-amber-800">
            Registration Information <span className="text-red-600">*</span>
          </h3>

          <div className="mb-6">
            <label className="block text-sm font-medium mb-1 text-amber-800">
              Are the shares of the company held to the extent of 51% by citizens?
            </label>
            <select
              required
              className="w-full p-2 border border-amber-300 rounded focus:outline-none focus:ring-2 focus:ring-amber-400"
            >
              <option value="">-- Select --</option>
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
          </div>

          <h3 className="font-semibold text-amber-800 mt-8 mb-6 border-b-2 border-amber-800">
            Required Documents <span className="text-red-600">*</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FileUpload label="Aadhar Card" required accept=".pdf,.png,.jpg,.jpeg" />
            <FileUpload label="PAN Card" required accept=".pdf,.png,.jpg,.jpeg" />
            <FileUpload label="Certificate of Incorporation" required accept=".pdf,.png,.jpg,.jpeg" />
            <FileUpload label="GST Certificate" required accept=".pdf,.png,.jpg,.jpeg" />
            <FileUpload label="Company Profile" required accept=".pdf,.png,.jpg,.jpeg" />
            <FileUpload label="Authorized Signatory Proof" required accept=".pdf,.png,.jpg,.jpeg" />
          </div>
        </form>
      </div>
    </motion.div>
  );
};

export default Organization;
