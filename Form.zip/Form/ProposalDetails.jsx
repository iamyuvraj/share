import React, { useState, useEffect, useCallback, useRef } from "react";

const ProposalDetails = ({
  initialFormData = {},
  onFormDataChange,
  financeDetails,
}) => {
  
  const contributionPercent = Number(
    (
      (financeDetails.actual_contribution_applicant * 100) /
      financeDetails.actual_grant_from_ttdf
    ).toFixed(2)
  );

  // Initialize state with initialFormData or defaults FIRST
  const [formState, setFormState] = useState({
    keyInformation: {
      proposalBrief: initialFormData?.keyInformation?.proposalBrief || "",
      grantToTurnoverRatio: initialFormData?.keyInformation?.grantToTurnoverRatio || "",
    },
    proposalSummary: {
      proposedVillage: initialFormData?.proposalSummary?.proposedVillage || "",
      useCase: initialFormData?.proposalSummary?.useCase || "",
      potentialImpact: initialFormData?.proposalSummary?.potentialImpact || "",
      endToEndSolution: initialFormData?.proposalSummary?.endToEndSolution || "",
      dataSecurityMeasures: initialFormData?.proposalSummary?.dataSecurityMeasures || "",
      modelVillage: initialFormData?.proposalSummary?.modelVillage || "",
    },
    teamMembers: initialFormData?.teamMembers || [
      { id: -1, name: "", resumeFile: null, resumeFilePreview: null, resumeText: "", otherDetails: "" },
    ],
  });

  
  const isMounted = useRef(true);
  const lastFormStateRef = useRef(formState); 
  const debounceTimeoutRef = useRef(null);
  console.log("🐛 Team members count:", formState.teamMembers.length);
  console.log("🐛 Team members:", formState.teamMembers.map(m => ({ id: m.id, name: m.name })));

 
  useEffect(() => {
    return () => {
      isMounted.current = false;
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, []);

  
  const villageOptions = [
    { value: "", label: "Select a Village" },
    { value: "ari_umri_mp", label: "Ari & Umri (Block Guna, Madhya Pradesh)" },
    {
      value: "narakoduru_ap",
      label: "Narakoduru (Block Chebrolu, Andhra Pradesh)",
    },
    {
      value: "chaurawala_up",
      label: "Chaurawala (Block Morna, Uttar Pradesh)",
    },
  ];

 
  // FIXED: Debounced form data change handler to prevent excessive API calls
const debouncedFormDataChange = useCallback(
  (newFormState) => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }

    debounceTimeoutRef.current = setTimeout(() => {
      if (isMounted.current) {
        onFormDataChange(newFormState);
        lastFormStateRef.current = newFormState;
      }
    }, 300); // 300ms debounce delay
  },
  [onFormDataChange]
);


useEffect(() => {

  if (isMounted.current && onFormDataChange) {
    
    onFormDataChange(formState);
   
  }
}, [formState, onFormDataChange]);


useEffect(() => {
  if (initialFormData && Object.keys(initialFormData).length > 0) {
    setFormState({
      keyInformation: {
        proposalBrief: initialFormData?.keyInformation?.proposalBrief || "",
        grantToTurnoverRatio: initialFormData?.keyInformation?.grantToTurnoverRatio || "",
      },
      proposalSummary: {
        proposedVillage: initialFormData?.proposalSummary?.proposedVillage || "",
        useCase: initialFormData?.proposalSummary?.useCase || "",
        potentialImpact: initialFormData?.proposalSummary?.potentialImpact || "",
        endToEndSolution: initialFormData?.proposalSummary?.endToEndSolution || "",
        dataSecurityMeasures: initialFormData?.proposalSummary?.dataSecurityMeasures || "",
        modelVillage: initialFormData?.proposalSummary?.modelVillage || "",
      },
      teamMembers: initialFormData?.teamMembers || [
        { id: -1, name: "", resumeFile: null, resumeFilePreview: null, resumeText: "", otherDetails: "" },
      ],
    });
  }
}, [initialFormData]);

  const handleKeyInfoChange = (field, value) => {
  console.log("🔍 handleKeyInfoChange called:", { field, value });
  
  setFormState((prev) => {
    const newState = {
      ...prev,
      keyInformation: {
        ...prev.keyInformation,
        [field]: limitWords(value),
      },
    };
    console.log("🔍 New formState after keyInfo change:", newState);
    
    
    if (onFormDataChange) {
      console.log("🔍 Immediate callback with value:", value);
     
      setTimeout(() => {
        onFormDataChange(newState);
      }, 0);
    }
    
    return newState;
  });
};
  const handleSummaryChange = (field, value) => {
  setFormState((prev) => {
    const newState = {
      ...prev,
      proposalSummary: {
        ...prev.proposalSummary,
        [field]: limitWords(value),
      },
    };
    console.log("🔍 New formState after summary change:", newState);
    
    
    if (onFormDataChange) {
      
      setTimeout(() => {
        onFormDataChange(newState);
      }, 0);
    }
    
    return newState;
  });
};

  const handleTeamMemberChange = (id, field, value) => {
  setFormState((prev) => {
    const newState = {
      ...prev,
      teamMembers: prev.teamMembers.map((member) =>
        member.id === id ? { ...member, [field]: value } : member
      ),
    };

    if (onFormDataChange) {
  
      setTimeout(() => {
        onFormDataChange(newState);
      }, 0);
    }
    
    return newState;
  });
};

  const handleResumeUpload = (id, file) => {
  setFormState((prev) => {
    const newState = {
      ...prev,
      teamMembers: prev.teamMembers.map((member) =>
        member.id === id ? { ...member, resumeFile: file } : member
      ),
    };
    

    if (onFormDataChange) {
    
      setTimeout(() => {
        onFormDataChange(newState);
      }, 0);
    }
    
    return newState;
  });
};

  const removeResumeFile = (id) => {
  setFormState((prev) => {
    const newState = {
      ...prev,
      teamMembers: prev.teamMembers.map((member) =>
        member.id === id ? { ...member, resumeFile: null, resumeFilePreview: null } : member
      ),
    };
    
    if (onFormDataChange) {
   
      setTimeout(() => {
        onFormDataChange(newState);
      }, 0);
    }
    
    return newState;
  });
};

  const MAX_TEAM_MEMBERS = 5;

  const addTeamMember = () => {
  if (formState.teamMembers.length < MAX_TEAM_MEMBERS) {
    const existingIds = formState.teamMembers.map(m => m.id);
    const minId = Math.min(...existingIds, 0);
    const newId = minId - 1;
    
    setFormState((prev) => {
      const newState = {
        ...prev,
        teamMembers: [
          ...prev.teamMembers,
          {
            id: newId,
            name: "",
            resumeFile: null,
            resumeFilePreview: null,
            resumeText: "",
            otherDetails: "",
          },
        ],
      };
      

      if (onFormDataChange) {
        setTimeout(() => {
          onFormDataChange(newState);
        }, 0);
      }
      
      return newState;
    });
  }
};

const removeTeamMember = (id) => {
  if (formState.teamMembers.length > 1) {
    setFormState((prev) => {
      const newState = {
        ...prev,
        teamMembers: prev.teamMembers.filter((member) => member.id !== id),
      };
 
      if (onFormDataChange) {
        setTimeout(() => {
          onFormDataChange(newState);
        }, 0);
      }
      
      return newState;
    });
  }
};
  
  const isKeyInfoComplete = () => {
    return Object.values(formState.keyInformation).every(
      (value) => value.trim() !== ""
    );
  };

  const isSummaryComplete = () => {
    return Object.values(formState.proposalSummary).every(
      (value) => value.trim() !== ""
    );
  };

  const isTeamComplete = () => {
  return formState.teamMembers.every(
    (member) =>
      member.name.trim() !== "" &&
      (member.resumeFile !== null || member.resumeFilePreview !== null) &&
      member.otherDetails.trim() !== ""
  );
};

  const isFormComplete = () => {
    return isKeyInfoComplete() && isSummaryComplete() && isTeamComplete();
  };

  const MAX_WORDS = 1000;

  const countWords = (text) => {
    return text.trim().split(/\s+/).filter(Boolean).length;
  };

  const limitWords = (text) => {
    const words = text.trim().split(/\s+/);
    if (words.length <= MAX_WORDS) return text;
    return words.slice(0, MAX_WORDS).join(" ");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Key Information Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">1</span>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                Key Information of the Proposal
              </h2>
              {/* <p className="text-gray-600">
                Essential details about your proposal and financial structure
              </p> */}
            </div>
          </div>

          <div className="space-y-6">
            {/* Proposal Brief */}
            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Brief About the Proposal
                <span className="text-red-500 ml-1">*</span>
              </label>

              <textarea
                value={formState.keyInformation.proposalBrief}
                onChange={(e) =>
                  handleKeyInfoChange("proposalBrief", e.target.value)
                }
                className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Description (max 1000 words)"
                rows="4"
              />
              <p className="text-xs text-gray-500 mt-1">
                {countWords(formState.keyInformation.proposalBrief)} /{" "}
                {MAX_WORDS} words
                {countWords(formState.keyInformation.proposalBrief) >=
                  MAX_WORDS && (
                  <span className="text-red-500 ml-2">Word limit reached!</span>
                )}
              </p>
            </div>

            {/* Financial Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Contribution Percentage (%)
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={formState.keyInformation.contributionPercentage}
                    onChange={(e) =>
                      handleKeyInfoChange(
                        "contributionPercentage",
                        e.target.value
                      )
                    }
                    className="w-full px-4 py-3 pr-12 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200"
                    placeholder="0"
                    min="0"
                    max="100"
                    step="0.1"
                  />
                  <div className="absolute right-3 top-3 text-gray-400">%</div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Percentage of funds contributed from your side relative to
                  TTDF grant sought
                </p>
              </div> */}

              {/* <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Grant to Turnover Ratio (%)
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={formState.keyInformation.grantToTurnoverRatio}
                    onChange={(e) =>
                      handleKeyInfoChange(
                        "grantToTurnoverRatio",
                        e.target.value
                      )
                    }
                    className="w-full px-4 py-3 pr-12 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200"
                    placeholder="0"
                    min="0"
                    max="100"
                    step="0.1"
                  />
                  <div className="absolute right-3 top-3 text-gray-400">%</div>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Ratio of TTDF grant sought to your organization's annual turnover
                </p>
              </div> */}
            </div>
          </div>
        </div>

        {/* Proposal Summary Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">2</span>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                Proposal Summary
              </h2>
              {/* <p className="text-gray-600">
                Detailed information about your 5G model village implementation
              </p> */}
            </div>
          </div>

          <div className="space-y-6">
            {/* Village Selection and Use Cases */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Name of the Village Proposed
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <select
                  value={formState.proposalSummary.proposedVillage}
                  onChange={(e) =>
                    handleSummaryChange("proposedVillage", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200"
                >
                  {villageOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  List of Service Offerings to be Deployed (as illustrated in
                  Call for Proposal)
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <textarea
                  value={formState.proposalSummary.useCase}
                  onChange={(e) =>
                    handleSummaryChange("useCase", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                  placeholder="Description (max 1000 words)"
                  rows="3"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {countWords(formState.proposalSummary.useCase)} / {MAX_WORDS}{" "}
                  words
                  {countWords(formState.proposalSummary.useCase) >=
                    MAX_WORDS && (
                    <span className="text-red-500 ml-2">
                      Word limit reached!
                    </span>
                  )}
                </p>
              </div>
            </div>

            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                List of Additional Service Offerings to be Deployed (apart from
                the ones illustrated in Call for Proposal)
                <span className="text-red-500 ml-1">*</span>
              </label>
              <textarea
                value={formState.proposalSummary.endToEndSolution}
                onChange={(e) =>
                  handleSummaryChange("endToEndSolution", e.target.value)
                }
                className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Describe (max 1000 words)"
                rows="4"
              />
              <p className="text-xs text-gray-500 mt-1">
                {countWords(formState.proposalSummary.endToEndSolution)} /{" "}
                {MAX_WORDS} words
                {countWords(formState.proposalSummary.endToEndSolution) >=
                  MAX_WORDS && (
                  <span className="text-red-500 ml-2">Word limit reached!</span>
                )}
              </p>
            </div>

            {/* Abstract and Impact */}
            <div className="grid grid-cols-1 md:grid-cols-1 gap-6">
              {/* <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Abstract of the Proposal
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <textarea
                  value={formState.proposalSummary.proposalAbstract}
                  onChange={(e) =>
                    handleSummaryChange("proposalAbstract", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                  placeholder="Provide a detailed abstract of your proposal..."
                  rows="4"
                />
              </div> */}

              <div className="group">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Potential Impact
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <textarea
                  value={formState.proposalSummary.potentialImpact}
                  onChange={(e) =>
                    handleSummaryChange("potentialImpact", e.target.value)
                  }
                  className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                  placeholder="Describe the expected impact on the village and community... (max 1000 words)"
                  rows="4"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {countWords(formState.proposalSummary.potentialImpact)} /{" "}
                  {MAX_WORDS} words
                  {countWords(formState.proposalSummary.potentialImpact) >=
                    MAX_WORDS && (
                    <span className="text-red-500 ml-2">
                      Word limit reached!
                    </span>
                  )}
                </p>
              </div>
            </div>

            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Monitoring Mechanism
                <span className="text-red-500 ml-1">*</span>
              </label>
              <textarea
                value={formState.proposalSummary.modelVillage}
                onChange={(e) =>
                  handleSummaryChange("modelVillage", e.target.value)
                }
                className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Describe (max 1000 words)"
                rows="4"
              />
              <p className="text-xs text-gray-500 mt-1">
                {countWords(formState.proposalSummary.modelVillage)} /{" "}
                {MAX_WORDS} words
                {countWords(formState.proposalSummary.modelVillage) >=
                  MAX_WORDS && (
                  <span className="text-red-500 ml-2">Word limit reached!</span>
                )}
              </p>
            </div>

            {/* Data Security */}
            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Data Security Measures
                <span className="text-red-500 ml-1">*</span>
              </label>
              <textarea
                value={formState.proposalSummary.dataSecurityMeasures}
                onChange={(e) =>
                  handleSummaryChange("dataSecurityMeasures", e.target.value)
                }
                className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Detail how your proposal ensures data security and privacy... (max 1000 words)"
                rows="4"
              />
              <p className="text-xs text-gray-500 mt-1">
                {countWords(formState.proposalSummary.dataSecurityMeasures)} /{" "}
                {MAX_WORDS} words
                {countWords(formState.proposalSummary.dataSecurityMeasures) >=
                  MAX_WORDS && (
                  <span className="text-red-500 ml-2">Word limit reached!</span>
                )}
              </p>
            </div>

            {/* Required Support */}
            {/* <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Required Support Details
                <span className="text-red-500 ml-1">*</span>
              </label>
              <textarea
                value={formState.proposalSummary.requiredSupportDetails}
                onChange={(e) =>
                  handleSummaryChange("requiredSupportDetails", e.target.value)
                }
                className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Specify any support required from TTDF for successful implementation..."
                rows="4"
              />
            </div> */}

            {/* Team Section */}
            <div className="group">
              <div className="flex items-center justify-between mb-4">
                <label className="block text-sm font-semibold text-gray-700">
                  Team Members
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <button
                  type="button"
                  onClick={addTeamMember}
                  className="px-4 py-2 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-lg hover:from-yellow-600 hover:to-yellow-700 transition-all duration-200 flex items-center gap-2 text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={formState.teamMembers.length >= MAX_TEAM_MEMBERS}
                  title={
                    formState.teamMembers.length >= MAX_TEAM_MEMBERS
                      ? "Maximum 5 team members allowed."
                      : ""
                  }
                >
                  <svg
                    className="w-4 h-4"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                    />
                  </svg>
                  Add Team Member
                </button>
              </div>

              <div className="space-y-6">
                {formState.teamMembers.map((member, index) => (
                  <div
                    key={member.id}
                    className="border border-gray-200 rounded-lg p-4 bg-gray-50"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-semibold text-gray-800">
                        Team Member {index + 1}
                      </h4>
                      {formState.teamMembers.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeTeamMember(member.id)}
                          className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-all duration-200"
                        >
                          <svg
                            className="w-4 h-4"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                            />
                          </svg>
                        </button>
                      )}
                    </div>

                    <div className="space-y-4">
                      <div className="group">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Name
                          <span className="text-red-500 ml-1">*</span>
                        </label>
                        <input
                          type="text"
                          value={member.name}
                          onChange={(e) =>
                            handleTeamMemberChange(
                              member.id,
                              "name",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200"
                          placeholder="Enter team member's full name..."
                        />
                      </div>

                      <div className="group">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Designation
                          <span className="text-red-500 ml-1">*</span>
                        </label>
                        <textarea
                          value={member.otherDetails}
                          onChange={(e) =>
                            handleTeamMemberChange(
                              member.id,
                              "otherDetails",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 resize-none"
                          placeholder="Enter Designation"
                          rows="1"
                        />
                      </div>

                      <div className="group">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Resume/CV
                          <span className="text-red-500 ml-1">*</span>
                        </label>

                        {/* File Upload Option */}
                        <div className="mb-4">
                          <div className="border-2 border-dashed border-yellow-300 rounded-lg p-4 text-center hover:border-yellow-400 transition-colors">
                            {(member.resumeFile || member.resumeFilePreview) ? (
  <div className="flex items-center justify-between bg-yellow-50 p-3 rounded-lg">
    <div className="flex items-center gap-3">
      <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
        <svg className="w-4 h-4 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      </div>
      <div className="text-left">
        <p className="text-sm font-medium text-gray-700">
          {member.resumeFile ? member.resumeFile.name : 'Previously uploaded resume'}
        </p>
        <p className="text-xs text-gray-500">
          {member.resumeFile ? 
            `${(member.resumeFile.size / 1024 / 1024).toFixed(2)} MB` : 
            'Existing file'
          }
        </p>
      </div>
    </div>
    <div className="flex gap-2">
      {member.resumeFilePreview && member.resumeFilePreview.url && (
        <a
          href={member.resumeFilePreview.url}
          target="_blank"
          rel="noopener noreferrer"
          className="p-1 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-full transition-all duration-200"
          title="View existing resume"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
        </a>
      )}
      <button type="button" onClick={() => removeResumeFile(member.id)} className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full transition-all duration-200">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
        </button>
    </div>
  </div>
) : (
                              <div>
                                <input
                                  type="file"
                                  id={`resume-${member.id}`}
                                  accept=".pdf,.doc,.docx"
                                  onChange={(e) =>
                                    handleResumeUpload(
                                      member.id,
                                      e.target.files[0]
                                    )
                                  }
                                  className="hidden"
                                />
                                <label
                                  htmlFor={`resume-${member.id}`}
                                  className="cursor-pointer flex flex-col items-center gap-2"
                                >
                                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                                    <svg
                                      className="w-6 h-6 text-yellow-600"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                                      />
                                    </svg>
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">
                                      Upload Resume
                                    </p>
                                    <p className="text-xs text-gray-500">
                                      PDF, DOC, DOCX (Max 5MB)
                                    </p>
                                  </div>
                                </label>
                              </div>
                            )}
                          </div>
                        </div>

                        {member.resumeFile && (
                          <p className="text-xs text-gray-500 mt-2">
                            Resume Uploaded
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProposalDetails;
