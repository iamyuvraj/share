import React from "react";
import { FiUploadCloud } from "react-icons/fi";
import { motion } from "framer-motion";

// Label with required asterisk
const LabelRequired = ({ label }) => (
  <label className="block text-sm font-medium mb-1 text-yellow-800">
    {label} <span className="text-red-600">*</span>
  </label>
);

// Reusable input component with optional label
const Input = ({ label, placeholder, type = "text", required = false, name, value, onChange }) => (
  <div>
    {label && (
      <label className="block text-sm font-medium mb-1 text-yellow-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
    )}
    <input
      type={type}
      placeholder={placeholder}
      required={required}
      name={name}
      value={value}
      onChange={onChange}
      className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
    />
  </div>
);

// File upload component with preview for images
const FileUpload = ({
  label,
  required = false,
  accept,
  height = "h-32",
  name,
  onFileChange,
  preview,
}) => {
  return (
    <div
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      <label className="block text-sm font-medium mb-1 text-yellow-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      <div
        className={`relative w-full border-2 border-dashed border-yellow-500 rounded px-3 py-6 cursor-pointer text-yellow-700 text-sm bg-yellow-50 ${height}`}
      >
        <input
          type="file"
          required={required}
          accept={accept}
          onChange={(e) => onFileChange(name, e.target.files[0])}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        {!preview && (
          <>
            {accept.includes("image/") ? (
              <div className="flex flex-col items-center justify-center text-yellow-700 select-none pointer-events-none h-full">
                <FiUploadCloud className="text-4xl mb-2" />
                <span>Click or drag image file to upload</span>
              </div>
            ) : (
              <span className="block text-center select-none pointer-events-none">
                Click or drag file to upload
              </span>
            )}
          </>
        )}
        {preview && (
          <img
            src={preview}
            alt="Preview"
            className="absolute top-1 left-1/3 right-1/3 bottom-1 object-contain rounded max-w-full max-h-[90%]"
          />
        )}
      </div>
    </div>
  );
};

const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const BasicForm = ({ formData, onFormDataChange }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.startsWith("address.")) {
      const key = name.split(".")[1];
      onFormDataChange({
        ...formData,
        address: { ...formData.address, [key]: value },
      });
    } else {
      onFormDataChange({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleFileChange = (name, file) => {
    const preview = file && file.type.startsWith("image/") ? URL.createObjectURL(file) : null;
    onFormDataChange({
      ...formData,
      [name]: file,
      [`${name}Preview`]: preview,
    });
  };

  const handleSave = () => {
    console.log("Basic Form Data:", formData);
  };

  return (
    <motion.div
      className="flex justify-center"
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-6xl bg-white rounded p-8">
        <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
          <h2 className="text-2xl font-semibold text-yellow-800 mb-6 border-b-2 border-yellow-800 pb-2 text-center">
            Basic Information
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-4">
              <FileUpload
                label="Applicant Photo"
                required
                accept=".jpg,.jpeg"
                name="applicantPhoto"
                onFileChange={handleFileChange}
                preview={formData.applicantPhotoPreview}
              />
              <Input
                label="Applicant Name"
                placeholder="Enter your full name"
                required
                type="text"
                name="applicantName"
                value={formData.applicantName}
                onChange={handleChange}
              />
              <div>
                <LabelRequired label="Gender" />
                <div className="flex space-x-4 text-yellow-800">
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="Male"
                      checked={formData.gender === "Male"}
                      onChange={handleChange}
                      required
                    />{" "}
                    Male
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="Female"
                      checked={formData.gender === "Female"}
                      onChange={handleChange}
                    />{" "}
                    Female
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="Other"
                      checked={formData.gender === "Other"}
                      onChange={handleChange}
                    />{" "}
                    Other
                  </label>
                </div>
              </div>
              <h3 className="font-semibold text-yellow-800 mt-4">
                Highest Qualification <span className="text-red-600">*</span>
              </h3>
              <Input
                placeholder="Enter Qualification"
                required
                name="qualification"
                value={formData.qualification}
                onChange={handleChange}
              />
              <FileUpload
                label="Resume Upload"
                required
                accept=".pdf,.png,.jpg,.jpeg"
                name="resume"
                onFileChange={handleFileChange}
                preview={formData.resumePreview}
              />
              <Input
                label="Mobile No."
                placeholder="Enter your phone number"
                required
                type="number"
                name="mobile"
                value={formData.mobile}
                onChange={handleChange}
              />
              <Input
                label="E-Mail"
                placeholder="your.email@example.com"
                type="email"
                required
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
              <div>
                <LabelRequired label="Type of Applicant" />
                <select
                  required
                  className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
                  name="applicantType"
                  value={formData.applicantType}
                  onChange={handleChange}
                >
                  <option value="" disabled>
                    Select Type
                  </option>
                  <option>Individual</option>
                  <option>Company</option>
                </select>
              </div>
              <Input
                label="Individual PAN"
                placeholder="Enter PAN number"
                required
                type="text"
                name="individualPAN"
                value={formData.individualPAN}
                onChange={handleChange}
              />
              <FileUpload
                label="Upload PAN File"
                required
                accept=".pdf,.png,.jpg,.jpeg"
                name="panFile"
                onFileChange={handleFileChange}
                preview={formData.panFilePreview}
              />
              <h3 className="font-semibold text-yellow-800 mt-4">
                Full Address <span className="text-red-600">*</span>
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="House No."
                  required
                  type="text"
                  name="address.houseNo"
                  value={formData.address.houseNo}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Street Name"
                  required
                  name="address.street"
                  value={formData.address.street}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Locality"
                  required
                  name="address.locality"
                  value={formData.address.locality}
                  onChange={handleChange}
                />
                <Input
                  placeholder="District"
                  required
                  name="address.district"
                  value={formData.address.district}
                  onChange={handleChange}
                />
                <Input
                  placeholder="State"
                  required
                  name="address.state"
                  value={formData.address.state}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Pin Code"
                  required
                  type="number"
                  name="address.pin"
                  value={formData.address.pin}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Country"
                  required
                  name="address.country"
                  value={formData.address.country}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Landmark"
                  required
                  name="address.landmark"
                  value={formData.address.landmark}
                  onChange={handleChange}
                />
              </div>
            </div>
            {/* Right Column */}
            <div className="space-y-4">
              <Input
                label="Official E-Mail"
                placeholder="your.email@example.com"
                type="email"
                required
                name="officialEmail"
                value={formData.officialEmail}
                onChange={handleChange}
              />
              <Input
                label="Organization"
                placeholder="Organization Name"
                required
                name="organization"
                value={formData.organization}
                onChange={handleChange}
              />
              <Input
                label="Proposal Duration"
                placeholder="Enter Proposal Duration (in months)"
                required
                type="number"
                name="proposalDuration"
                value={formData.proposalDuration}
                onChange={handleChange}
              />
              <Input
                label="Landline No."
                placeholder="Enter your phone number"
                required
                type="number"
                name="landline"
                value={formData.landline}
                onChange={handleChange}
              />
              <div>
                <LabelRequired label="Organization Type" />
                <select
                  required
                  className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
                  name="organizationType"
                  value={formData.organizationType}
                  onChange={handleChange}
                >
                  <option value="" disabled>
                    Select Organization Type
                  </option>
                  <option>MSME</option>
                  <option>Start-Up</option>
                </select>
              </div>
              <Input
                label="Company Mobile No."
                placeholder="Enter your phone number"
                required
                type="number"
                name="companyMobile"
                value={formData.companyMobile}
                onChange={handleChange}
              />
              <Input
                label="Website"
                placeholder="www.example.com"
                required
                name="website"
                value={formData.website}
                onChange={handleChange}
              />
              <Input
                label="Proposal Submitted By"
                placeholder="Enter Name"
                required
                name="proposalBy"
                value={formData.proposalBy}
                onChange={handleChange}
              />
              <FileUpload
                label="Registration Certificate Document"
                accept=".pdf,.png,.jpg,.jpeg"
                name="registrationCertificate"
                onFileChange={handleFileChange}
                preview={formData.registrationCertificatePreview}
              />
              <FileUpload
                label="Upload Passport"
                accept=".pdf,.png,.jpg,.jpeg"
                name="passport"
                onFileChange={handleFileChange}
                preview={formData.passportPreview}
              />
              <div>
                <LabelRequired label="Company As Per TTDF Guidelines" />
                <select
                  required
                  className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
                  name="ttdfCompany"
                  value={formData.ttdfCompany}
                  onChange={handleChange}
                >
                  <option value="" disabled>
                    Select
                  </option>
                  <option>Yes</option>
                  <option>No</option>
                </select>
              </div>
              <FileUpload
                label="CA Certified Shareholding Pattern Attachment"
                accept=".pdf,.png,.jpg,.jpeg"
                name="shareHoldingPattern"
                onFileChange={handleFileChange}
                preview={formData.shareHoldingPatternPreview}
              />
              <FileUpload
                label="DSIR Certificate Attachment"
                accept=".pdf,.png,.jpg,.jpeg"
                name="dsirCertificate"
                onFileChange={handleFileChange}
                preview={formData.dsirCertificatePreview}
              />
            </div>
          </div>
          {/* Save Button */}
          <div className="flex justify-end pt-6">
            <button
              type="button"
              className="bg-yellow-600 text-white px-6 py-2 rounded hover:bg-yellow-700 transition"
              onClick={handleSave}
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </motion.div>
  );
};

export default BasicForm;