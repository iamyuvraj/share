import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Plus,
  Trash2,
  Calculator,
  FileText,
  Settings,
  TrendingUp,
} from "lucide-react";

// Utility functions with null checks
function sumGrantsByType(offering) {
  if (!offering?.items) return { capexYear0: 0, opexYear1: 0, opexYear2: 0 };

  let capexYear0 = 0,
    opexYear1 = 0,
    opexYear2 = 0;
  for (const item of offering.items) {
    capexYear0 += Number(item?.financials?.capex?.year0?.grant || 0);
    opexYear1 += Number(item?.financials?.opex?.year1?.grant || 0);
    opexYear2 += Number(item?.financials?.opex?.year2?.grant || 0);
  }
  return { capexYear0, opexYear1, opexYear2 };
}

function sumTableGrantsByType(table) {
  if (!table?.serviceOfferings)
    return { capexYear0: 0, opexYear1: 0, opexYear2: 0 };

  return table.serviceOfferings.reduce(
    (acc, offering) => {
      const sums = sumGrantsByType(offering);
      acc.capexYear0 += sums.capexYear0;
      acc.opexYear1 += sums.opexYear1;
      acc.opexYear2 += sums.opexYear2;
      return acc;
    },
    { capexYear0: 0, opexYear1: 0, opexYear2: 0 }
  );
}

function sumAllCapexYear0(tables = []) {
  return tables.reduce(
    (sum, table) => sum + sumTableGrantsByType(table).capexYear0,
    0
  );
}

// FIXED: Debounce function to prevent excessive updates
function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  
  return debouncedValue;
}

const BudgetEstimate = ({ formData = {}, onFormDataChange }) => {
  const [activeTab, setActiveTab] = useState("budgetEstimate");
  const isInitializedRef = useRef(false);
  const lastNotifiedDataRef = useRef(null);

  // FIXED: Initialize form data structure with defaults
  const getDefaultFormData = useCallback(() => ({
    tables: [
      {
        id: "table-1",
        title: "Budget Estimate of Service",
        serviceOfferings: [
          {
            id: "offering-1",
            name: "Enter Service Name...",
            items: [
              {
                id: "item-1",
                description: "",
                financials: {
                  capex: {
                    year0: {
                      description: "",
                      cost: 0,
                      qty: 0,
                      total: 0,
                      grant: 0,
                      remarks: "",
                    },
                  },
                  opex: {
                    year1: {
                      description: "",
                      cost: 0,
                      qty: 0,
                      total: 0,
                      grant: 0,
                      remarks: "",
                    },
                    year2: {
                      description: "",
                      cost: 0,
                      qty: 0,
                      total: 0,
                      grant: 0,
                      remarks: "",
                    },
                  },
                },
              },
            ],
          },
        ],
      },
    ],
    equipmentOverhead: {
      tables: [
        {
          id: "table-2",
          title: "Equipment Overhead",
          serviceOfferings: [
            {
              id: "offering-2",
              name: "IT Infrastructure",
              items: [
                {
                  id: "item-2",
                  description: "Server Setup",
                  financials: {
                    capex: {
                      year0: {
                        description: "Dell PowerEdge Server",
                        cost: 200,
                        qty: 1,
                        total: 200,
                        grant: 2000,
                        remarks: "High",
                      },
                    },
                    opex: {
                      year1: {
                        description: "Server",
                        cost: 500,
                        qty: 1,
                        total: 500,
                        grant: 3000,
                        remarks: "Annual",
                      },
                      year2: {
                        description: "Extended",
                        cost: 300,
                        qty: 1,
                        total: 300,
                        grant: 5000,
                        remarks: "2",
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    incomeEstimate: {
      rows: [
        {
          id: `row-${Date.now()}`,
          serviceOffering: "",
          year1: {
            estimatedTransactions: "",
            userCharge: "",
            estimatedRevenue: "",
          },
          year2: {
            estimatedTransactions: "",
            userCharge: "",
            estimatedRevenue: "",
          },
        },
      ],
    },
  }), []);

  // FIXED: Initialize with stable reference
  const [localFormData, setLocalFormData] = useState(() => {
    const defaultData = getDefaultFormData();
    
    if (formData && Object.keys(formData).length > 0) {
      return {
        tables: formData.tables && formData.tables.length > 0 ? formData.tables : defaultData.tables,
        equipmentOverhead: {
          tables: formData.equipmentOverhead?.tables && formData.equipmentOverhead.tables.length > 0 
            ? formData.equipmentOverhead.tables 
            : defaultData.equipmentOverhead.tables
        },
        incomeEstimate: {
          rows: formData.incomeEstimate?.rows && formData.incomeEstimate.rows.length > 0
            ? formData.incomeEstimate.rows
            : defaultData.incomeEstimate.rows
        }
      };
    }
    
    return defaultData;
  });

  // FIXED: Only sync with parent on initial load, not on every change
  useEffect(() => {
    if (!isInitializedRef.current && formData && Object.keys(formData).length > 0) {
      const hasValidTables = formData.tables && Array.isArray(formData.tables) && formData.tables.length > 0;
      const hasValidEquipment = formData.equipmentOverhead?.tables && Array.isArray(formData.equipmentOverhead.tables);
      const hasValidIncome = formData.incomeEstimate?.rows && Array.isArray(formData.incomeEstimate.rows);

      if (hasValidTables || hasValidEquipment || hasValidIncome) {
        console.log("🔍 Initial data sync from parent");
        
        setLocalFormData(prev => {
          const defaultData = getDefaultFormData();
          return {
            tables: hasValidTables ? formData.tables : prev.tables || defaultData.tables,
            equipmentOverhead: {
              tables: hasValidEquipment ? formData.equipmentOverhead.tables : prev.equipmentOverhead?.tables || defaultData.equipmentOverhead.tables
            },
            incomeEstimate: {
              rows: hasValidIncome ? formData.incomeEstimate.rows : prev.incomeEstimate?.rows || defaultData.incomeEstimate.rows
            }
          };
        });
        
        isInitializedRef.current = true;
      }
    }
  }, []); // FIXED: Empty dependency array to only run once

  // FIXED: Debounced notification to parent
  const debouncedLocalFormData = useDebounce(localFormData, 300);

  // FIXED: Memoized notification function with comparison
  const notifyParent = useCallback((data) => {
    if (!onFormDataChange) return;

    const budgetTables = data.tables || [];
    const equipmentTables = data.equipmentOverhead?.tables || [];
    
    const capex0Sum = sumAllCapexYear0(budgetTables) + sumAllCapexYear0(equipmentTables);
    
    const opexYear1Sum = budgetTables.reduce((sum, t) => sum + sumTableGrantsByType(t).opexYear1, 0) +
                        equipmentTables.reduce((sum, t) => sum + sumTableGrantsByType(t).opexYear1, 0);
    
    const opexYear2Sum = budgetTables.reduce((sum, t) => sum + sumTableGrantsByType(t).opexYear2, 0) +
                        equipmentTables.reduce((sum, t) => sum + sumTableGrantsByType(t).opexYear2, 0);

    const newDataToSend = {
      ...data,
      grantTotals: {
        capexYear0: capex0Sum,
        opexYear1: opexYear1Sum,
        opexYear2: opexYear2Sum,
      },
    };

    // FIXED: Only notify if data actually changed
    const dataStringified = JSON.stringify(newDataToSend);
    if (lastNotifiedDataRef.current !== dataStringified) {
      console.log("🔍 Notifying parent of changes:", {
        capexYear0: capex0Sum,
        opexYear1: opexYear1Sum,
        opexYear2: opexYear2Sum,
      });
      
      onFormDataChange(newDataToSend);
      lastNotifiedDataRef.current = dataStringified;
    }
  }, [onFormDataChange]);

  // FIXED: Use debounced data for parent notification
  useEffect(() => {
    if (isInitializedRef.current) {
      notifyParent(debouncedLocalFormData);
    }
  }, [debouncedLocalFormData, notifyParent]);

  // FIXED: Stable update function with useCallback
  const updateLocalData = useCallback((updater) => {
    setLocalFormData(prev => {
      if (typeof updater === 'function') {
        return updater(prev);
      }
      return { ...prev, ...updater };
    });
  }, []);

  // Helper function to get current tab data
  const getCurrentTabData = useCallback(() => {
    if (activeTab === "budgetEstimate") {
      return { tables: localFormData.tables || [] };
    } else if (activeTab === "equipmentOverhead") {
      return localFormData.equipmentOverhead || { tables: [] };
    } else {
      return localFormData.incomeEstimate || { rows: [] };
    }
  }, [activeTab, localFormData]);

  // FIXED: Stable update functions with useCallback
  const updateServiceOfferingName = useCallback((offeringId, newName) => {
    updateLocalData(prev => {
      if (activeTab === "budgetEstimate") {
        return {
          ...prev,
          tables: prev.tables.map((t) => ({
            ...t,
            serviceOfferings: t.serviceOfferings.map((o) =>
              o.id === offeringId ? { ...o, name: newName } : o
            ),
          })),
        };
      } else if (activeTab === "equipmentOverhead") {
        return {
          ...prev,
          equipmentOverhead: {
            ...prev.equipmentOverhead,
            tables: prev.equipmentOverhead.tables.map((t) => ({
              ...t,
              serviceOfferings: t.serviceOfferings.map((o) =>
                o.id === offeringId ? { ...o, name: newName } : o
              ),
            })),
          },
        };
      }
      return prev;
    });
  }, [activeTab, updateLocalData]);

  const addServiceOffering = useCallback(() => {
    const newOffering = {
      id: `offering-${Date.now()}`,
      name: "New Service Offering",
      items: [],
    };

    updateLocalData(prev => {
      if (activeTab === "budgetEstimate") {
        return {
          ...prev,
          tables: prev.tables.map((table) => ({
            ...table,
            serviceOfferings: [...table.serviceOfferings, newOffering],
          })),
        };
      } else if (activeTab === "equipmentOverhead") {
        return {
          ...prev,
          equipmentOverhead: {
            ...prev.equipmentOverhead,
            tables: prev.equipmentOverhead.tables.map((table) => ({
              ...table,
              serviceOfferings: [...table.serviceOfferings, newOffering],
            })),
          },
        };
      }
      return prev;
    });
  }, [activeTab, updateLocalData]);

  const addItem = useCallback((offeringId) => {
    const newItem = {
      id: `item-${Date.now()}`,
      description: "New Item",
      financials: {
        capex: {
          year0: {
            description: "",
            cost: 0,
            qty: 0,
            total: 0,
            grant: 0,
            remarks: "",
          },
        },
        opex: {
          year1: {
            description: "",
            cost: 0,
            qty: 0,
            total: 0,
            grant: 0,
            remarks: "",
          },
          year2: {
            description: "",
            cost: 0,
            qty: 0,
            total: 0,
            grant: 0,
            remarks: "",
          },
        },
      },
    };

    updateLocalData(prev => {
      if (activeTab === "budgetEstimate") {
        return {
          ...prev,
          tables: prev.tables.map((table) => ({
            ...table,
            serviceOfferings: table.serviceOfferings.map((offering) =>
              offering.id === offeringId
                ? { ...offering, items: [...offering.items, newItem] }
                : offering
            ),
          })),
        };
      } else if (activeTab === "equipmentOverhead") {
        return {
          ...prev,
          equipmentOverhead: {
            ...prev.equipmentOverhead,
            tables: prev.equipmentOverhead.tables.map((table) => ({
              ...table,
              serviceOfferings: table.serviceOfferings.map((offering) =>
                offering.id === offeringId
                  ? { ...offering, items: [...offering.items, newItem] }
                  : offering
              ),
            })),
          },
        };
      }
      return prev;
    });
  }, [activeTab, updateLocalData]);

  const updateField = useCallback((offeringId, itemId, period, year, field, value) => {
    updateLocalData(prev => {
      const updateTables = (tables) => 
        tables.map((table) => ({
          ...table,
          serviceOfferings: table.serviceOfferings.map((offering) =>
            offering.id === offeringId
              ? {
                  ...offering,
                  items: offering.items.map((item) =>
                    item.id === itemId
                      ? {
                          ...item,
                          financials: {
                            ...item.financials,
                            [period]: {
                              ...item.financials[period],
                              [year]: {
                                ...item.financials[period][year],
                                [field]: value,
                                ...(field === "cost" || field === "qty"
                                  ? {
                                      total:
                                        (field === "cost"
                                          ? value
                                          : item.financials[period][year]
                                              .cost) *
                                        (field === "qty"
                                          ? value
                                          : item.financials[period][year].qty),
                                    }
                                  : {}),
                              },
                            },
                          },
                        }
                      : item
                  ),
                }
              : offering
          ),
        }));

      if (activeTab === "budgetEstimate") {
        return {
          ...prev,
          tables: updateTables(prev.tables),
        };
      } else if (activeTab === "equipmentOverhead") {
        return {
          ...prev,
          equipmentOverhead: {
            ...prev.equipmentOverhead,
            tables: updateTables(prev.equipmentOverhead.tables),
          },
        };
      }
      return prev;
    });
  }, [activeTab, updateLocalData]);

  const deleteItem = useCallback((offeringId, itemId) => {
    updateLocalData(prev => {
      const updateTables = (tables) =>
        tables.map((table) => ({
          ...table,
          serviceOfferings: table.serviceOfferings.map((offering) =>
            offering.id === offeringId
              ? {
                  ...offering,
                  items: offering.items.filter((item) => item.id !== itemId),
                }
              : offering
          ),
        }));

      if (activeTab === "budgetEstimate") {
        return {
          ...prev,
          tables: updateTables(prev.tables),
        };
      } else if (activeTab === "equipmentOverhead") {
        return {
          ...prev,
          equipmentOverhead: {
            ...prev.equipmentOverhead,
            tables: updateTables(prev.equipmentOverhead.tables),
          },
        };
      }
      return prev;
    });
  }, [activeTab, updateLocalData]);

  // Income Estimate functions
  const addIncomeRow = useCallback(() => {
    updateLocalData(prev => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: [
          ...prev.incomeEstimate.rows,
          {
            id: `row-${Date.now()}`,
            serviceOffering: "",
            year1: {
              estimatedTransactions: "",
              userCharge: "",
              estimatedRevenue: "",
            },
            year2: {
              estimatedTransactions: "",
              userCharge: "",
              estimatedRevenue: "",
            },
          },
        ],
      },
    }));
  }, [updateLocalData]);

  const updateIncomeField = useCallback((rowId, year, field, value) => {
    updateLocalData(prev => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: prev.incomeEstimate.rows.map((row) =>
          row.id === rowId
            ? {
                ...row,
                [year]: {
                  ...row[year],
                  [field]: value,
                  ...(field === "estimatedTransactions" ||
                  field === "userCharge"
                    ? {
                        estimatedRevenue:
                          (Number(
                            field === "estimatedTransactions"
                              ? value
                              : row[year].estimatedTransactions
                          ) || 0) *
                          (parseFloat(
                            field === "userCharge"
                              ? value
                              : row[year].userCharge
                          ) || 0),
                      }
                    : {}),
                },
              }
            : row
        ),
      },
    }));
  }, [updateLocalData]);

  const updateIncomeServiceOffering = useCallback((rowId, value) => {
    updateLocalData(prev => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: prev.incomeEstimate.rows.map((row) =>
          row.id === rowId ? { ...row, serviceOffering: value } : row
        ),
      },
    }));
  }, [updateLocalData]);

  const deleteIncomeRow = useCallback((rowId) => {
    updateLocalData(prev => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: prev.incomeEstimate.rows.filter(
          (row) => row.id !== rowId
        ),
      },
    }));
  }, [updateLocalData]);

  // FIXED: Stable tabs array
  const tabs = [
    {
      id: "budgetEstimate",
      label: "Budget Estimate (Service Offering-wise)",
      icon: Calculator,
    },
    {
      id: "equipmentOverhead",
      label: "Equipment/Manpower/Overheads (Used Across Services)",
      icon: Settings,
    },
    { id: "incomeEstimate", label: "Income Estimate", icon: TrendingUp },
  ];

  const currentData = getCurrentTabData();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Tabs */}
      <div className="max-w-[80vw] mx-auto px-6 py-6">
        <div className="bg-white rounded-2xl shadow-xl border border-gray-200">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === id
                      ? "border-yellow-400 text-yellow-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-3">
            {/* Add Service Offering Button */}
            {activeTab !== "incomeEstimate" && (
              <div className="mb-4">
                <button
                  onClick={addServiceOffering}
                  className="flex items-center space-x-2 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-3 py-2 rounded-xl font-semibold hover:from-yellow-500 hover:to-yellow-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Plus className="w-5 h-5" />
                  <span>Add Service Offering</span>
                </button>
              </div>
            )}

            {/* Service Offerings or Income Estimate Table */}
            {activeTab === "incomeEstimate" ? (
              <div className="w-full overflow-x-auto">
                <div className="mb-4">
                  <button
                    onClick={addIncomeRow}
                    className="flex items-center space-x-2 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-3 py-2 rounded-xl font-semibold hover:from-yellow-500 hover:to-yellow-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Plus className="w-5 h-5" />
                    <span>Add Service Offering</span>
                  </button>
                </div>
                <table className="min-w-[1100px] w-full border-separate border-spacing-0">
                  <thead>
                    <tr>
                      <th
                        className="bg-yellow-100 text-gray-900 px-6 py-3 text-left text-xs font-bold uppercase tracking-wider border-r border-white"
                        rowSpan={2}
                        style={{ minWidth: 200 }}
                      >
                        Service Offering
                      </th>
                      <th
                        className="bg-orange-100 text-gray-900 px-4 py-3 text-center text-xs font-bold uppercase tracking-wider border-b-2 border-orange-300"
                        colSpan={3}
                      >
                        First Year
                      </th>
                      <th
                        className="bg-green-100 text-gray-900 px-4 py-3 text-center text-xs font-bold uppercase tracking-wider border-b-2 border-green-300"
                        colSpan={3}
                      >
                        Second Year
                      </th>
                      <th className="bg-gray-100"></th>
                    </tr>
                    <tr>
                      <th className="bg-orange-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-orange-200">
                        Estimated Transactions
                      </th>
                      <th className="bg-orange-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-orange-200">
                        User Charge Per Transaction
                      </th>
                      <th className="bg-orange-50 px-3 py-2 text-xs font-semibold text-gray-700">
                        Estimated Revenue
                      </th>
                      <th className="bg-green-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-green-200">
                        Estimated Transactions
                      </th>
                      <th className="bg-green-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-green-200">
                        User Charge Per Transaction
                      </th>
                      <th className="bg-green-50 px-3 py-2 text-xs font-semibold text-gray-700">
                        Estimated Revenue
                      </th>
                      <th className="bg-gray-100"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {currentData.rows?.map((row) => (
                      <tr key={row.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3">
                          <input
                            type="text"
                            value={row.serviceOffering}
                            onChange={(e) =>
                              updateIncomeServiceOffering(
                                row.id,
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                            placeholder="Service Offering"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year1.estimatedTransactions}
                            onChange={(e) =>
                              updateIncomeField(
                                row.id,
                                "year1",
                                "estimatedTransactions",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
                            placeholder="Transactions"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="text"
                            value={row.year1.userCharge}
                            onChange={(e) =>
                              updateIncomeField(
                                row.id,
                                "year1",
                                "userCharge",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
                            placeholder="Charge"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year1.estimatedRevenue}
                            readOnly
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded bg-orange-50 font-semibold text-orange-800"
                            placeholder="Revenue"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year2.estimatedRevenue}
                            readOnly
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded bg-green-50 font-semibold text-green-800"
                            placeholder="Revenue"
                          />
                        </td>
                        <td className="px-3 py-3 text-center">
                          <button
                            onClick={() => deleteIncomeRow(row.id)}
                            className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors"
                            type="button"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              // Service Offerings Tables
              currentData.tables?.map((table) => (
                <div key={table.id} className="space-y-8">
                  {table.serviceOfferings?.map((offering) => (
                    <div
                      key={offering.id}
                      className="rounded-2xl overflow-hidden"
                    >
                      {/* Service Offering Header */}
                      <div className="bg-gradient-to-r from-gray-100 to-gray-100 px-5 py-4 border-b border-gray-200">
                        <div className="flex items-center justify-between">
                          <input
                            type="text"
                            value={offering.name}
                            onChange={(e) => {
                              updateServiceOfferingName(offering.id, e.target.value);
                            }}
                            className="text-2xl font-bold text-gray-900 bg-transparent border-none focus:outline-none focus:ring-0"
                          />
                          <button
                            onClick={() => addItem(offering.id)}
                            className="flex items-center space-x-2 bg-blue-600 text-white px-3 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-md"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add Item</span>
                          </button>
                        </div>
                      </div>

                      {/* Table */}
                      <div className="w-full overflow-x-auto">
                        <table className="min-w-[1200px] w-full border-separate border-spacing-0">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider sticky left-0 bg-gray-50 border-r border-gray-200 z-10">
                                Description
                              </th>
                              <th
                                className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b-2 border-yellow-400"
                                colSpan="6"
                              >
                                Capex (Year 0)
                              </th>
                              <th
                                className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b-2 border-blue-400"
                                colSpan="6"
                              >
                                Opex (Year 1)
                              </th>
                              <th
                                className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b-2 border-green-400"
                                colSpan="6"
                              >
                                Opex (Year 2)
                              </th>
                              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                            </tr>
                            <tr className="bg-gray-50">
                              <th className="px-6 py-2 text-xs font-medium text-gray-500 sticky left-0 bg-gray-50 border-r border-gray-200 z-10"></th>
                              {/* Capex Headers */}
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-l border-yellow-200">
                                Item Description
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Cost
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Qty
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Total
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Grant
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-r border-yellow-200">
                                Remarks
                              </th>
                              {/* Opex Y1 Headers */}
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-l border-blue-200">
                                Item Description
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Cost
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Qty
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Total
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Grant
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-r border-blue-200">
                                Remarks
                              </th>
                              {/* Opex Y2 Headers */}
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-l border-green-200">
                                Item Description
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Cost
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Qty
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Total
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Grant
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-r border-green-200">
                                Remarks
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600"></th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {offering.items?.map((item) => (
                              <tr key={item.id} className="hover:bg-gray-50">
                                <td className="px-3 py-3 sticky left-0 bg-white border-r border-gray-200 z-10">
                                  <input
                                    type="text"
                                    value={item.description}
                                    onChange={(e) => {
                                      const newDesc = e.target.value;
                                      updateLocalData(prev => {
                                        if (activeTab === "budgetEstimate") {
                                          return {
                                            ...prev,
                                            tables: prev.tables.map((t) => ({
                                              ...t,
                                              serviceOfferings: t.serviceOfferings.map((o) =>
                                                o.id === offering.id
                                                  ? {
                                                      ...o,
                                                      items: o.items.map((i) =>
                                                        i.id === item.id
                                                          ? { ...i, description: newDesc }
                                                          : i
                                                      ),
                                                    }
                                                  : o
                                              ),
                                            })),
                                          };
                                        } else if (activeTab === "equipmentOverhead") {
                                          return {
                                            ...prev,
                                            equipmentOverhead: {
                                              ...prev.equipmentOverhead,
                                              tables: prev.equipmentOverhead.tables.map((t) => ({
                                                ...t,
                                                serviceOfferings: t.serviceOfferings.map((o) =>
                                                  o.id === offering.id
                                                    ? {
                                                        ...o,
                                                        items: o.items.map((i) =>
                                                          i.id === item.id
                                                            ? { ...i, description: newDesc }
                                                            : i
                                                        ),
                                                      }
                                                    : o
                                                ),
                                              })),
                                            },
                                          };
                                        }
                                        return prev;
                                      });
                                    }}
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>

                                {/* Capex Year 0 */}
                                <td className="px-3 py-3 border-l border-yellow-200">
                                  <input
                                    type="text"
                                    value={item.financials?.capex?.year0?.description || ""}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "description",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.capex?.year0?.cost || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "cost",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.capex?.year0?.qty || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "qty",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-24 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.capex?.year0?.total || 0}
                                    readOnly
                                    className="w-full min-w-24 px-3 py-2 text-sm border border-gray-300 rounded bg-yellow-50 font-semibold text-yellow-800"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.capex?.year0?.grant || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "grant",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-24 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3 border-r border-yellow-200">
                                  <input
                                    type="text"
                                    value={item.financials?.capex?.year0?.remarks || ""}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "remarks",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-40 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>

                                {/* Opex Year 1 */}
                                <td className="px-3 py-3 border-l border-blue-200">
                                  <input
                                    type="text"
                                    value={item.financials?.opex?.year1?.description || ""}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "description",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year1?.cost || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "cost",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year1?.qty || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "qty",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year1?.total || 0}
                                    readOnly
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded bg-blue-50 font-semibold text-blue-800"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year1?.grant || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "grant",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3 border-r border-blue-200">
                                  <input
                                    type="text"
                                    value={item.financials?.opex?.year1?.remarks || ""}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "remarks",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-40 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>

                                {/* Opex Year 2 */}
                                <td className="px-3 py-3 border-l border-green-200">
                                  <input
                                    type="text"
                                    value={item.financials?.opex?.year2?.description || ""}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "description",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year2?.cost || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "cost",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year2?.qty || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "qty",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year2?.total || 0}
                                    readOnly
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded bg-green-50 font-semibold text-green-800"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials?.opex?.year2?.grant || 0}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "grant",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3 border-r border-green-200">
                                  <input
                                    type="text"
                                    value={item.financials?.opex?.year2?.remarks || ""}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "remarks",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-40 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>

                                {/* Actions */}
                                <td className="px-3 py-3 text-center">
                                  <button
                                    onClick={() => deleteItem(offering.id, item.id)}
                                    className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Empty State */}
                      {(!offering.items || offering.items.length === 0) && (
                        <div className="text-center py-12 text-gray-500">
                          <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                          <p className="text-lg font-medium">No items added yet</p>
                          <p className="text-sm">Click "Add Item" to get started</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Grand Totals */}
        <div className="mt-6 p-6 bg-yellow-50 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold text-yellow-900 mb-4 flex items-center gap-2">
            Grand Total of Funds Requested
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Capex */}
            <div className="flex flex-col bg-yellow-100 rounded-md p-4 border border-yellow-200">
              <span className="text-gray-600 font-medium mb-1">Capex (Year 0)</span>
              <span className="text-yellow-700 text-xl font-bold">
                ₹{(
                  sumAllCapexYear0(localFormData.tables || []) +
                  sumAllCapexYear0(localFormData.equipmentOverhead?.tables || [])
                ).toLocaleString()}
              </span>
            </div>

            {/* Opex Year 1 */}
            <div className="flex flex-col bg-blue-50 rounded-md p-4 border border-blue-100">
              <span className="text-gray-600 font-medium mb-1">Opex (Year 1)</span>
              <span className="text-blue-700 text-xl font-bold">
                ₹{(
                  (localFormData.tables || []).reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear1,
                    0
                  ) +
                  (localFormData.equipmentOverhead?.tables || []).reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear1,
                    0
                  )
                ).toLocaleString()}
              </span>
            </div>

            {/* Opex Year 2 */}
            <div className="flex flex-col bg-green-50 rounded-md p-4 border border-green-100">
              <span className="text-gray-600 font-medium mb-1">Opex (Year 2)</span>
              <span className="text-green-700 text-xl font-bold">
                ₹{(
                  (localFormData.tables || []).reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear2,
                    0
                  ) +
                  (localFormData.equipmentOverhead?.tables || []).reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear2,
                    0
                  )
                ).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetEstimate;