import React, { useState, useEffect, useRef, useCallback } from "react";
import { Upload } from "lucide-react";

const ProjectDetails = ({ initialFormData = {}, onFormDataChange }) => {
  
  const [projectDetails, setProjectDetails] = useState(() => ({
    ganttChart: initialFormData?.ganttChart || null,
    ganttChartPreview: initialFormData?.ganttChartPreview || null,
    dpr: initialFormData?.dpr || null,
    dprPreview: initialFormData?.dprPreview || null,
    presentation: initialFormData?.presentation || null,
    presentationPreview: initialFormData?.presentationPreview || null,
  }));

  
  const isInitialMount = useRef(true);


  const handleFileUpload = useCallback((field, file) => {
    setProjectDetails((prev) => ({
      ...prev,
      [field]: file,
    }));
  }, []);


  useEffect(() => {
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    onFormDataChange(projectDetails);
  }, [projectDetails, onFormDataChange]);

  const getFileName = (field) => {
    const file = projectDetails[field];
    const preview = projectDetails[`${field}Preview`];
    
    if (file instanceof File) {
      return file.name;
    }
    if (preview && preview.url) {
      const urlParts = preview.url.split('/');
      return urlParts[urlParts.length - 1];
    }
    return null;
  };


  const FileUploadField = useCallback(
    ({ label, field, accept, placeholder }) => {
      const file = projectDetails[field];
      const preview = projectDetails[`${field}Preview`];
      const hasFile = !!(file || preview);

      const getDisplayName = () => {
        if (file instanceof File) return file.name;
        if (preview && preview.url) {
          const urlParts = preview.url.split('/');
          return urlParts[urlParts.length - 1];
        }
        return null;
      };

      const fileName = getDisplayName();

      return (
        <div className="group">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            {label}
            <span className="text-red-500 ml-1">*</span>
          </label>
          <div className="relative">
            <input
              type="file"
              accept={accept}
              onChange={(e) => {
                const selectedFile = e.target.files[0];
                if (selectedFile) {
                  console.log(`🔍 ${field} file selected:`, selectedFile.name);
                  handleFileUpload(field, selectedFile);
                }
              }}
              className="hidden"
              id={field}
            />
            
            {!hasFile ? (
              // Upload area when no file
              <label
                htmlFor={field}
                className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 cursor-pointer flex items-center justify-center bg-gray-50 hover:bg-gray-100"
              >
                <Upload className="w-5 h-5 mr-2 text-gray-400" />
                <span className="text-gray-600">
                  {placeholder}
                </span>
              </label>
            ) : (
              // File status area when file exists
              <div className="w-full px-4 py-3 border border-green-300 rounded-lg bg-green-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Upload className="w-5 h-5 mr-2 text-green-500" />
                    <div>
                      <span className="text-green-700 font-medium">
                        {fileName || 'File uploaded'}
                      </span>
                      <div className="text-xs text-green-600 mt-1">
                        {file instanceof File ? 'New file selected' : 'Previously uploaded'}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {/* View current file button */}
                    {preview && preview.url && (
                      <a
                        href={preview.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded hover:bg-blue-200 transition-colors"
                      >
                        View current
                      </a>
                    )}
                    {/* Replace file button */}
                    <label
                      htmlFor={field}
                      className="text-xs bg-yellow-100 text-yellow-700 px-3 py-1 rounded cursor-pointer hover:bg-yellow-200 transition-colors"
                    >
                      Replace file
                    </label>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    },
    [handleFileUpload, projectDetails]
  );

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">9</span>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                Project Documentation
              </h2>
              <p className="text-gray-600">Upload required project files</p>
            </div>
          </div>

          <div className="space-y-6">
            <FileUploadField
              label="Upload GANTT/PERT Chart (overall timeline for completing the Project shall be restricted to 24-weeks from the date of awarding the work)"
              field="ganttChart"
              accept=".pdf,.ppt,.pptx,.doc,.docx,.xls,.xlsx"
              placeholder="Click to upload file (PDF, PPT, Word, Excel)"
            />

            <FileUploadField
              label="Project Presentation"
              field="presentation"
              accept=".pdf,.ppt,.pptx"
              placeholder="Click to upload file (PDF, PPT)"
            />

            <FileUploadField
              label="Detailed Project Report (DPR)"
              field="dpr"
              accept=".pdf,.ppt,.pptx,.doc,.docx"
              placeholder="Click to upload file (PDF, PPT, Word)"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(ProjectDetails);