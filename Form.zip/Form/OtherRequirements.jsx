import React, { useState, useMemo } from "react";
import {
  Plus,
  Trash2,
  Calculator,
  FileText,
  Settings,
  TrendingUp,
} from "lucide-react";

// Utility: sum grants for a single offering, separated by type/year
function sumGrantsByType(offering) {
  let capexYear0 = 0,
    opexYear1 = 0,
    opexYear2 = 0;
  for (const item of offering.items) {
    capexYear0 += Number(item.financials.capex?.year0?.grant || 0);
    opexYear1 += Number(item.financials.opex?.year1?.grant || 0);
    opexYear2 += Number(item.financials.opex?.year2?.grant || 0);
  }
  return { capexYear0, opexYear1, opexYear2 };
}

// Utility: sum grants for a table (all offerings), separated by type/year
function sumTableGrantsByType(table) {
  return table.serviceOfferings.reduce(
    (acc, offering) => {
      const sums = sumGrantsByType(offering);
      acc.capexYear0 += sums.capexYear0;
      acc.opexYear1 += sums.opexYear1;
      acc.opexYear2 += sums.opexYear2;
      return acc;
    },
    { capexYear0: 0, opexYear1: 0, opexYear2: 0 }
  );
}

// Utility: sum all capex-year0 grants across all tables (for passing elsewhere)
function sumAllCapexYear0(tables) {
  return tables.reduce(
    (sum, table) => sum + sumTableGrantsByType(table).capexYear0,
    0
  );
}

const BudgetEstimateForm = ({ onGrantTotalsChange }) => {
  const [activeTab, setActiveTab] = useState("budgetEstimate");
  const [formData, setFormData] = useState({
    budgetEstimate: {
      tables: [
        {
          id: "table-1",
          title: "Budget Estimate of Service",
          serviceOfferings: [
            {
              id: "offering-1",
              name: "Enter Service Name...",
              items: [
                {
                  id: "item-1",
                  description: "Smart Classroom",
                  financials: {
                    capex: {
                      year0: {
                        description: "Smart Board",
                        cost: 50,
                        qty: 2,
                        total: 100,
                        grant: 1000,
                        remarks: "Includes",
                      },
                    },
                    opex: {
                      year1: {
                        description: "License",
                        cost: 100,
                        qty: 1,
                        total: 100,
                        grant: 2000,
                        remarks: "Partial",
                      },
                      year2: {
                        description: "Maintenance",
                        cost: 200,
                        qty: 1,
                        total: 200,
                        grant: 3000,
                        remarks: "Standard",
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    equipmentOverhead: {
      tables: [
        {
          id: "table-2",
          title: "Equipment Overhead",
          serviceOfferings: [
            {
              id: "offering-2",
              name: "IT Infrastructure",
              items: [
                {
                  id: "item-2",
                  description: "Server Setup",
                  financials: {
                    capex: {
                      year0: {
                        description: "Dell PowerEdge Server",
                        cost: 200,
                        qty: 1,
                        total: 200,
                        grant: 2000,
                        remarks: "High",
                      },
                    },
                    opex: {
                      year1: {
                        description: "Server",
                        cost: 500,
                        qty: 1,
                        total: 500,
                        grant: 3000,
                        remarks: "Annual",
                      },
                      year2: {
                        description: "Extended",
                        cost: 300,
                        qty: 1,
                        total: 300,
                        grant: 5000,
                        remarks: "2",
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    incomeEstimate: {
      rows: [
        {
          id: `row-${Date.now()}`,
          serviceOffering: "",
          year1: {
            estimatedTransactions: "",
            userCharge: "",
            estimatedRevenue: "",
          },
          year2: {
            estimatedTransactions: "",
            userCharge: "",
            estimatedRevenue: "",
          },
        },
      ],
    },
  });

  // Calculate all totals using useMemo for performance
  const grantTotals = useMemo(() => {
    // Budget Estimate
    const budgetTables = formData.budgetEstimate.tables || [];
    const budgetTableTotals = budgetTables.map(sumTableGrantsByType);
    // const budgetEstimateTotal = budgetTableTotals.reduce((a, b) => a + b, 0);
    const budgetEstimateTotal = budgetTableTotals.reduce(
      (acc, curr) => ({
        capexYear0: acc.capexYear0 + curr.capexYear0,
        opexYear1: acc.opexYear1 + curr.opexYear1,
        opexYear2: acc.opexYear2 + curr.opexYear2,
      }),
      { capexYear0: 0, opexYear1: 0, opexYear2: 0 }
    );

    // Equipment Overhead
    const equipmentTables = formData.equipmentOverhead.tables || [];
    const equipmentTableTotals = equipmentTables.map(sumTableGrantsByType);
    // const equipmentOverheadTotal = equipmentTableTotals.reduce(
    //   (a, b) => a + b,
    //   0
    // );
    const equipmentOverheadTotal = equipmentTableTotals.reduce(
      (acc, curr) => ({
        capexYear0: acc.capexYear0 + curr.capexYear0,
        opexYear1: acc.opexYear1 + curr.opexYear1,
        opexYear2: acc.opexYear2 + curr.opexYear2,
      }),
      { capexYear0: 0, opexYear1: 0, opexYear2: 0 }
    );

    // Grand Total
    // const grandTotal = budgetEstimateTotal + equipmentOverheadTotal;
    const grandTotal = {
      capexYear0:
        budgetEstimateTotal.capexYear0 + equipmentOverheadTotal.capexYear0,
      opexYear1:
        budgetEstimateTotal.opexYear1 + equipmentOverheadTotal.opexYear1,
      opexYear2:
        budgetEstimateTotal.opexYear2 + equipmentOverheadTotal.opexYear2,
    };

    return {
      budgetTableTotals,
      budgetEstimateTotal,
      equipmentTableTotals,
      equipmentOverheadTotal,
      grandTotal,
    };
  }, [formData]);

  // Optionally pass totals to parent for later use
  React.useEffect(() => {
    if (onGrantTotalsChange) {
      onGrantTotalsChange(grantTotals);
    }
  }, [grantTotals, onGrantTotalsChange]);

  const addServiceOffering = () => {
    const newOffering = {
      id: `offering-${Date.now()}`,
      name: "New Service Offering",
      items: [],
    };

    setFormData((prev) => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        tables: prev[activeTab].tables.map((table) => ({
          ...table,
          serviceOfferings: [...table.serviceOfferings, newOffering],
        })),
      },
    }));
  };

  const addItem = (offeringId) => {
    const newItem = {
      id: `item-${Date.now()}`,
      description: "New Item",
      financials: {
        capex: {
          year0: {
            description: "",
            cost: 0,
            qty: 0,
            total: 0,
            grant: 0,
            remarks: "",
          },
        },
        opex: {
          year1: {
            description: "",
            cost: 0,
            qty: 0,
            total: 0,
            grant: 0,
            remarks: "",
          },
          year2: {
            description: "",
            cost: 0,
            qty: 0,
            total: 0,
            grant: 0,
            remarks: "",
          },
        },
      },
    };

    setFormData((prev) => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        tables: prev[activeTab].tables.map((table) => ({
          ...table,
          serviceOfferings: table.serviceOfferings.map((offering) =>
            offering.id === offeringId
              ? { ...offering, items: [...offering.items, newItem] }
              : offering
          ),
        })),
      },
    }));
  };

  const updateField = (offeringId, itemId, period, year, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        tables: prev[activeTab].tables.map((table) => ({
          ...table,
          serviceOfferings: table.serviceOfferings.map((offering) =>
            offering.id === offeringId
              ? {
                  ...offering,
                  items: offering.items.map((item) =>
                    item.id === itemId
                      ? {
                          ...item,
                          financials: {
                            ...item.financials,
                            [period]: {
                              ...item.financials[period],
                              [year]: {
                                ...item.financials[period][year],
                                [field]: value,
                                ...(field === "cost" || field === "qty"
                                  ? {
                                      total:
                                        (field === "cost"
                                          ? value
                                          : item.financials[period][year]
                                              .cost) *
                                        (field === "qty"
                                          ? value
                                          : item.financials[period][year].qty),
                                    }
                                  : {}),
                              },
                            },
                          },
                        }
                      : item
                  ),
                }
              : offering
          ),
        })),
      },
    }));
  };

  const deleteItem = (offeringId, itemId) => {
    setFormData((prev) => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        tables: prev[activeTab].tables.map((table) => ({
          ...table,
          serviceOfferings: table.serviceOfferings.map((offering) =>
            offering.id === offeringId
              ? {
                  ...offering,
                  items: offering.items.filter((item) => item.id !== itemId),
                }
              : offering
          ),
        })),
      },
    }));
  };

  // Income Estimate handlers
  const addIncomeRow = () => {
    setFormData((prev) => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: [
          ...prev.incomeEstimate.rows,
          {
            id: `row-${Date.now()}`,
            serviceOffering: "",
            year1: {
              estimatedTransactions: "",
              userCharge: "",
              estimatedRevenue: "",
            },
            year2: {
              estimatedTransactions: "",
              userCharge: "",
              estimatedRevenue: "",
            },
          },
        ],
      },
    }));
  };

  const updateIncomeField = (rowId, year, field, value) => {
    setFormData((prev) => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: prev.incomeEstimate.rows.map((row) =>
          row.id === rowId
            ? {
                ...row,
                [year]: {
                  ...row[year],
                  [field]: value,
                  ...(field === "estimatedTransactions" ||
                  field === "userCharge"
                    ? {
                        estimatedRevenue:
                          (Number(
                            field === "estimatedTransactions"
                              ? value
                              : row[year].estimatedTransactions
                          ) || 0) *
                          (parseFloat(
                            field === "userCharge"
                              ? value
                              : row[year].userCharge
                          ) || 0),
                      }
                    : {}),
                },
              }
            : row
        ),
      },
    }));
  };

  const updateIncomeServiceOffering = (rowId, value) => {
    setFormData((prev) => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: prev.incomeEstimate.rows.map((row) =>
          row.id === rowId ? { ...row, serviceOffering: value } : row
        ),
      },
    }));
  };

  const deleteIncomeRow = (rowId) => {
    setFormData((prev) => ({
      ...prev,
      incomeEstimate: {
        ...prev.incomeEstimate,
        rows: prev.incomeEstimate.rows.filter((row) => row.id !== rowId),
      },
    }));
  };

  const tabs = [
    { id: "budgetEstimate", label: "Budget Estimate", icon: Calculator },
    { id: "equipmentOverhead", label: "Equipment Overhead", icon: Settings },
    {
      id: "incomeEstimate",
      label: "Income Estimate",
      icon: TrendingUp,
      disabled: false,
    },
  ];

  const currentData = formData[activeTab];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Tabs */}
      <div className="max-w-[80vw] mx-auto px-6 py-6">
        <div className="bg-white rounded-2xl shadow-xl border border-gray-200">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map(({ id, label, icon: Icon, disabled }) => (
                <button
                  key={id}
                  disabled={disabled}
                  onClick={() => !disabled && setActiveTab(id)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === id
                      ? "border-yellow-400 text-yellow-600"
                      : disabled
                      ? "border-transparent text-gray-400 cursor-not-allowed"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{label}</span>
                  {disabled && (
                    <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                      Coming Soon
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-3">
            {/* Add Service Offering Button */}
            {activeTab !== "incomeEstimate" && (
              <div className="mb-4">
                <button
                  onClick={addServiceOffering}
                  className="flex items-center space-x-2 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-3 py-2 rounded-xl font-semibold hover:from-yellow-500 hover:to-yellow-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Plus className="w-5 h-5" />
                  <span>Add Service Offering</span>
                </button>
              </div>
            )}

            {/* Service Offerings or Income Estimate Table */}
            {activeTab === "incomeEstimate" ? (
              <div className="w-full overflow-x-auto">
                <div className="mb-4">
                  <button
                    onClick={addIncomeRow}
                    className="flex items-center space-x-2 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-3 py-2 rounded-xl font-semibold hover:from-yellow-500 hover:to-yellow-600 transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Plus className="w-5 h-5" />
                    <span>Add Service Offering</span>
                  </button>
                </div>
                <table className="min-w-[1100px] w-full border-separate border-spacing-0">
                  <thead>
                    <tr>
                      <th
                        className="bg-yellow-100 text-gray-900 px-6 py-3 text-left text-xs font-bold uppercase tracking-wider border-r border-white"
                        rowSpan={2}
                        style={{ minWidth: 200 }}
                      >
                        Service Offering
                      </th>
                      <th
                        className="bg-orange-100 text-gray-900 px-4 py-3 text-center text-xs font-bold uppercase tracking-wider border-b-2 border-orange-300"
                        colSpan={3}
                      >
                        First Year
                      </th>
                      <th
                        className="bg-green-100 text-gray-900 px-4 py-3 text-center text-xs font-bold uppercase tracking-wider border-b-2 border-green-300"
                        colSpan={3}
                      >
                        Second Year
                      </th>
                      <th className="bg-gray-100"></th>
                    </tr>
                    <tr>
                      <th className="bg-orange-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-orange-200">
                        Estimated Transactions
                      </th>
                      <th className="bg-orange-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-orange-200">
                        User Charge Per Transaction
                      </th>
                      <th className="bg-orange-50 px-3 py-2 text-xs font-semibold text-gray-700">
                        Estimated Revenue
                      </th>
                      <th className="bg-green-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-green-200">
                        Estimated Transactions
                      </th>
                      <th className="bg-green-50 px-3 py-2 text-xs font-semibold text-gray-700 border-r border-green-200">
                        User Charge Per Transaction
                      </th>
                      <th className="bg-green-50 px-3 py-2 text-xs font-semibold text-gray-700">
                        Estimated Revenue
                      </th>
                      <th className="bg-gray-100"></th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {formData.incomeEstimate.rows.map((row) => (
                      <tr key={row.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3">
                          <input
                            type="text"
                            value={row.serviceOffering}
                            onChange={(e) =>
                              updateIncomeServiceOffering(
                                row.id,
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                            placeholder="Service Offering"
                          />
                        </td>
                        {/* First Year */}
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year1.estimatedTransactions}
                            onChange={(e) =>
                              updateIncomeField(
                                row.id,
                                "year1",
                                "estimatedTransactions",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
                            placeholder="Transactions"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="text"
                            value={row.year1.userCharge}
                            onChange={(e) =>
                              updateIncomeField(
                                row.id,
                                "year1",
                                "userCharge",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400"
                            placeholder="Charge"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year1.estimatedRevenue}
                            readOnly
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded bg-orange-50 font-semibold text-orange-800"
                            placeholder="Revenue"
                          />
                        </td>
                        {/* Second Year */}
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year2.estimatedTransactions}
                            onChange={(e) =>
                              updateIncomeField(
                                row.id,
                                "year2",
                                "estimatedTransactions",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-400"
                            placeholder="Transactions"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="text"
                            value={row.year2.userCharge}
                            onChange={(e) =>
                              updateIncomeField(
                                row.id,
                                "year2",
                                "userCharge",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-400"
                            placeholder="Charge"
                          />
                        </td>
                        <td className="px-3 py-3">
                          <input
                            type="number"
                            value={row.year2.estimatedRevenue}
                            readOnly
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded bg-green-50 font-semibold text-green-800"
                            placeholder="Revenue"
                          />
                        </td>
                        <td className="px-3 py-3 text-center">
                          <button
                            onClick={() => deleteIncomeRow(row.id)}
                            className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors"
                            type="button"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              currentData.tables.map((table) => (
                <div key={table.id} className="space-y-8">
                  {/* Service Offerings */}
                  {table.serviceOfferings.map((offering) => (
                    <div
                      key={offering.id}
                      className="rounded-2xl overflow-hidden"
                    >
                      {/* Service Offering Header */}
                      <div className="bg-gradient-to-r from-gray-100 to-gray-100 px-5 py-4 border-b border-gray-200">
                        <div className="flex items-center justify-between">
                          <input
                            type="text"
                            value={offering.name}
                            onChange={(e) => {
                              const newName = e.target.value;
                              setFormData((prev) => ({
                                ...prev,
                                [activeTab]: {
                                  ...prev[activeTab],
                                  tables: prev[activeTab].tables.map((t) => ({
                                    ...t,
                                    serviceOfferings: t.serviceOfferings.map(
                                      (o) =>
                                        o.id === offering.id
                                          ? { ...o, name: newName }
                                          : o
                                    ),
                                  })),
                                },
                              }));
                            }}
                            className="text-2xl font-bold text-gray-900 bg-transparent border-none focus:outline-none focus:ring-0"
                          />
                          <button
                            onClick={() => addItem(offering.id)}
                            className="flex items-center space-x-2 bg-blue-600 text-white px-3 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-md"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add Item</span>
                          </button>
                        </div>
                      </div>

                      {/* Table */}
                      <div className="w-full overflow-x-auto">
                        <table className="min-w-[1200px] w-full border-separate border-spacing-0">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider sticky left-0 bg-gray-50 border-r border-gray-200 z-10">
                                Description
                              </th>
                              <th
                                className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b-2 border-yellow-400"
                                colSpan="6"
                              >
                                Capex (Year 0)
                              </th>
                              <th
                                className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b-2 border-blue-400"
                                colSpan="6"
                              >
                                Opex (Year 1)
                              </th>
                              <th
                                className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-b-2 border-green-400"
                                colSpan="6"
                              >
                                Opex (Year 2)
                              </th>
                              <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider"></th>
                            </tr>
                            <tr className="bg-gray-50">
                              <th className="px-6 py-2 text-xs font-medium text-gray-500 sticky left-0 bg-gray-50 border-r border-gray-200 z-10"></th>
                              {/* Capex Headers */}
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-l border-yellow-200">
                                Description
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Cost
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Qty
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Total
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Grant
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-r border-yellow-200">
                                Remarks
                              </th>
                              {/* Opex Y1 Headers */}
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-l border-blue-200">
                                Description
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Cost
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Qty
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Total
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Grant
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-r border-blue-200">
                                Remarks
                              </th>
                              {/* Opex Y2 Headers */}
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-l border-green-200">
                                Description
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Cost
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Qty
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Total
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600">
                                Grant
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600 border-r border-green-200">
                                Remarks
                              </th>
                              <th className="px-3 py-2 text-xs font-medium text-gray-600"></th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {offering.items.map((item) => (
                              <tr key={item.id} className="hover:bg-gray-50">
                                <td className="px-3 py-3 sticky left-0 bg-white border-r border-gray-200 z-10">
                                  <input
                                    type="text"
                                    value={item.description}
                                    onChange={(e) => {
                                      const newDesc = e.target.value;
                                      setFormData((prev) => ({
                                        ...prev,
                                        [activeTab]: {
                                          ...prev[activeTab],
                                          tables: prev[activeTab].tables.map(
                                            (t) => ({
                                              ...t,
                                              serviceOfferings:
                                                t.serviceOfferings.map((o) =>
                                                  o.id === offering.id
                                                    ? {
                                                        ...o,
                                                        items: o.items.map(
                                                          (i) =>
                                                            i.id === item.id
                                                              ? {
                                                                  ...i,
                                                                  description:
                                                                    newDesc,
                                                                }
                                                              : i
                                                        ),
                                                      }
                                                    : o
                                                ),
                                            })
                                          ),
                                        },
                                      }));
                                    }}
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>

                                {/* Capex Year 0 */}
                                <td className="px-3 py-3 border-l border-yellow-200">
                                  <input
                                    type="text"
                                    value={
                                      item.financials.capex.year0.description
                                    }
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "description",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.capex.year0.cost}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "cost",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.capex.year0.qty}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "qty",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-24 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.capex.year0.total}
                                    readOnly
                                    className="w-full min-w-24 px-3 py-2 text-sm border border-gray-300 rounded bg-yellow-50 font-semibold text-yellow-800"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.capex.year0.grant}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "grant",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-24 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>
                                <td className="px-3 py-3 border-r border-yellow-200">
                                  <input
                                    type="text"
                                    value={item.financials.capex.year0.remarks}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "capex",
                                        "year0",
                                        "remarks",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-40 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-500"
                                  />
                                </td>

                                {/* Opex Year 1 */}
                                <td className="px-3 py-3 border-l border-blue-200">
                                  <input
                                    type="text"
                                    value={
                                      item.financials.opex.year1.description
                                    }
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "description",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year1.cost}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "cost",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year1.qty}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "qty",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year1.total}
                                    readOnly
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded bg-blue-50 font-semibold text-blue-800"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year1.grant}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "grant",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>
                                <td className="px-3 py-3 border-r border-blue-200">
                                  <input
                                    type="text"
                                    value={item.financials.opex.year1.remarks}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year1",
                                        "remarks",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-40 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  />
                                </td>

                                {/* Opex Year 2 */}
                                <td className="px-3 py-3 border-l border-green-200">
                                  <input
                                    type="text"
                                    value={
                                      item.financials.opex.year2.description
                                    }
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "description",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-44 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year2.cost}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "cost",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year2.qty}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "qty",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year2.total}
                                    readOnly
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded bg-green-50 font-semibold text-green-800"
                                  />
                                </td>
                                <td className="px-3 py-3">
                                  <input
                                    type="number"
                                    value={item.financials.opex.year2.grant}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "grant",
                                        Number(e.target.value)
                                      )
                                    }
                                    className="w-full min-w-28 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>
                                <td className="px-3 py-3 border-r border-green-200">
                                  <input
                                    type="text"
                                    value={item.financials.opex.year2.remarks}
                                    onChange={(e) =>
                                      updateField(
                                        offering.id,
                                        item.id,
                                        "opex",
                                        "year2",
                                        "remarks",
                                        e.target.value
                                      )
                                    }
                                    className="w-full min-w-40 px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
                                  />
                                </td>

                                {/* Actions */}
                                <td className="px-3 py-3 text-center">
                                  <button
                                    onClick={() =>
                                      deleteItem(offering.id, item.id)
                                    }
                                    className="text-red-600 hover:text-red-800 hover:bg-red-50 p-2 rounded-lg transition-colors"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Empty State */}
                      {offering.items.length === 0 && (
                        <div className="text-center py-12 text-gray-500">
                          <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                          <p className="text-lg font-medium">
                            No items added yet
                          </p>
                          <p className="text-sm">
                            Click "Add Item" to get started
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Budget Estimate Section */}
      <div className="py-3 px-6">
        {/* Grand Totals */}
        <div className="mt-3 p-6 bg-yellow-50 rounded-lg shadow-md text-base sm:text-lg">
          <h2 className="text-2xl font-semibold text-yellow-900 mb-4 flex items-center gap-2">
            Grand Totals
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm sm:text-base">
            {/* Capex */}
            <div className="flex flex-col bg-yellow-100 rounded-md p-4 border border-yellow-200">
              <span className="text-gray-600 font-medium mb-1">
                Capex (Year 0)
              </span>
              <span className="text-yellow-700 text-xl font-bold">
                ₹
                {(
                  sumAllCapexYear0(formData.budgetEstimate.tables) +
                  sumAllCapexYear0(formData.equipmentOverhead.tables)
                ).toLocaleString()}
              </span>
            </div>

            {/* Opex Year 1 */}
            <div className="flex flex-col bg-blue-50 rounded-md p-4 border border-blue-100">
              <span className="text-gray-600 font-medium mb-1">
                Opex (Year 1)
              </span>
              <span className="text-blue-700 text-xl font-bold">
                ₹
                {(
                  formData.budgetEstimate.tables.reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear1,
                    0
                  ) +
                  formData.equipmentOverhead.tables.reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear1,
                    0
                  )
                ).toLocaleString()}
              </span>
            </div>

            {/* Opex Year 2 */}
            <div className="flex flex-col bg-green-50 rounded-md p-4 border border-green-100">
              <span className="text-gray-600 font-medium mb-1">
                Opex (Year 2)
              </span>
              <span className="text-green-700 text-xl font-bold">
                ₹
                {(
                  formData.budgetEstimate.tables.reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear2,
                    0
                  ) +
                  formData.equipmentOverhead.tables.reduce(
                    (sum, t) => sum + sumTableGrantsByType(t).opexYear2,
                    0
                  )
                ).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BudgetEstimateForm;
