// objectivetimelines.jsx

import React, { useEffect } from "react";
import toast, { Toaster } from "react-hot-toast";

const MilestoneCard = ({
  milestoneNumber,
  ttdfGrantINR,
  data,
  onDataChange,
  isValid,
  isDisabled,
  milestoneData,
}) => {
  const handleChange = (field, value) => {
    onDataChange(milestoneNumber - 1, field, value);
  };

  const isWeeksValid = () => {
    const enteredWeeks = Number(data.timeRequiredMonths) || 0;
    
    // For milestones 1-3, check if sum is <= 6
    if (milestoneNumber <= 3) {
      const sumFirstThree = milestoneData
        .slice(0, 3)
        .reduce((sum, m) => sum + (Number(m.timeRequiredMonths) || 0), 0);
      return sumFirstThree <= 6;
    }
    
    // For milestone 4, check if <= 5
    if (milestoneNumber === 4) {
      return enteredWeeks <= 5;
    }
    
    // No validation for milestones 5 and 6
    return true;
  };

  const getValidationMessage = () => {
    if (milestoneNumber <= 3) {
      const sumFirstThree = milestoneData
        .slice(0, 3)
        .reduce((sum, m) => sum + (Number(m.timeRequiredMonths) || 0), 0);
      if (sumFirstThree > 6) {
        return `Sum of weeks for Milestones 1-3 should be ≤ 6 weeks (current sum: ${sumFirstThree})`;
      }
    } else if (milestoneNumber === 4) {
      if (Number(data.timeRequiredMonths) > 5) {
        return `Time Required (Weeks) should be ≤ 5 weeks`;
      }
    }
    return null;
  };

  const validationMessage = getValidationMessage();

  return (
    <div
      className={`bg-white rounded-xl shadow-lg border-2 transition-all duration-300 hover:shadow-xl ${
        isValid
          ? "border-green-200 bg-green-50/30"
          : "border-gray-200 hover:border-yellow-300"
      } ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
    >
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">
                {milestoneNumber}
              </span>
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-800">
                Milestone {milestoneNumber}
              </h3>
              <p className="text-sm text-gray-500"></p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500 mb-1">TTDF Capex Grant</p>
            <p className="text-lg font-bold text-blue-600">
              ₹{ttdfGrantINR.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Form Fields */}
        <div className="space-y-6">
          {/* Scope of Work - CLEAN: Just use user data */}
          <div className="group">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Scope of Work
              <span className="text-red-500 ml-1">*</span>
            </label>
            <textarea
              value={data.scopeOfWork || ""}
              onChange={(e) => handleChange("scopeOfWork", e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-200 resize-none"
              placeholder="Enter scope of work for this milestone..."
              rows="2"
              disabled={isDisabled}
            />
          </div>

          {/* Activities */}
          <div className="group">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Key Activities
              <span className="text-red-500 ml-1">*</span>
            </label>
            <textarea
              value={data.activities || ""}
              onChange={(e) => handleChange("activities", e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-200 resize-none"
              placeholder="List the key activities to be undertaken in this milestone..."
              rows="3"
              disabled={isDisabled}
            />
          </div>

          {/* Time Required and Applicant Contribution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Time Required (Weeks)
                <span className="text-red-500 ml-1">*</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={data.timeRequiredMonths || ""}
                  onChange={(e) =>
                    handleChange("timeRequiredMonths", e.target.value)
                  }
                  className={`w-full px-4 py-3 border ${
                    data.timeRequiredMonths && !isWeeksValid()
                      ? "border-red-500"
                      : "border-gray-300"
                  } rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-200`}
                  placeholder="0"
                  min="0"
                  step="0.5"
                  disabled={isDisabled}
                />
                <div className="absolute right-3 top-3 text-gray-400 text-sm">
                  Weeks
                </div>
              </div>
              {validationMessage ? (
                <p className="text-xs text-red-500 mt-1">{validationMessage}</p>
              ) : (
                <p className="text-xs text-gray-400 mt-1">
                  {milestoneNumber <= 3
                    ? "(Sum of M1+M2+M3 should be ≤ 6 weeks)"
                    : milestoneNumber === 4
                    ? "(Should be ≤ 5 weeks)"
                    : ""}
                </p>
              )}
            </div>

            <div className="group">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                TTDF Capex Grant (INR)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3 text-gray-400">₹</span>
                <input
                  type="number"
                  value={ttdfGrantINR}
                  readOnly
                  className="w-full pl-8 pr-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-600 cursor-not-allowed"
                  disabled
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ObjectiveTimelines = ({
  formData,
  onFormDataChange,
  financeDetails,
  grantTotals,
}) => {
  // Grant percentages for each milestone
  const grantPercentages = [0.1, 0.3, 0.15, 0.15, 0.15, 0.15];

  // Get values from financeDetails.section3Data with fallback
  const AmountToBeDistributed = grantTotals?.capexYear0 * 0.9 || 0;
  const totalTTDFGrant = Number(grantTotals?.capexYear0 * 0.9) || 0;
  const totalContribution =
    Number(financeDetails?.actual_contribution_applicant) || 0;

  // Check if section3Data is empty
  const isSection3DataEmpty =
    !financeDetails?.grant_from_ttdf &&
    !financeDetails?.contribution_applicant &&
    !financeDetails?.expected_other_contribution &&
    !financeDetails?.other_source_funding;

  // CLEAN: Use milestoneData directly from formData
  const milestoneData = formData?.milestoneData || Array(6).fill(null).map((_, index) => ({
    id: index + 1,
    scopeOfWork: "",
    timeRequiredMonths: "",
    activities: "",
    ttdfGrantINR: 0,
    applicantContributionINR: 0,
  }));

  // Calculate grant amounts
  const grantAmounts = grantPercentages.map((percentage) =>
    Math.round(totalTTDFGrant * percentage)
  );

  // Update ttdfGrantINR in milestoneData when grantAmounts change
  useEffect(() => {
    const updatedMilestoneData = milestoneData.map((milestone, index) => ({
      ...milestone, 
      ttdfGrantINR: grantAmounts[index] || 0, // Only update the grant amount
    }));
    
    // Only update if there's actually a change in grant amounts
    const hasChanged = updatedMilestoneData.some((milestone, index) => 
      milestone.ttdfGrantINR !== milestoneData[index]?.ttdfGrantINR
    );
    
    if (hasChanged) {
      console.log("🔍 Updating milestone grant amounts:", updatedMilestoneData);
      onFormDataChange({
        ...formData,
        milestoneData: updatedMilestoneData,
      });
    }
  }, [totalTTDFGrant]);

  
  useEffect(() => {
    if (isSection3DataEmpty) {
      toast.error(
        "Please complete Step 6: Finance Details before filling the milestone data.",
        {
          duration: 5000,
          position: "top-center",
        }
      );
    }
  }, [isSection3DataEmpty]);

  // Calculate totals
  const totalUserContribution = milestoneData.reduce(
    (sum, milestone) =>
      sum + (Number(milestone?.applicantContributionINR) || 0),
    0
  );

  const totalTime = milestoneData.reduce(
    (sum, milestone) => sum + (Number(milestone?.timeRequiredMonths) || 0),
    0
  );

  const remainingContribution = totalContribution - totalUserContribution;

  // Validation
  const isFormValid =
    !isSection3DataEmpty &&
    Math.abs(remainingContribution) < 0.01 && 
    milestoneData.every(
      (milestone, index) =>
        milestone.scopeOfWork?.trim() !== "" &&
        milestone.activities?.trim() !== "" &&
        Number(milestone.timeRequiredMonths) > 0 &&
        Number(milestone.applicantContributionINR) >= 0
    ) &&
    // Additional validation for weeks
    milestoneData.slice(0, 3).reduce((sum, m) => sum + (Number(m.timeRequiredMonths) || 0), 0) <= 6 &&
    (milestoneData[3] ? Number(milestoneData[3].timeRequiredMonths) <= 5 : true);

  const updateMilestone = (index, field, value) => {
    console.log(`🔍 Updating milestone ${index + 1}, field: ${field}, value:`, value);
    
    const updatedMilestoneData = milestoneData.map((milestone, i) =>
      i === index ? { ...milestone, [field]: value } : milestone
    );
    
    console.log("🔍 Updated milestoneData:", updatedMilestoneData);
    
    onFormDataChange({
      ...formData,
      milestoneData: updatedMilestoneData,
    });
  };

  const isValidMilestone = (index) => {
    const milestone = milestoneData[index];
    const hasScopeOfWork = milestone.scopeOfWork?.trim() !== "";
    const hasActivities = milestone.activities?.trim() !== "";
    const hasValidTime = Number(milestone.timeRequiredMonths) > 0;
    const hasValidContribution = Number(milestone.applicantContributionINR) >= 0;
    
    
    let hasValidTimeSpecific = true;
    if (index <= 2) {
      const sumFirstThree = milestoneData
        .slice(0, 3)
        .reduce((sum, m) => sum + (Number(m.timeRequiredMonths) || 0), 0);
      hasValidTimeSpecific = sumFirstThree <= 6;
    } else if (index === 3) {
      hasValidTimeSpecific = Number(milestone.timeRequiredMonths) <= 5;
    }
    

    return (
      hasScopeOfWork &&
      hasActivities &&
      hasValidTime &&
      hasValidContribution &&
      hasValidTimeSpecific
    );
  };

  return (
    <div className="min-h-screen p-3 bg-gradient-to-br from-gray-50 to-blue-50">
      <Toaster />
      <div className="max-w-7xl mx-auto">
        {/* Milestone Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 mb-6">
          {milestoneData.map((milestone, index) => (
            <MilestoneCard
              key={index}
              milestoneNumber={index + 1}
              ttdfGrantINR={grantAmounts[index] || 0}
              data={milestone}
              onDataChange={updateMilestone}
              isValid={isValidMilestone(index)}
              isDisabled={isSection3DataEmpty}
              milestoneData={milestoneData}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ObjectiveTimelines;