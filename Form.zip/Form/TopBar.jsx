// import React, { useRef } from "react";
// import { Link, useLocation } from "react-router-dom";
// import { IoMdArrowDroprightCircle, IoMdArrowDropleftCircle } from "react-icons/io";
// import { motion } from "framer-motion"; // ✅ Required import

// const Step = ({ number, label, active = false }) => (
//   <div className="flex flex-col items-center min-w-max">
//     <div
//       className={`w-8 h-8 rounded-full flex items-center justify-center font-bold transition-colors duration-200
//         ${
//           active
//             ? "bg-yellow-800 text-white"
//             : "bg-yellow-600 text-white group-hover:bg-yellow-800 group-hover:text-white"
//         }`}
//     >
//       {number}
//     </div>
//     <span className="text-xs mt-1 text-center transition-colors text-yellow-800 duration-200 group-hover:font-semibold">
//       {label}
//     </span>
//   </div>
// );

// const boxVariants = {
//   hidden: { opacity: 0, x: -100 },
//   visible: { opacity: 1, x: 0 },
// };

// const TopBar = () => {
//   const scrollRef = useRef(null);
//   const location = useLocation();

//   const scroll = (direction) => {
//     if (scrollRef.current) {
//       scrollRef.current.scrollBy({
//         left: direction === "left" ? -150 : 150,
//         behavior: "smooth",
//       });
//     }
//   };

//   const steps = [
//     { name: "Basic Form", path: "/" },
//     { name: "Organization Details", path: "/organization" },
//     { name: "Proposal Summary", path: "/proposal" },
//     { name: "Available Staff Assets", path: "/available" },
//     { name: "Collaborator Details", path: "/collaborator" },
//     { name: "Finance Details", path: "/finance" },
//     { name: "Highlight Proposal", path: "/highlight" },
//     { name: "IPR Details", path: "/ipr" },
//     { name: "Patents", path: "/patents" },
//     { name: "Manpower Details", path: "/manpower" },
//     { name: "Finance Budget", path: "/budget" },
//     { name: "Objective Wise Timelines", path: "/objective" },
//     { name: "Declaration Document", path: "/declaration" },
//   ];

//   return (
//     <motion.div
//       className="w-full bg-white shadow-md rounded-lg p-4 flex flex-col"
//       variants={boxVariants}
//       initial="hidden"
//       animate="visible"
//       transition={{ duration: 0.5 }}
//     >
//       <div className="flex items-center justify-between mb-2">
//         <button
//           onClick={() => scroll("left")}
//           className="text-yellow-700 hover:text-yellow-800 px-2"
//         >
//           <IoMdArrowDropleftCircle className="text-2xl" />
//         </button>

//         <div
//           ref={scrollRef}
//           className="flex overflow-x-auto space-x-9 px-2 no-scrollbar w-full"
//         >
//           {steps.map((step, index) => (
//             <Link to={step.path} key={index} className="group focus:outline-none">
//               <Step
//                 number={index + 1}
//                 label={step.name}
//                 active={location.pathname === step.path}
//               />
//             </Link>
//           ))}
//         </div>

//         <button
//           onClick={() => scroll("right")}
//           className="text-yellow-700 hover:text-yellow-800 px-2"
//         >
//           <IoMdArrowDroprightCircle className="text-2xl" />
//         </button>
//       </div>
//     </motion.div>
//   );
// };

// export default TopBar;

import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { IoMdCheckmark } from "react-icons/io";
import { motion } from "framer-motion";

const Step = ({
  number,
  label,
  active = false,
  completed = false,
  onClick,
}) => (
  <div
    className="flex items-center w-full p-3 group cursor-pointer"
    onClick={onClick}
  >
    <div
      className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-all duration-300 mr-4
        ${
          completed
            ? "bg-green-500 text-white shadow-lg"
            : active
            ? "bg-yellow-400 text-gray-800 shadow-md"
            : "bg-gray-200 text-gray-600 group-hover:bg-yellow-300 group-hover:text-gray-800"
        }`}
    >
      {completed ? <IoMdCheckmark className="text-lg" /> : number}
    </div>
    <span
      className={`text-sm font-medium transition-all duration-300 flex-1
        ${
          completed
            ? "text-green-700"
            : active
            ? "text-yellow-700"
            : "text-gray-700 group-hover:text-yellow-700"
        }`}
    >
      {label}
    </span>
  </div>
);

const sidebarVariants = {
  hidden: { opacity: 0, x: -50 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const TopBar = () => {
  const location = useLocation();
  const [completedSteps, setCompletedSteps] = useState(new Set());

  const steps = [
    { name: "Basic Form", path: "/" },
    { name: "Collaborator Details", path: "/collaborator" },
    { name: "Organization Details", path: "/organization" },
    { name: "Proposal Summary", path: "/proposal" },
    { name: "Available Staff Assets", path: "/available" },

    { name: "Finance Details", path: "/finance" },
    { name: "Highlight Proposal", path: "/highlight" },
    { name: "IPR Details", path: "/ipr" },
    { name: "Patents", path: "/patents" },
    { name: "Manpower Details", path: "/manpower" },
    { name: "Finance Budget", path: "/budget" },
    { name: "Objective Wise Timelines", path: "/objective" },
    { name: "Declaration Document", path: "/declaration" },
  ];

  const handleSaveSubmit = () => {
    const currentStepIndex = steps.findIndex(
      (step) => step.path === location.pathname
    );
    if (currentStepIndex !== -1) {
      setCompletedSteps((prev) => new Set([...prev, currentStepIndex]));
    }
  };

  const completionPercentage = Math.round(
    (completedSteps.size / steps.length) * 100
  );

  return (
    <motion.div
      className="w-80 bg-white shadow-lg h-screen flex flex-col border-r border-gray-200"
      variants={sidebarVariants}
      initial="hidden"
      animate="visible"
    >
      {/* EY Header */}
      <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 p-6 text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">EY</h1>
        <p className="text-sm text-gray-700">Building a better working world</p>
      </div>

      {/* Progress Overview */}
      <div className="bg-gray-50 p-4 border-b border-gray-200">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-700">Progress</span>
          <span className="text-sm font-bold text-yellow-600">
            {completionPercentage}%
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <motion.div
            className="bg-gradient-to-r from-yellow-400 to-green-500 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${completionPercentage}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
        <p className="text-xs text-gray-600 mt-1">
          {completedSteps.size} of {steps.length} sections completed
        </p>
      </div>

      {/* Steps Navigation */}
      <div className="flex-1 overflow-y-auto py-4">
        {steps.map((step, index) => (
          <Link to={step.path} key={index} className="block">
            <Step
              number={index + 1}
              label={step.name}
              active={location.pathname === step.path}
              completed={completedSteps.has(index)}
            />
          </Link>
        ))}
      </div>

      {/* Save/Submit Button */}
      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <motion.button
          onClick={handleSaveSubmit}
          className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 text-gray-800 py-3 px-4 rounded-lg font-semibold shadow-md hover:from-yellow-500 hover:to-yellow-600 transition-all duration-300 transform hover:scale-105 active:scale-95"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Save & Complete Section
        </motion.button>

        {/* Additional Actions */}
        <div className="flex gap-2 mt-3">
          <button className="flex-1 bg-gray-200 text-gray-700 py-2 px-3 rounded-md text-sm font-medium hover:bg-gray-300 transition-colors">
            Save Draft
          </button>
          <button className="flex-1 bg-green-500 text-white py-2 px-3 rounded-md text-sm font-medium hover:bg-green-600 transition-colors">
            Submit All
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default TopBar;
