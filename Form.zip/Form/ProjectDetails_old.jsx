import React, { useState } from "react";
import { Plus, Trash2, Upload, FileText } from "lucide-react";

const ProjectDetails = () => {
  const [projectDetails, setProjectDetails] = useState({
    architectureAndProjectChart: {
      ganttChart: null,
      technicalProposal: null,
      proposalPresentation: null,
    },
    manpowerDetails: [
      {
        jobTitle: "",
        minimumQualification: "",
        ageLimit: "",
        roleInProject: "",
        numberOfPositions: 0,
        durationMonths: 0,
        proposedMonthlySalary: 0,
        totalCost: 0,
      },
    ],
    otherRequirements: [
      {
        item: "",
        quantity: 0,
        unitPrice: 0,
        totalPrice: 0,
        specifications: "",
        certification: "",
        remarks: "",
      },
    ],
  });

  const handleFileUpload = (section, field, file) => {
    setProjectDetails((prev) => ({
      ...prev,
      architectureAndProjectChart: {
        ...prev.architectureAndProjectChart,
        [field]: file,
      },
    }));
  };

  const handleManpowerChange = (index, field, value) => {
    const updatedManpower = [...projectDetails.manpowerDetails];
    updatedManpower[index][field] = value;

    // Calculate total cost automatically
    if (
      field === "proposedMonthlySalary" ||
      field === "durationMonths" ||
      field === "numberOfPositions"
    ) {
      const salary =
        parseFloat(updatedManpower[index].proposedMonthlySalary) || 0;
      const duration = parseInt(updatedManpower[index].durationMonths) || 0;
      const positions = parseInt(updatedManpower[index].numberOfPositions) || 0;
      updatedManpower[index].totalCost = salary * duration * positions;
    }

    setProjectDetails((prev) => ({
      ...prev,
      manpowerDetails: updatedManpower,
    }));
  };

  const handleOtherRequirementChange = (index, field, value) => {
    const updatedRequirements = [...projectDetails.otherRequirements];
    updatedRequirements[index][field] = value;

    // Calculate total price automatically
    if (field === "quantity" || field === "unitPrice") {
      const quantity = parseInt(updatedRequirements[index].quantity) || 0;
      const unitPrice = parseFloat(updatedRequirements[index].unitPrice) || 0;
      updatedRequirements[index].totalPrice = quantity * unitPrice;
    }

    setProjectDetails((prev) => ({
      ...prev,
      otherRequirements: updatedRequirements,
    }));
  };

  const addManpowerRow = () => {
    setProjectDetails((prev) => ({
      ...prev,
      manpowerDetails: [
        ...prev.manpowerDetails,
        {
          jobTitle: "",
          minimumQualification: "",
          ageLimit: "",
          roleInProject: "",
          numberOfPositions: 0,
          durationMonths: 0,
          proposedMonthlySalary: 0,
          totalCost: 0,
        },
      ],
    }));
  };

  const removeManpowerRow = (index) => {
    if (projectDetails.manpowerDetails.length > 1) {
      const updatedManpower = projectDetails.manpowerDetails.filter(
        (_, i) => i !== index
      );
      setProjectDetails((prev) => ({
        ...prev,
        manpowerDetails: updatedManpower,
      }));
    }
  };

  const addOtherRequirementRow = () => {
    setProjectDetails((prev) => ({
      ...prev,
      otherRequirements: [
        ...prev.otherRequirements,
        {
          item: "",
          quantity: 0,
          unitPrice: 0,
          totalPrice: 0,
          specifications: "",
          certification: "",
          remarks: "",
        },
      ],
    }));
  };

  const removeOtherRequirementRow = (index) => {
    if (projectDetails.otherRequirements.length > 1) {
      const updatedRequirements = projectDetails.otherRequirements.filter(
        (_, i) => i !== index
      );
      setProjectDetails((prev) => ({
        ...prev,
        otherRequirements: updatedRequirements,
      }));
    }
  };

  const calculateManpowerTotal = () => {
    return projectDetails.manpowerDetails.reduce(
      (total, item) => total + (item.totalCost || 0),
      0
    );
  };

  const calculateOtherRequirementsTotal = () => {
    return projectDetails.otherRequirements.reduce(
      (total, item) => total + (item.totalPrice || 0),
      0
    );
  };

  const FileUploadField = ({
    label,
    field,
    accept = ".pdf,.doc,.docx,.jpg,.png",
  }) => (
    <div className="group">
      <label className="block text-sm font-semibold text-gray-700 mb-2">
        {label}
        <span className="text-red-500 ml-1">*</span>
      </label>
      <div className="relative">
        <input
          type="file"
          accept={accept}
          onChange={(e) =>
            handleFileUpload(
              "architectureAndProjectChart",
              field,
              e.target.files[0]
            )
          }
          className="hidden"
          id={field}
        />
        <label
          htmlFor={field}
          className="w-full px-4 py-3 border border-yellow-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all duration-200 cursor-pointer flex items-center justify-center bg-gray-50 hover:bg-gray-100"
        >
          <Upload className="w-5 h-5 mr-2 text-gray-400" />
          <span className="text-gray-600">
            {projectDetails.architectureAndProjectChart[field]
              ? projectDetails.architectureAndProjectChart[field].name
              : "Click to upload file"}
          </span>
        </label>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="max-w-7xl mx-auto">
        {/* Architecture & Project Chart Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">1</span>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                Architecture & Project Chart Upload
              </h2>
              <p className="text-gray-600">
                Upload GANTT/PERT Chart, technical proposal, and presentation
                (Project timeline: 18 months max)
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <FileUploadField
              label="GANTT/PERT Chart (Overall timeline for completing the project)"
              field="ganttChart"
              accept=".pdf,.jpg,.png,.doc,.docx"
            />

            <FileUploadField
              label="Technical Architecture & Detailed Proposal"
              field="technicalProposal"
              accept=".pdf,.doc,.docx"
            />

            <FileUploadField
              label="Proposal Presentation (PDF)"
              field="proposalPresentation"
              accept=".pdf"
            />
          </div>
        </div>

        {/* Manpower Details Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">2</span>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-800">
                Details of Manpower
              </h2>
              <p className="text-gray-600">
                Hire for this proposal from total cost
              </p>
            </div>
            <button
              onClick={addManpowerRow}
              className="flex items-center px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Row
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    S.No
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Job Title
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Minimum Qualification
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Age Limit
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Role in Project
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    No. of Positions
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Duration (Months)
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Monthly Salary (₹)
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Total Cost (₹)
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {projectDetails.manpowerDetails.map((row, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="border border-gray-300 p-3 text-center">
                      {index + 1}
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.jobTitle}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "jobTitle",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Job Title"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.minimumQualification}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "minimumQualification",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Qualification"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.ageLimit}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "ageLimit",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Age Limit"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.roleInProject}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "roleInProject",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Role"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="number"
                        value={row.numberOfPositions}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "numberOfPositions",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="0"
                        min="0"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="number"
                        value={row.durationMonths}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "durationMonths",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="0"
                        min="0"
                        max="18"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="number"
                        value={row.proposedMonthlySalary}
                        onChange={(e) =>
                          handleManpowerChange(
                            index,
                            "proposedMonthlySalary",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="0"
                        min="0"
                      />
                    </td>
                    <td className="border border-gray-300 p-3 text-right font-semibold">
                      ₹{row.totalCost.toLocaleString()}
                    </td>
                    <td className="border border-gray-300 p-3 text-center">
                      <button
                        onClick={() => removeManpowerRow(index)}
                        className="text-red-500 hover:text-red-700 p-1"
                        disabled={projectDetails.manpowerDetails.length === 1}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                <tr className="bg-yellow-50 font-bold">
                  <td
                    colSpan="8"
                    className="border border-gray-300 p-3 text-right"
                  >
                    Total
                  </td>
                  <td className="border border-gray-300 p-3 text-right">
                    ₹{calculateManpowerTotal().toLocaleString()}
                  </td>
                  <td className="border border-gray-300 p-3"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Other Requirements Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-full flex items-center justify-center mr-3">
              <span className="text-white font-bold text-lg">3</span>
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-gray-800">
                Other Requirements
              </h2>
              <p className="text-gray-600">
                Equipment, materials, and other resources needed
              </p>
            </div>
            <button
              onClick={addOtherRequirementRow}
              className="flex items-center px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Row
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    S.No
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Items
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Quantity
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Unit Price (₹)
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Total Price (₹)
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Specifications
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Certification
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Remarks
                  </th>
                  <th className="border border-gray-300 p-3 text-left font-semibold">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {projectDetails.otherRequirements.map((row, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="border border-gray-300 p-3 text-center">
                      {index + 1}
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.item}
                        onChange={(e) =>
                          handleOtherRequirementChange(
                            index,
                            "item",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Item name"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="number"
                        value={row.quantity}
                        onChange={(e) =>
                          handleOtherRequirementChange(
                            index,
                            "quantity",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="0"
                        min="0"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="number"
                        value={row.unitPrice}
                        onChange={(e) =>
                          handleOtherRequirementChange(
                            index,
                            "unitPrice",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="0"
                        min="0"
                      />
                    </td>
                    <td className="border border-gray-300 p-3 text-right font-semibold">
                      ₹{row.totalPrice.toLocaleString()}
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.specifications}
                        onChange={(e) =>
                          handleOtherRequirementChange(
                            index,
                            "specifications",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Specifications"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.certification}
                        onChange={(e) =>
                          handleOtherRequirementChange(
                            index,
                            "certification",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Certification"
                      />
                    </td>
                    <td className="border border-gray-300 p-3">
                      <input
                        type="text"
                        value={row.remarks}
                        onChange={(e) =>
                          handleOtherRequirementChange(
                            index,
                            "remarks",
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        placeholder="Remarks"
                      />
                    </td>
                    <td className="border border-gray-300 p-3 text-center">
                      <button
                        onClick={() => removeOtherRequirementRow(index)}
                        className="text-red-500 hover:text-red-700 p-1"
                        disabled={projectDetails.otherRequirements.length === 1}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                <tr className="bg-yellow-50 font-bold">
                  <td
                    colSpan="4"
                    className="border border-gray-300 p-3 text-right"
                  >
                    Total
                  </td>
                  <td className="border border-gray-300 p-3 text-right">
                    ₹{calculateOtherRequirementsTotal().toLocaleString()}
                  </td>
                  <td colSpan="4" className="border border-gray-300 p-3"></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary Section */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">
            Project Cost Summary
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700">
                Total Manpower Cost
              </h4>
              <p className="text-2xl font-bold text-yellow-600">
                ₹{calculateManpowerTotal().toLocaleString()}
              </p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700">
                Total Other Requirements
              </h4>
              <p className="text-2xl font-bold text-yellow-600">
                ₹{calculateOtherRequirementsTotal().toLocaleString()}
              </p>
            </div>
            <div className="bg-yellow-100 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700">
                Total Project Cost
              </h4>
              <p className="text-2xl font-bold text-yellow-700">
                ₹
                {(
                  calculateManpowerTotal() + calculateOtherRequirementsTotal()
                ).toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetails;
