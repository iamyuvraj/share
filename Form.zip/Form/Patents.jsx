import React, { useState } from "react";
import { FiPlus, FiX, FiUpload, FiUser, FiEye, FiEdit, FiTrash2 } from "react-icons/fi";
import { motion } from "framer-motion";
const boxVariants = {   
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};
const Patents = () => {
  const [formVisible, setFormVisible] = useState(false);
  const [rows, setRows] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    patentNumber: "",
    patentTitle: "",
    file: null,
  });
  const [editingIndex, setEditingIndex] = useState(null);

  const [selectedImage, setSelectedImage] = useState(null);
  const [showImageModal, setShowImageModal] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({ ...prev, file }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingIndex !== null) {
      // Edit existing row
      const updatedRows = [...rows];
      updatedRows[editingIndex] = formData;
      setRows(updatedRows);
      setEditingIndex(null);
    } else {
      // Add new row
      setRows([...rows, formData]);
    }
    setFormData({ name: "", patentNumber: "", patentTitle: "", file: null });
    setFormVisible(false);
  };

  const handleEdit = (index) => {
    setFormData(rows[index]);
    setEditingIndex(index);
    setFormVisible(true);
  };

  const handleDelete = (index) => {
    if (window.confirm("Are you sure you want to delete this patent?")) {
      setRows(rows.filter((_, i) => i !== index));
    }
  };

  return (
    <motion.div
         variants={boxVariants}
        initial="hidden"
        animate="visible"
        transition={{ duration: 0.5 }}>
      <div className="p-6">
        <h3 className="text-2xl font-semibold text-yellow-800 mb-8 flex flex-col items-center gap-2 border-b-2 border-yellow-900">
          List of Patents that May Restrict Freedom-to-Operate in Envisaged Technology Areas
        </h3>

        <div className="overflow-auto rounded border border-yellow-100 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-yellow-100 text-yellow-800 border-y border-yellow-100">
              <tr>
                <th className="px-3 py-2">Serial No.</th>
                <th className="px-3 py-2">Patent Number</th>
                <th className="px-3 py-2">Patent Title</th>
                <th className="px-3 py-2">Patent Document (Optional)</th>
                <th className="px-3 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.length > 0 ? (
                rows.map((row, index) => (
                  <tr key={index} className={index % 2 === 0 ? "bg-yellow-50" : "bg-yellow-100"}>
                    <td className="px-3 py-2 border-y border-yellow-100">{index + 1}</td>
                    <td className="px-3 py-2 border-y border-yellow-100">{row.patentNumber}</td>
                    <td className="px-3 py-2 border-y border-yellow-100">{row.patentTitle}</td>
                    <td className="px-3 py-2 border-y border-yellow-100">
                      {row.file ? (
                        <img
                          src={URL.createObjectURL(row.file)}
                          alt="MoU"
                          className="h-10 w-10 object-cover rounded"
                        />
                      ) : (
                        "N/A"
                      )}
                    </td>
                    <td className="px-3 py-2 border-y border-yellow-100 text-yellow-600 font-medium flex gap-4">
                      {row.file ? (
                        <button
                          onClick={() => {
                            setSelectedImage(URL.createObjectURL(row.file));
                            setShowImageModal(true);
                          }}
                          title="View"
                          className="hover:text-yellow-800"
                        >
                          <FiEye size={18} />
                        </button>
                      ) : (
                        <span className="text-gray-400" title="No image">
                          <FiEye size={18} className="opacity-40 cursor-not-allowed" />
                        </span>
                      )}

                      <button
                        onClick={() => handleEdit(index)}
                        title="Edit"
                        className="hover:text-green-600"
                      >
                        <FiEdit size={18} />
                      </button>

                      <button
                        onClick={() => handleDelete(index)}
                        title="Delete"
                        className="hover:text-red-600"
                      >
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="text-center text-yellow-500 py-4">
                    No Patent added yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mt-6">
          <button
            className="flex items-center gap-2 text-yellow-600 hover:text-yellow-800 font-medium"
            onClick={() => {
              setFormData({ name: "", patentNumber: "", patentTitle: "", file: null });
              setEditingIndex(null);
              setFormVisible(true);
            }}
          >
            <FiPlus className="text-lg" />
            Add Patent
          </button>
        </div>
      </div>

      {/* Form Modal */}
      {formVisible && (
        <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-2xl w-[700px] max-h-[90vh] overflow-y-auto relative border border-yellow-100">
            <button
              onClick={() => setFormVisible(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
            >
              <FiX className="text-xl" />
            </button>

           <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
  <div>
    <label className="block text-sm font-medium text-yellow-800 mb-1">
      Patent Number <span className="text-red-600">*</span>
    </label>
    <div className="flex items-center gap-2 bg-yellow-50 border border-yellow-100 rounded p-2">
      <input
        type="number"
        name="patentNumber"
        value={formData.patentNumber}
        onChange={handleChange}
        required
        placeholder="Enter patent number"
        className="bg-transparent w-full outline-none"
      />
    </div>
  </div>

  <div>
    <label className="block text-sm font-medium text-yellow-800 mb-1">
      Patent Title <span className="text-red-600">*</span>
    </label>
    <div className="flex items-center gap-2 bg-yellow-50 border border-yellow-100 rounded p-2">
      <input
        type="text"
        name="patentTitle"
        value={formData.patentTitle}
        onChange={handleChange}
        required
        placeholder="Enter patent title"
        className="bg-transparent w-full outline-none"
      />
    </div>
  </div>

  <div className="md:col-span-2">
    <label className="block text-sm font-medium text-yellow-800 mb-1">
      Patent Document (Optional)
    </label>
    <div className="flex items-center gap-2 bg-yellow-50 border border-yellow-100 rounded p-2">
      <FiUpload className="text-yellow-600" />
      <input
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="bg-transparent w-full outline-none"
      />
    </div>
    {/* Show preview of selected image */}
    {formData.file && (
      <img
        src={URL.createObjectURL(formData.file)}
        alt="Preview"
        className="mt-2 h-20 w-20 object-cover rounded"
      />
    )}
  </div>

  <div className="md:col-span-2 flex justify-end gap-4 mt-4">
    <button
      type="button"
      onClick={() => {
        setFormVisible(false);
        setEditingIndex(null);
        setFormData({ patentNumber: "", patentTitle: "", file: null });
      }}
      className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
    >
      Cancel
    </button>
    <button
      type="submit"
      className="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700"
    >
      {editingIndex !== null ? "Update" : "Add"}
    </button>
  </div>
</form>

          </div>
        </div>
      )}

      {/* Image Modal */}
      {showImageModal && selectedImage && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="relative bg-white p-4 rounded shadow-lg max-w-3xl max-h-[90vh] overflow-auto border border-yellow-100">
            <button
              className="absolute top-2 right-2 text-gray-600 hover:text-gray-800"
              onClick={() => setShowImageModal(false)}
            >
              <FiX className="text-2xl" />
            </button>
            <img
              src={selectedImage}
              alt="MoU Preview"
              className="w-full h-auto rounded"
            />
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default Patents;
