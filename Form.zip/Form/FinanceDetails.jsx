import React, { useState, useEffect, useCallback } from "react";
import { Plus, X, Edit, Trash2, Eye } from "lucide-react";

const Modal = ({ visible, onClose, title, children }) => {
  if (!visible) return null;
  return (
    <div className="fixed inset-0 z-50 flex h-full items-center justify-center bg-black/30 bg-opacity-30">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 relative">
        <button
          className="absolute top-2 right-2 text-yellow-700 hover:text-yellow-900"
          onClick={onClose}
        >
          <X size={22} />
        </button>
        <h4 className="text-lg font-semibold text-yellow-800 mb-4">{title}</h4>
        {children}
      </div>
    </div>
  );
};

const FinanceDetails = ({
  initialFormData = {},
  onFormDataChange,
  grantTotals = {},
  budgetEstimate = {},
  submissionId
}) => {
  // Calculate derived values from grant totals
  const tenPercentOfCapex = grantTotals?.capexYear0 ? grantTotals.capexYear0 * 0.1 : 0;
  const totalGrantFromTtdf = (grantTotals?.capexYear0 ?? 0) + (grantTotals?.opexYear1 ?? 0) + (grantTotals?.opexYear2 ?? 0);

  // Initialize local state with defaults
  const [formData, setFormData] = useState({
    contributionRows: initialFormData.contributionRows || [],
    fundRows: initialFormData.fundRows || [],
    grant_from_ttdf: totalGrantFromTtdf,
    contribution_applicant: initialFormData.contribution_applicant || "",
    expected_other_contribution: 0,
    other_source_funding: 0,
    actual_grant_from_ttdf: totalGrantFromTtdf - tenPercentOfCapex,
    actual_contribution_applicant: tenPercentOfCapex,
    ...initialFormData,
  });

  // Modal states
  const [contribFormVisible, setContribFormVisible] = useState(false);
  const [contribEditingIndex, setContribEditingIndex] = useState(null);
  const [contribFormData, setContribFormData] = useState({
    expectedSource: "",
    contributionItem: "",
    contributionAmount: "",
  });

  const [fundFormVisible, setFundFormVisible] = useState(false);
  const [fundEditingIndex, setFundEditingIndex] = useState(null);
  const [fundFormData, setFundFormData] = useState({
    fundSourceDetails: "",
    fundItem: "",
    fundAmount: "",
  });

  const [viewModalVisible, setViewModalVisible] = useState(false);
  const [viewData, setViewData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Calculate derived values function
  const calculateDerivedValues = useCallback((data) => {
    const expectedOtherContribution = (data.contributionRows || []).reduce(
      (sum, row) => sum + (Number(row.contributionAmount) || 0), 0
    );

    const otherSourceFunding = (data.fundRows || []).reduce(
      (sum, row) => sum + (Number(row.fundAmount) || 0), 0
    );

    const contributionByApplicant = Number(data.contribution_applicant) || 0;

    return {
      actual_grant_from_ttdf: totalGrantFromTtdf - tenPercentOfCapex - contributionByApplicant,
      actual_contribution_applicant: tenPercentOfCapex + contributionByApplicant,
      expected_other_contribution: expectedOtherContribution,
      other_source_funding: otherSourceFunding,
      // DON'T include contribution_applicant here - let it be controlled by user input
    };
  }, [totalGrantFromTtdf, tenPercentOfCapex]);

  // Debounced save function to prevent excessive API calls
  const saveToBackend = useCallback(async (dataToSave) => {
    if (!submissionId || isLoading) return;

    try {
      setIsLoading(true);
      const response = await fetch('/api/dynamic-form/finance-details/update/', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]')?.value || '',
        },
        body: JSON.stringify({
          submission_id: submissionId,
          ...dataToSave
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      if (!result.success) {
        console.error('Save failed:', result);
      }
    } catch (error) {
      console.error('Error saving finance details:', error);
    } finally {
      setIsLoading(false);
    }
  }, [submissionId, isLoading]);

  // Update both local and parent state, then save to backend
  const updateFormData = useCallback((newData) => {
    const updatedData = { ...formData, ...newData };
    const derived = calculateDerivedValues(updatedData);
    
    // Don't override contribution_applicant if it's being set by user
    const completeData = { 
      ...updatedData, 
      ...derived,
      // Preserve the user's contribution_applicant input
      contribution_applicant: newData.contribution_applicant !== undefined 
        ? newData.contribution_applicant 
        : updatedData.contribution_applicant
    };

    setFormData(completeData);
    
    // Notify parent component
    if (onFormDataChange) {
      onFormDataChange(completeData);
    }

    // Save to backend (debounced)
    const timeoutId = setTimeout(() => {
      saveToBackend(completeData);
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [formData, calculateDerivedValues, onFormDataChange, saveToBackend]);

  // Initialize when props change
  useEffect(() => {
    const derived = calculateDerivedValues(initialFormData);
    const newFormData = {
      contributionRows: initialFormData.contributionRows || [],
      fundRows: initialFormData.fundRows || [],
      grant_from_ttdf: totalGrantFromTtdf,
      contribution_applicant: initialFormData.contribution_applicant || "",
      ...derived,
    };

    setFormData(newFormData);
    if (onFormDataChange) {
      onFormDataChange(newFormData);
    }
  }, []); // FIXED: Empty dependency array to prevent infinite loops

  // Handle contribution form changes
  const handleContribChange = (e) => {
    const { name, value } = e.target;
    setContribFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFundChange = (e) => {
    const { name, value } = e.target;
    setFundFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSection3Change = (e) => {
    const { name, value } = e.target;
    updateFormData({ [name]: value });
  };

  const handleContribSubmit = (e) => {
    if (e) e.preventDefault();
    const updatedRows = [...formData.contributionRows];
    
    if (contribEditingIndex !== null) {
      updatedRows[contribEditingIndex] = {
        ...contribFormData,
        serialNo: updatedRows[contribEditingIndex].serialNo,
      };
    } else {
      updatedRows.push({
        ...contribFormData,
        serialNo: updatedRows.length + 1,
      });
    }
    
    updateFormData({ contributionRows: updatedRows });
    resetContribForm();
  };

  const handleFundSubmit = (e) => {
    if (e) e.preventDefault();
    const updatedRows = [...formData.fundRows];
    
    if (fundEditingIndex !== null) {
      updatedRows[fundEditingIndex] = {
        ...fundFormData,
        serialNo: updatedRows[fundEditingIndex].serialNo,
      };
    } else {
      updatedRows.push({
        ...fundFormData,
        serialNo: updatedRows.length + 1,
      });
    }
    
    updateFormData({ fundRows: updatedRows });
    resetFundForm();
  };

  const resetContribForm = () => {
    setContribFormData({
      expectedSource: "",
      contributionItem: "",
      contributionAmount: "",
    });
    setContribEditingIndex(null);
    setContribFormVisible(false);
  };

  const resetFundForm = () => {
    setFundFormData({
      fundSourceDetails: "",
      fundItem: "",
      fundAmount: "",
    });
    setFundEditingIndex(null);
    setFundFormVisible(false);
  };

  const handleContribEdit = (i) => {
    const entry = formData.contributionRows[i];
    setContribFormData({
      expectedSource: entry.expectedSource,
      contributionItem: entry.contributionItem,
      contributionAmount: entry.contributionAmount,
    });
    setContribEditingIndex(i);
    setContribFormVisible(true);
  };

  const handleFundEdit = (i) => {
    const entry = formData.fundRows[i];
    setFundFormData({
      fundSourceDetails: entry.fundSourceDetails,
      fundItem: entry.fundItem,
      fundAmount: entry.fundAmount,
    });
    setFundEditingIndex(i);
    setFundFormVisible(true);
  };

  const handleContribDelete = (i) => {
    if (window.confirm("Delete this entry?")) {
      const updatedRows = formData.contributionRows
        .filter((_, idx) => idx !== i)
        .map((row, idx) => ({ ...row, serialNo: idx + 1 }));
      updateFormData({ contributionRows: updatedRows });
      if (contribEditingIndex === i) resetContribForm();
    }
  };

  const handleFundDelete = (i) => {
    if (window.confirm("Delete this entry?")) {
      const updatedRows = formData.fundRows
        .filter((_, idx) => idx !== i)
        .map((row, idx) => ({ ...row, serialNo: idx + 1 }));
      updateFormData({ fundRows: updatedRows });
      if (fundEditingIndex === i) resetFundForm();
    }
  };

  const handleView = (data) => {
    setViewData(data);
    setViewModalVisible(true);
  };

  return (
    <div className="space-y-12 px-4 py-3">
      {/* Loading indicator */}
      {isLoading && (
        <div className="fixed top-4 right-4 bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-2 rounded">
          Saving...
        </div>
      )}

      {/* Contribution Modal */}
      <Modal
        visible={contribFormVisible}
        onClose={resetContribForm}
        title={contribEditingIndex !== null ? "Edit Contribution Entry" : "Add Contribution Entry"}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Expected Source <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              name="expectedSource"
              value={contribFormData.expectedSource}
              onChange={handleContribChange}
              required
              className="w-full p-2 border border-yellow-200 rounded"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Contribution Item <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              name="contributionItem"
              value={contribFormData.contributionItem}
              onChange={handleContribChange}
              required
              className="w-full p-2 border border-yellow-200 rounded"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Contribution Amount (INR) <span className="text-red-600">*</span>
            </label>
            <input
              type="number"
              name="contributionAmount"
              value={contribFormData.contributionAmount}
              onChange={handleContribChange}
              required
              min="0"
              className="w-full p-2 border border-yellow-200 rounded"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              className="px-4 py-2 rounded bg-gray-200 text-gray-700"
              onClick={resetContribForm}
            >
              Cancel
            </button>
            <button
              type="button"
              className="px-4 py-2 rounded bg-yellow-600 text-white hover:bg-yellow-700"
              onClick={handleContribSubmit}
            >
              {contribEditingIndex !== null ? "Update" : "Add"}
            </button>
          </div>
        </div>
      </Modal>

      {/* Fund Modal */}
      <Modal
        visible={fundFormVisible}
        onClose={resetFundForm}
        title={fundEditingIndex !== null ? "Edit Fund Entry" : "Add Fund Entry"}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Fund Source Details <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              name="fundSourceDetails"
              value={fundFormData.fundSourceDetails}
              onChange={handleFundChange}
              required
              className="w-full p-2 border border-yellow-200 rounded"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Fund Item <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              name="fundItem"
              value={fundFormData.fundItem}
              onChange={handleFundChange}
              required
              className="w-full p-2 border border-yellow-200 rounded"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Fund Amount (INR) <span className="text-red-600">*</span>
            </label>
            <input
              type="number"
              name="fundAmount"
              value={fundFormData.fundAmount}
              onChange={handleFundChange}
              required
              min="0"
              className="w-full p-2 border border-yellow-200 rounded"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              className="px-4 py-2 rounded bg-gray-200 text-gray-700"
              onClick={resetFundForm}
            >
              Cancel
            </button>
            <button
              type="button"
              className="px-4 py-2 rounded bg-yellow-600 text-white hover:bg-yellow-700"
              onClick={handleFundSubmit}
            >
              {fundEditingIndex !== null ? "Update" : "Add"}
            </button>
          </div>
        </div>
      </Modal>

      {/* View Modal */}
      <Modal
        visible={viewModalVisible}
        onClose={() => setViewModalVisible(false)}
        title={`View ${viewData?.section === 1 ? "Contribution" : "Fund"} Details`}
      >
        {viewData && (
          <div className="space-y-2">
            <p><strong className="text-yellow-800">Serial No:</strong> {viewData.serialNo}</p>
            {viewData.section === 1 ? (
              <>
                <p><strong className="text-yellow-800">Expected Source:</strong> {viewData.expectedSource}</p>
                <p><strong className="text-yellow-800">Contribution Item:</strong> {viewData.contributionItem}</p>
                <p><strong className="text-yellow-800">Contribution Amount (INR):</strong> {viewData.contributionAmount}</p>
              </>
            ) : (
              <>
                <p><strong className="text-yellow-800">Fund Source Details:</strong> {viewData.fundSourceDetails}</p>
                <p><strong className="text-yellow-800">Fund Item:</strong> {viewData.fundItem}</p>
                <p><strong className="text-yellow-800">Fund Amount (INR):</strong> {viewData.fundAmount}</p>
              </>
            )}
            <div className="flex justify-end mt-4">
              <button
                className="px-4 py-2 rounded bg-gray-200 text-gray-700"
                onClick={() => setViewModalVisible(false)}
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Section 1: Contribution Details */}
      <section>
        <h3 className="text-yellow-800 mb-6 font-semibold text-lg">
          Section 1: Contribution Details
        </h3>
        <div className="overflow-auto rounded border border-yellow-50 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-yellow-100 text-yellow-800">
              <tr>
                <th className="px-3 py-2">Serial No.</th>
                <th className="px-3 py-2">Expected other source for the Proposal Contribution</th>
                <th className="px-3 py-2">Contribution Item</th>
                <th className="px-3 py-2">Contribution Amount (INR)</th>
                <th className="px-3 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {formData.contributionRows.length ? (
                formData.contributionRows.map((row, i) => (
                  <tr key={i} className={`${i % 2 === 0 ? "bg-yellow-50" : "bg-yellow-100"} border-b border-yellow-50`}>
                    <td className="px-3 py-2">{row.serialNo}</td>
                    <td className="px-3 py-2">{row.expectedSource}</td>
                    <td className="px-3 py-2">{row.contributionItem}</td>
                    <td className="px-3 py-2">{row.contributionAmount}</td>
                    <td className="px-3 py-2 flex gap-2">
                      <button onClick={() => handleView({ section: 1, ...row })} title="View" className="text-yellow-600 hover:text-yellow-800">
                        <Eye size={16} />
                      </button>
                      <button onClick={() => handleContribEdit(i)} title="Edit" className="text-yellow-600 hover:text-green-800">
                        <Edit size={16} />
                      </button>
                      <button onClick={() => handleContribDelete(i)} title="Delete" className="text-yellow-600 hover:text-red-800">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr className="border-b border-yellow-50">
                  <td colSpan="5" className="text-center text-yellow-500 py-4">No entries yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-6">
          <button
            className="flex items-center gap-2 text-yellow-600 hover:text-yellow-800 font-medium"
            onClick={() => {
              resetContribForm();
              setContribFormVisible(true);
            }}
            type="button"
          >
            <Plus className="text-lg" /> Add Entry
          </button>
        </div>
      </section>

      {/* Section 2: Fund Details */}
      <section>
        <h3 className="text-yellow-800 mb-6 font-semibold text-lg">
          Section 2: Fund Details
        </h3>
        <div className="overflow-auto rounded border border-yellow-50 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-yellow-100 text-yellow-800">
              <tr>
                <th className="px-3 py-2">Serial No.</th>
                <th className="px-3 py-2">Details of Other Sources of Funding</th>
                <th className="px-3 py-2">Fund Item</th>
                <th className="px-3 py-2">Fund Amount (INR)</th>
                <th className="px-3 py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {formData.fundRows.length ? (
                formData.fundRows.map((row, i) => (
                  <tr key={i} className={`${i % 2 === 0 ? "bg-yellow-50" : "bg-yellow-100"} border-b border-yellow-50`}>
                    <td className="px-3 py-2">{row.serialNo}</td>
                    <td className="px-3 py-2">{row.fundSourceDetails}</td>
                    <td className="px-3 py-2">{row.fundItem}</td>
                    <td className="px-3 py-2">{row.fundAmount}</td>
                    <td className="px-3 py-2 flex gap-2">
                      <button onClick={() => handleView({ section: 2, ...row })} title="View" className="text-yellow-600 hover:text-yellow-800">
                        <Eye size={16} />
                      </button>
                      <button onClick={() => handleFundEdit(i)} title="Edit" className="text-yellow-600 hover:text-green-800">
                        <Edit size={16} />
                      </button>
                      <button onClick={() => handleFundDelete(i)} title="Delete" className="text-yellow-600 hover:text-red-800">
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr className="border-b border-yellow-50">
                  <td colSpan="5" className="text-center text-yellow-500 py-4">No entries yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-6">
          <button
            className="flex items-center gap-2 text-yellow-600 hover:text-yellow-800 font-medium"
            onClick={() => {
              resetFundForm();
              setFundFormVisible(true);
            }}
            type="button"
          >
            <Plus className="text-lg" /> Add Entry
          </button>
        </div>
      </section>

      {/* Section 3: Summary */}
      <section>
        <h3 className="text-yellow-800 mb-6 font-semibold text-lg">Section 3: Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white p-6 border border-yellow-50 rounded shadow-sm">
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">Total Funds Requested (INR)</label>
            <input
              type="number"
              value={totalGrantFromTtdf}
              readOnly
              className="w-full p-2 border border-yellow-100 bg-gray-100 rounded"
            />
            <p className="text-xs text-gray-500 mt-1">Automatically calculated from CAPEX and OPEX</p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">TTDF Capex (INR)</label>
            <input
              type="text"
              readOnly
              value={formData.actual_grant_from_ttdf.toLocaleString()}
              className="w-full p-2 border border-yellow-100 bg-gray-100 rounded"
            />
            <p className="text-xs text-gray-500 mt-1">Calculated as: (Grant from TTDF) - (10% of CAPEX)</p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">
              Contribution by Applicant (INR) <span className="text-red-600">*</span>
            </label>
            <input
              type="number"
              name="contribution_applicant"
              value={formData.contribution_applicant}
              onChange={handleSection3Change}
              className="w-full p-2 border border-yellow-100 bg-yellow-50 rounded"
            />
            <p className="text-xs text-gray-500 mt-1">Additional contribution beyond the required 10% of CAPEX</p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">Total Contribution by Applicant (INR)</label>
            <input
              type="text"
              readOnly
              value={formData.actual_contribution_applicant.toLocaleString()}
              className="w-full p-2 border border-yellow-100 bg-gray-100 rounded"
            />
            <p className="text-xs text-gray-500 mt-1">
              Calculated as: (10% of CAPEX Year 0: ₹{tenPercentOfCapex.toLocaleString()}) + (Additional Contribution)
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">Expected Other Contribution (INR)</label>
            <input
              type="number"
              readOnly
              value={formData.expected_other_contribution}
              className="w-full p-2 border border-yellow-100 bg-gray-100 rounded"
            />
            <p className="text-xs text-gray-500 mt-1">Sum of all Contribution Amounts from Section 1</p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-yellow-800 mb-1">Other Source of Funding (INR)</label>
            <input
              type="number"
              readOnly
              value={formData.other_source_funding}
              className="w-full p-2 border border-yellow-100 bg-gray-100 rounded"
            />
            <p className="text-xs text-gray-500 mt-1">Sum of all Fund Amounts from Section 2</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FinanceDetails;