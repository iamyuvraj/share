import React, { useState } from "react";
import { FiPlus, FiX, FiEdit, FiTrash2, FiEye } from "react-icons/fi";
import { motion } from "framer-motion";
const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};
const Objective = () => {
  const [formVisible, setFormVisible] = useState(false);
  const [formData, setFormData] = useState({
    scopeOfWork: "",
    timeRequired: "",
    activities: "",
    contribution: "",
    grants: "",
  });
  const [rows, setRows] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const [viewData, setViewData] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editIndex !== null) {
      const updatedRows = [...rows];
      updatedRows[editIndex] = formData;
      setRows(updatedRows);
      setEditIndex(null);
    } else {
      setRows([...rows, formData]);
    }
    setFormData({
      scopeOfWork: "",
      timeRequired: "",
      activities: "",
      contribution: "",
      grants: "",
    });
    setFormVisible(false);
  };

  const handleDelete = (index) => {
    if (window.confirm("Are you sure you want to delete this entry?")) {
      setRows((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const handleEdit = (index) => {
    setFormData(rows[index]);
    setEditIndex(index);
    setFormVisible(true);
  };

  const handleView = (index) => {
    setViewData(rows[index]);
  };

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={boxVariants}
      transition={{ duration: 0.5 }}
    >
      <div className=" p-6">
        <h3 className="text-2xl font-semibold text-yellow-800 mb-8 flex flex-col items-center gap-2 border-b-2 border-yellow-900">
          Objective Wise Activities & Timeline
        </h3>

        <div className="overflow-auto rounded border border-yellow-50 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-yellow-100 text-yellow-800">
              <tr>
                <th className="px-3 py-2">Milestone</th>
                <th className="px-3 py-2">Define Scope of Work</th>
                <th className="px-3 py-2">Time Required (in months)</th>
                <th className="px-3 py-2">Activities to be Undertaken</th>
                <th className="px-3 py-2">
                  Contribution by Applicant (in INR)
                </th>
                <th className="px-3 py-2">Grants from TTDF (in INR)</th>
                <th className="px-3 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.length ? (
                rows.map((row, i) => (
                  <tr
                    key={i}
                    className={`${
                      i % 2 === 0 ? "bg-yellow-50" : "bg-yellow-100"
                    } border-b border-yellow-50`}
                  >
                    <td className="px-3 py-2">{i + 1}</td>
                    <td className="px-3 py-2">{row.scopeOfWork}</td>
                    <td className="px-3 py-2">{row.timeRequired}</td>
                    <td className="px-3 py-2">{row.activities}</td>
                    <td className="px-3 py-2">{row.contribution}</td>
                    <td className="px-3 py-2">{row.grants}</td>
                    <td className="px-3 py-2 flex gap-3 text-yellow-600">
                      <button
                        onClick={() => handleView(i)}
                        title="View Details"
                        className="hover:text-yellow-800"
                      >
                        <FiEye />
                      </button>
                      <button
                        onClick={() => handleEdit(i)}
                        title="Edit"
                        className="hover:text-yellow-800"
                      >
                        <FiEdit />
                      </button>
                      <button
                        onClick={() => handleDelete(i)}
                        title="Delete"
                        className="hover:text-red-600"
                      >
                        <FiTrash2 />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr className="border-b border-yellow-50">
                  <td colSpan="7" className="text-center text-yellow-500 py-4">
                    No entries yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex justify-end mt-6">
          <button
            className="flex items-center gap-2 text-yellow-600 hover:text-yellow-800 font-medium"
            onClick={() => {
              setFormData({
                scopeOfWork: "",
                timeRequired: "",
                activities: "",
                contribution: "",
                grants: "",
              });
              setEditIndex(null);
              setFormVisible(true);
            }}
          >
            <FiPlus className="text-lg" />
            Add Milestone
          </button>
        </div>
        {formVisible && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-10">
            <div className="bg-white rounded-lg shadow-2xl w-full max-w-3xl relative border border-yellow-100 p-6">
              <button
                onClick={() => setFormVisible(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>

              <h3 className="text-lg font-semibold text-yellow-700 mb-4 border-b border-yellow-50 pb-2">
                {editIndex !== null ? "Edit Objective" : "Add Objective"}
              </h3>

              <form
                onSubmit={handleSubmit}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Scope of Work <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="scopeOfWork"
                    value={formData.scopeOfWork}
                    onChange={handleChange}
                    required
                    className="w-full p-2 border border-yellow-100 bg-yellow-50 rounded"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Time Required (in months){" "}
                    <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    name="timeRequired"
                    value={formData.timeRequired}
                    onChange={handleChange}
                    required
                    className="w-full p-2 border border-yellow-100 bg-yellow-50 rounded"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Activities to be Undertaken{" "}
                    <span className="text-red-600">*</span>
                  </label>
                  <input
                    name="activities"
                    value={formData.activities}
                    onChange={handleChange}
                    required
                    type="number"
                    className="w-full p-2 border border-yellow-100 bg-yellow-50 rounded"
                  ></input>
                </div>

                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Contribution by Applicant (in INR){" "}
                    <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    name="contribution"
                    value={formData.contribution}
                    onChange={handleChange}
                    required
                    className="w-full p-2 border border-yellow-100 bg-yellow-50 rounded"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Grants from TTDF (in INR){" "}
                    <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    name="grants"
                    value={formData.grants}
                    onChange={handleChange}
                    required
                    className="w-full p-2 border border-yellow-100 bg-yellow-50 rounded"
                  />
                </div>

                <div className="md:col-span-2 flex justify-end gap-4 mt-4">
                  <button
                    type="button"
                    onClick={() => setFormVisible(false)}
                    className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700"
                  >
                    {editIndex !== null ? "Save" : "Add"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {viewData && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-10">
            <div className="bg-white rounded-lg shadow-2xl w-full max-w-md relative border border-yellow-100 p-6">
              <button
                onClick={() => setViewData(null)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>

              <h3 className="text-lg font-semibold text-yellow-700 mb-4 border-b border-yellow-50 pb-2">
                Objective Details
              </h3>

              <div className="space-y-2 text-yellow-800 text-sm">
                <p>
                  <strong>Define Scope of Work:</strong> {viewData.scopeOfWork}
                </p>
                <p>
                  <strong>Time Required (in months):</strong>{" "}
                  {viewData.timeRequired}
                </p>
                <p>
                  <strong>Activities to be Undertaken:</strong>{" "}
                  {viewData.activities}
                </p>
                <p>
                  <strong>Contribution by Applicant (in INR):</strong>{" "}
                  {viewData.contribution}
                </p>
                <p>
                  <strong>Grants from TTDF (in INR):</strong> {viewData.grants}
                </p>
              </div>

              <div className="flex justify-end mt-6">
                <button
                  onClick={() => setViewData(null)}
                  className="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      <div className="flex justify-end mt-8">
        <button
          type="button"
          className="bg-yellow-600 text-white px-6 py-2 rounded hover:bg-yellow-700 font-semibold"
          onClick={() => {
            console.log("Objective Wise Activities & Timeline:", rows);
          }}
        >
          Save
        </button>
      </div>
    </motion.div>
  );
};

export default Objective;
