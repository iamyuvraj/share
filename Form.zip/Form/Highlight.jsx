import React from 'react'
import { motion } from 'framer-motion';
const LabelRequired = ({ label }) => (
  <label className="block text-sm font-medium mb-1 text-yellow-800">
    {label} <span className="text-red-600">*</span>
  </label>
);const Input = ({ label, placeholder, type = "text", required = false }) => (
  <div>
    {label && (
      <label className="block text-sm font-medium mb-1 text-yellow-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
    )}
    <input
      type={type}
      placeholder={placeholder}
      required={required}
      className="w-full p-2 border border-yellow-300 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
    />
  </div>
);
const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};
const Highlight = () => {
  return (
<motion.div className=" flex justify-center "
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}>
      <div className="w-full ">
        <form
          
          onSubmit={(e) => e.preventDefault()}
        >
          <h2 className="text-2xl font-bold text-yellow-800 mb-8 text-center border-b-2 border-yellow-900">
            Essence of the Proposal Highlighting the Following Aspects
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <Input label="Significance & Impact/Value of Proposal"/>
              <Input label="Inventive Step/Innovation" />
              <Input label="Commercialization Potential" />
              <Input label="Risk Factors" />
              <Input label="National and International Status of Proposed Technology or Product" />

             
            </div>

            <div className="space-y-4">
              <Input label="Rationale" />
              <Input label="National Importance / Social Relevance" />
              <Input label="Potential Competitors" />
              <Input label="Has the Preliminary work been done so far?" required />
              <Input label="Business Strategy" required />
            </div>
          </div>

         
        </form>
      </div>
    </motion.div>  )
}
export default Highlight