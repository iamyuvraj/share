import React, { useState } from "react";
import Sourceex from "../../tables/Sourceex";
import Sourcedt from "../../tables/Sourcedt";
import { motion } from "framer-motion";

const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const Budget = () => {
  const tabs = [
    { name: "Source Detail", key: "sourcedt" },
    { name: "Expected Source  ", key: "sourceex" },
  ];

  const [activeTab, setActiveTab] = useState("sourcedt");
  return (

      <motion.div className="max-w-7xl "
        variants={boxVariants}
        initial="hidden"
        animate="visible"
        transition={{ duration: 0.5 }}>
        <h2 className="text-2xl font-semibold text-yellow-800 mb-8 flex flex-col items-center gap-2 border-b-2 border-yellow-900">
           Finnacial Budget Details
        </h2>

        <nav className="mb-6 flex space-x-6">
          {tabs.map(({ name, key }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className={
                "pb-2 font-medium transition-all duration-200 " +
                (activeTab === key
                  ? "text-yellow-800 border-b-2 border-yellow-600"
                  : "text-yellow-600 hover:border-yellow-400 border-b-2 border-transparent")
              }
            >
              {name}
            </button>
          ))}
        </nav>

        <div>
          {activeTab === "sourcedt" && <Sourcedt />}
          {activeTab === "sourceex" && <Sourceex />}
        </div>

      
      </motion.div>
        
  );
};

export default Budget;
