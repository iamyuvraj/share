import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};
const Finance = () => {
  const formRef = useRef(null);
  const [alertMessage, setAlertMessage] = useState('');

  const [loanTaken, setLoanTaken] = useState('');
  const [loanType, setLoanType] = useState('');
  const [customLoanType, setCustomLoanType] = useState('');
  const [formData, setFormData] = useState({
    loanAmount: '',
    loanStatus: '',
    loanDate: '',
    bankName: '',
    bankType: '',
    branchName: '',
    accountNumber: '',
    ifscCode: '',
  });

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // Submit with full validation
  const handleSubmit = (e) => {
    e.preventDefault();
    setAlertMessage('');
    const form = formRef.current;
    if (!form) return;

    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    if (loanTaken === 'Yes') {
      if (!loanType) {
        setAlertMessage('Please select a Loan Type.');
        return;
      }
      if (loanType === 'Other' && !customLoanType.trim()) {
        setAlertMessage('Please specify the custom Loan Type.');
        return;
      }
    }

    setAlertMessage('Form submitted successfully!');
    // Proceed with final submission logic here
  };

  // Save as draft without validation
  const handleDraft = () => {
    setAlertMessage('');
    // Save draft logic here
    console.log('Draft saved', { loanTaken, loanType, customLoanType, formData });
  };

  // Updated common input/select classes with yellow-300 border & focus ring like Highlight.jsx
  const baseInputClass =
    "w-full p-2 border border-yellow-300  rounded focus:outline-none focus:ring-2 focus:ring-yellow-400";

  return (
    <motion.div className=" p-6 "
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}>
      <div className="text-yellow-800 border-b-2 border-yellow-900 flex justify-center mb-8 text-2xl font-semibold">
        <h2>Finance Details</h2>
      </div>

      {alertMessage && (
        <div className="mb-4 p-3 rounded border border-red-400 bg-red-100 text-red-800 font-semibold text-center">
          {alertMessage}
        </div>
      )}

      <form ref={formRef} onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="md:col-span-2 mt-4">
          <label className="block text-sm font-medium text-yellow-800 mb-1">
            Loan Taken? <span className="text-red-600">*</span>
          </label>
          <select
            value={loanTaken}
            onChange={(e) => setLoanTaken(e.target.value)}
            className={baseInputClass}
            required
          >
            <option value="">Select an option</option>
            <option value="Yes">Yes</option>
            <option value="No">No</option>
          </select>
        </div>

        {loanTaken === 'Yes' && (
          <>
            <div className="md:col-span-2 border-t border-yellow-200 mt-4 mb-2"></div>

            <div>
              <label className="block text-sm font-medium text-yellow-800 mb-1">
                Loan Amount(in lakhs) <span className="text-red-600">*</span>
              </label>
              <input
                type="number"
                value={formData.loanAmount}
                onChange={(e) => handleInputChange('loanAmount', e.target.value)}
                className={baseInputClass}
                required
                min="1"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-yellow-800 mb-1">
                Loan Type <span className="text-red-600">*</span>
              </label>
              <select
                value={loanType}
                onChange={(e) => setLoanType(e.target.value)}
                className={baseInputClass}
                required
              >
                <option value="">Select loan type</option>
                <option value="Term Loan">Term Loan</option>
                <option value="Working Capital">Working Capital</option>
                <option value="Overdraft">Overdraft</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {loanType === 'Other' && (
              <div>
                <label className="block text-sm font-medium text-yellow-800 mb-1">
                  Specify Loan Type <span className="text-red-600">*</span>
                </label>
                <input
                  type="text"
                  value={customLoanType}
                  onChange={(e) => setCustomLoanType(e.target.value)}
                  className={baseInputClass}
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-yellow-800 mb-1">
                Loan Status <span className="text-red-600">*</span>
              </label>
              <select
                value={formData.loanStatus}
                onChange={(e) => handleInputChange('loanStatus', e.target.value)}
                className={baseInputClass}
                required
              >
                <option value="">Select status</option>
                <option value="Sanctioned">Sanctioned</option>
                <option value="Pending">Pending</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-yellow-800 mb-1">
                Loan Sanction Date
              </label>
              <input
                type="date"
                value={formData.loanDate}
                onChange={(e) => handleInputChange('loanDate', e.target.value)}
                className={baseInputClass}
              />
            </div>
          </>
        )}

        <div className="md:col-span-2">
          <h3 className="text-lg font-bold text-yellow-800 mt-8 mb-4 border-b-2 border-yellow-900 pb-1">
            Bank Details
          </h3>
        </div>

       <div>
  <label className="block text-sm font-medium text-yellow-800 mb-1">
    Bank Name <span className="text-red-600">*</span>
  </label>
  <input
    type="text"
    value={formData.bankName}
    onChange={(e) => handleInputChange("bankName", e.target.value)}
    placeholder="Enter bank name"
    className={baseInputClass}
    required
  />
</div>

<div>
  <label className="block text-sm font-medium text-yellow-800 mb-1">
    Branch Name <span className="text-red-600">*</span>
  </label>
  <input
    type="text"
    value={formData.branchName}
    onChange={(e) => handleInputChange("branchName", e.target.value)}
    placeholder="Enter branch name"
    className={baseInputClass}
    required
  />
</div>

<div>
  <label className="block text-sm font-medium text-yellow-800 mb-1">
    Account Number <span className="text-red-600">*</span>
  </label>
  <input
    type="number"
    value={formData.accountNumber}
    onChange={(e) => handleInputChange("accountNumber", e.target.value)}
    placeholder="Enter account number"
    className={baseInputClass}
    required
  />
</div>

<div>
  <label className="block text-sm font-medium text-yellow-800 mb-1">
    IFSC Code <span className="text-red-600">*</span>
  </label>
  <input
    type="text"
    value={formData.ifscCode}
    onChange={(e) => handleInputChange("ifscCode", e.target.value)}
    placeholder="Enter ifsc code"
    className={baseInputClass}
    required
  />
</div>


        <div>
          <label className="block text-sm font-medium text-yellow-800 mb-1">
            Bank Type <span className="text-red-600">*</span>
          </label>
          <select
            value={formData.bankType}
            onChange={(e) => handleInputChange('bankType', e.target.value)}
            className={baseInputClass}
            required
          >
            <option value="">Select type</option>
            <option value="Public">Public Sector</option>
            <option value="Private">Private Sector</option>
            <option value="Co-operative">Co-operative</option>
          </select>
        </div>
       
        {/* Action Buttons */}
       
      </form>
    </motion.div>
  );
};

export default Finance;
