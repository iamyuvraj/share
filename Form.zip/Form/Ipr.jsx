import React, { useState } from "react";
import { FiUploadCloud } from "react-icons/fi";
import Licensed from "../../tables/Licensed";
import Ip from "../../tables/Ip";
import { motion } from "framer-motion";
const boxVariants = { 
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const Ipr = () => {
  const tabs = [
    { name: "Ip Table", key: "Ip" },
    { name: "Licensed Table", key: "Licensed" },
  ];

  const [activeTab, setActiveTab] = useState("Ip");

  const [formFields, setFormFields] = useState({
    previousSubmission: "",
    regulatoryInfo: "",
    incubationFacility: "",
    approvalDetails: "",
  });
const FileUpload = ({ label, required = false, accept = '', height = 'h-32' }) => {
  const [preview, setPreview] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result);
      reader.readAsDataURL(file);
    } else {
      setPreview(null);
    }
  };
}
  const handleFieldChange = (e) => {
    const { name, value } = e.target;
    setFormFields({ ...formFields, [name]: value });
  };

  return (
    <motion.div className="max-w-7xl mx-auto p-4"
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}>
      
      {/* Header */}
      <h2 className="text-2xl font-semibold text-yellow-800 mb-8 flex flex-col items-center gap-2 border-b-2 border-yellow-900">
        IP(intellectual Property) and Regularty Details
      </h2>

      {/* Budget Info Textareas */}
      <div className="grid grid-cols-2 gap-4 mb-6">
  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Project Name</label>
    <textarea
      rows="2"
      className="p-2 border border-yellow-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
  </div>

  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Estimated Budget</label>
    <textarea
      rows="2"
      className="p-2 border border-yellow-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
  </div>

  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Allocated Funds</label>
    <textarea
      rows="2"
      className="p-2 border border-yellow-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
  </div>

  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Expense Category</label>
    <textarea
      rows="2"
      className="p-2 border border-yellow-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
  </div>

  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Payment Mode</label>
    <textarea
      rows="2"
      className="p-2 border border-yellow-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
  </div>

  <div className="flex flex-col gap-2 mt-6">
    <label className="text-yellow-800 font-medium">Approved Date</label>
    <input
      type="date"
      className="p-2 border border-yellow-300 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500"
    />
  </div>
</div>


      {/* Tabs */}
      <nav className="mb-6 flex space-x-6">
        {tabs.map(({ name, key }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={
              "pb-2 font-medium transition-all duration-200 " +
              (activeTab === key
                ? "text-yellow-800 border-b-2 border-yellow-600"
                : "text-yellow-600 hover:border-yellow-400 border-b-2 border-transparent")
            }
          >
            {name}
          </button>
        ))}
      </nav>

      {/* Tab Content */}
      <div className="mb-8">
        {activeTab === "Ip" && <Ip />}
        {activeTab === "Licensed" && <Licensed />}
      </div>

      {/* Yes/No Questions and Approval Details */}
      <div className="space-y-6 bg-yellow-50 p-4 rounded border border-yellow-100">
        {[
          {
            label:
              "Have you ever submitted this related proposal before under any of the DoT Schemes?",
            name: "previousSubmission",
          },
          {
            label:
              "Does your solution have all the necessary regulatory approvals and certifications to sell in India?",
            name: "regulatoryInfo",
          },
          {
            label:
              "Are you incubated with any of the Recognized Incubation Facility?",
            name: "incubationFacility",
          },
        ].map(({ label, name }) => (
          <div key={name}>
            <label className="block text-yellow-800 font-medium mb-2">
              {label}
            </label>
            <div className="flex gap-6">
              {["Yes", "No"].map((option) => (
                <label key={option} className="flex items-center gap-2 text-yellow-700">
                  <input
                    type="radio"
                    name={name}
                    value={option}
                    checked={formFields[name] === option}
                    onChange={handleFieldChange}
                  />
                  {option}
                </label>
              ))}
            </div>
          </div>
        ))}

        <div>
          <label className="block text-yellow-800 font-medium mb-2">
            Approval Details
          </label>
          <textarea
            name="approvalDetails"
            value={formFields.approvalDetails}
            onChange={handleFieldChange}
            rows="4"
            className="w-full p-2 border border-yellow-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
      </div>

     {/* Border Separator */}
<div className="border-t-2 border-yellow-900 mt-4 mb-6" />

{/* File Upload Fields */}
<div className="grid grid-cols-2 gap-4 mb-6">
  {/* Upload: DoT Activities */}
  <div className="flex flex-col gap-2 ">
    <label className="text-yellow-800 font-medium">
      Is the product/technology related to present activities/products being developed by DoT? 
      If so, how does the product tie in with present activities/products being developed by DoT?
    </label>
    <div className="flex items-center border border-yellow-300 rounded-md bg-yellow-50 p-2 focus-within:ring-2 focus-within:ring-yellow-500">
      <FiUploadCloud className="text-yellow-600 mr-2" size={18} />
      <input type="file" className="w-full bg-yellow-50 focus:outline-none" />
    </div>
  </div>

  {/* Upload: IP Rights Ownership */}
  <div className="flex flex-col gap-2 mt-6">
    <label className="text-yellow-800 font-medium ">
      Is this Proposal Based on Intellectual Property rights owned by the Applicant/Collaborator/Licensed From Abroad?
    </label>
    <div className="flex items-center border border-yellow-300 rounded-md bg-yellow-50 p-2 focus-within:ring-2 focus-within:ring-yellow-500 mt-5.5">
      <FiUploadCloud className="text-yellow-600 mr-2" size={18} />
      <input type="file" className="w-full bg-yellow-50 focus:outline-none" />
    </div>
  </div>

  {/* Upload: IP Ownership Details */}
  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">
      Provide Details of IP Proposal Ownership by:
    </label>
    <div className="flex items-center border border-yellow-300 rounded-md bg-yellow-50 p-2 focus-within:ring-2 focus-within:ring-yellow-500">
      <FiUploadCloud className="text-yellow-600 mr-2" size={18} />
      <input type="file" className="w-full bg-yellow-50 focus:outline-none" />
    </div>
  </div>

  {/* Upload: IP Proposal */}
  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">IP Proposal</label>
    <div className="flex items-center border border-yellow-300 rounded-md bg-yellow-50 p-2 focus-within:ring-2 focus-within:ring-yellow-500">
      <FiUploadCloud className="text-yellow-600 mr-2" size={18} />
      <input type="file" className="w-full bg-yellow-50 focus:outline-none" />
    </div>
  </div>

  {/* Upload: Potential Impact */}
  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Potential Impact</label>
    <div className="flex items-center border border-yellow-300 rounded-md bg-yellow-50 p-2 focus-within:ring-2 focus-within:ring-yellow-500">
      <FiUploadCloud className="text-yellow-600 mr-2" size={18} />
      <input type="file" className="w-full bg-yellow-50 focus:outline-none" />
    </div>
  </div>

  {/* Upload: Patent */}
  <div className="flex flex-col gap-2">
    <label className="text-yellow-800 font-medium">Upload Patent/Patent Applied for</label>
    <div className="flex items-center border border-yellow-300 rounded-md bg-yellow-50 p-2 focus-within:ring-2 focus-within:ring-yellow-500">
      <FiUploadCloud className="text-yellow-600 mr-2" size={18} />
      <input type="file" className="w-full bg-yellow-50 focus:outline-none" />
    </div>
  </div>
</div>

    </motion.div>
  );
};

export default Ipr;
