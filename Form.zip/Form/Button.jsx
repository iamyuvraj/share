import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const steps = [
  { name: "Basic Form", path: "/" },
  { name: "Organization Details", path: "/organization" },
  { name: "Proposal Summary", path: "/proposal" },
  { name: "Available Staff Assets", path: "/available" },
  { name: "Collaborator Details", path: "/collaborator" },
  { name: "Finance Details", path: "/finance" },
  { name: "Highlight Proposal", path: "/highlight" },
  { name: "IPR Details", path: "/ipr" },
  { name: "Patents", path: "/patents" },
  { name: "Manpower Details", path: "/manpower" },
  { name: "Finance Budget", path: "/budget" },
  { name: "Objective Wise Timelines", path: "/objective" },
  { name: "Declaration Document", path: "/declaration" },
];
const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};
const Button = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const currentIndex = steps.findIndex((step) => step.path === location.pathname);
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === steps.length - 1;

  const goToStep = (offset) => {
    const newIndex = currentIndex + offset;
    if (newIndex >= 0 && newIndex < steps.length) {
      navigate(steps[newIndex].path);
    }
  };

  const handleNext = () => {
    if (isLast) {
      alert("Form submitted!");
    } else {
      goToStep(1);
    }
  };

  return (
    <motion.div className="flex justify-between mt-6 "
      variants={boxVariants} 
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}>
      {!isFirst ? (
        <button
          className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded hover:bg-yellow-200"
          onClick={() => goToStep(-1)}
        >
          Previous
        </button>
      ) : <div></div>}

      <div className="flex gap-4">
        <button className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded hover:bg-yellow-200">
          Save as Draft
        </button>
        <button
          className="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
          onClick={handleNext}
        >
          {isLast ? "Submit" : "Next"}
        </button>
      </div>
    </motion.div>
  );
};

export default Button;
