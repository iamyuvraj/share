import React, { useCallback } from "react";
import { FiSave, FiX } from "react-icons/fi";
import { FileText, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { useDropzone } from "react-dropzone";

const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const FundDetails = ({ formData, onFormDataChange }) => {
  const onDrop = useCallback(
    (acceptedFiles) => {
      const pdfFiles = acceptedFiles
        .filter((file) => file.type === "application/pdf" && file.size <= 10 * 1024 * 1024)
        .map((file) => ({
          file,
          preview: URL.createObjectURL(file),
        }));
      const updatedFiles = [...formData.loanDocuments, ...pdfFiles].slice(0, 5); // Cap at 5 files
      onFormDataChange({
        ...formData,
        loanDocuments: updatedFiles,
      });
    },
    [formData, onFormDataChange]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "application/pdf": [".pdf"] },
    multiple: true,
    maxFiles: 5,
    noClick: false,
    noKeyboard: false,
  });

  const removeFile = (index) => {
    const updatedFiles = formData.loanDocuments.filter((_, i) => i !== index);
    onFormDataChange({
      ...formData,
      loanDocuments: updatedFiles,
    });
  };

  const resetForm = () => {
    onFormDataChange({
      hasLoan: "",
      loanDescription: "",
      loanAmount: "",
      loanDocuments: [],
    });
  };

  const handleSave = () => {
    console.log("Fund Details Data:", formData);
  };

  const handleHasLoanChange = (e) => {
    onFormDataChange({
      ...formData,
      hasLoan: e.target.value,
    });
  };

  const handleLoanDescriptionChange = (e) => {
    onFormDataChange({
      ...formData,
      loanDescription: e.target.value,
    });
  };

  const handleLoanAmountChange = (e) => {
    onFormDataChange({
      ...formData,
      loanAmount: e.target.value,
    });
  };

  return (
    <motion.div
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      <div className="p-6">
        <h3 className="text-2xl font-semibold text-yellow-800 mb-8 flex flex-col items-center gap-2 border-b-2 border-amber-800">
          Outstanding Loan Details
        </h3>

        <div className="bg-white border border-amber-200 rounded p-6 shadow-sm max-w-3xl mx-auto">
          {/* Has Loan Radio Buttons */}
          <div className="mb-6">
            <label className="block text-yellow-800 font-medium mb-2">
              Is There Any Outstanding Loan?
            </label>
            <div className="flex items-center gap-6">
              {[
                { label: "Yes", value: "Yes" },
                { label: "No", value: "No" },
              ].map((opt) => (
                <label
                  key={opt.value}
                  className="flex items-center gap-2 text-yellow-700"
                >
                  <input
                    type="radio"
                    value={opt.value}
                    checked={formData.hasLoan === opt.value}
                    onChange={handleHasLoanChange}
                  />
                  {opt.label}
                </label>
              ))}
            </div>
          </div>

          {/* Conditional Loan Fields */}
          {formData.hasLoan === "Yes" && (
            <>
              {/* Description */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-yellow-800 mb-1">
                  Loan Description <span className="text-red-600">*</span>
                </label>
                <textarea
                  value={formData.loanDescription}
                  onChange={handleLoanDescriptionChange}
                  rows={4}
                  required
                  placeholder="Enter description"
                  className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                />
              </div>

              {/* Amount */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-yellow-800 mb-1">
                  Loan Amount (INR) <span className="text-red-600">*</span>
                </label>
                <input
                  type="number"
                  value={formData.loanAmount}
                  onChange={handleLoanAmountChange}
                  required
                  placeholder="Enter amount"
                  className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                />
              </div>

              {/* Drag & Drop Uploader */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-yellow-800 mb-1">
                  Upload Loan Documents (PDF)
                </label>

                {/* Dropzone Area */}
                <div
                  {...getRootProps()}
                  className={`flex flex-col items-center justify-center w-full p-6 border-2 border-dashed rounded transition ${
                    isDragActive
                      ? "border-amber-600 bg-amber-50"
                      : "border-amber-300 bg-amber-50 hover:bg-amber-100"
                  } cursor-pointer`}
                >
                  <input {...getInputProps()} />
                  <FileText className="w-8 h-8 text-amber-700 mb-2" />
                  {isDragActive ? (
                    <p className="text-amber-700 font-medium">
                      Drop the PDF(s) here…
                    </p>
                  ) : (
                    <>
                      <p className="text-amber-700 font-medium">
                        Drag & drop PDF(s) or click to browse
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Max 5 files, 10 MB each
                      </p>
                    </>
                  )}
                </div>

                {/* File List */}
                {formData.loanDocuments.length > 0 && (
                  <ul className="mt-3 space-y-2">
                    {formData.loanDocuments.map((doc, index) => (
                      <li
                        key={index}
                        className="flex items-center justify-between bg-amber-100 rounded p-2"
                      >
                        <span className="flex items-center gap-2 text-amber-800 text-sm">
                          <FileText className="w-4 h-4" />
                          {doc.file.name} ( {(doc.file.size / 1024).toFixed(1)} KB )
                        </span>
                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="text-rose-600 hover:text-rose-700"
                          title="Remove"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 mt-6">
            <button
              onClick={resetForm}
              className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 flex items-center gap-1"
            >
              <FiX /> Reset
            </button>
            <button
              onClick={handleSave}
              className="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800 flex items-center gap-1"
            >
              <FiSave /> Save
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default FundDetails;