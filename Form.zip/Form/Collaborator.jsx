import React, { useState, useEffect, useCallback } from "react";
import {
  FiPlus,
  FiX,
  FiEye,
  FiEdit,
  FiTrash2,
  FiFileText,
} from "react-icons/fi";
import { motion } from "framer-motion";

const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const Collaborator = ({ initialFormData = {}, onFormDataChange }) => {
  // Initialize local form data state
  const [formData, setFormData] = useState({
    collaborators: [],
    shareHolders: [],
    subShareHolders: [],
    rdStaff: [],
    equipments: [],
    ttdfAppliedBefore: "",
    ...initialFormData,
  });

  // Form visibility states
  const [formVisible, setFormVisible] = useState(false);
  const [shareFormVisible, setShareFormVisible] = useState(false);
  const [subShareFormVisible, setSubShareFormVisible] = useState(false);
  const [rdStaffFormVisible, setRdStaffFormVisible] = useState(false);
  const [equipmentFormVisible, setEquipmentFormVisible] = useState(false);

  // Form data states
  const [collaboratorFormData, setCollaboratorFormData] = useState({
    contactPersonName: "",
    organizationName: "",
    organizationType: "",
    ttdfCompany: "",
    pan: "",
    mouFile: null,
    mouFileName: "",
    applicantType: "", // NEW FIELD
  });

  const [shareFormData, setShareFormData] = useState({
    shareHolderName: "",
    sharePercentage: "",
    identityDocument: null,
    identityDocumentName: "",
  });

  const [subShareFormData, setSubShareFormData] = useState({
    organizationName: "", // NEW FIELD
    shareHolderName: "",
    sharePercentage: "",
    identityDocument: null,
    identityDocumentName: "",
  });

  const [rdStaffFormData, setRdStaffFormData] = useState({
    name: "",
    designation: "",
    email: "",
    highestQualification: "",
    mobile: "",
    resume: null,
    resumePreview: null,
    epfDetails: "",
  });

  const [equipmentFormData, setEquipmentFormData] = useState({
    item: "",
    unitPrice: "",
    quantity: "",
    contributorType: "",
  });

  // Editing indices
  const [editingIndex, setEditingIndex] = useState(null);
  const [editingShareIndex, setEditingShareIndex] = useState(null);
  const [editingSubShareIndex, setEditingSubShareIndex] = useState(null);
  const [rdStaffEditIndex, setRdStaffEditIndex] = useState(null);
  const [equipmentEditIndex, setEquipmentEditIndex] = useState(null);

  // Image preview state
  const [selectedImage, setSelectedImage] = useState(null);
  const [showImageModal, setShowImageModal] = useState(false);

  // Initialize form data when props change
  useEffect(() => {
    setFormData((prev) => ({
      ...prev,
      ...initialFormData,
    }));
  }, [initialFormData]);

  // Memoize the form data update function
  const updateFormData = useCallback(
    (newData) => {
      setFormData((prev) => {
        const updatedData = {
          ...prev,
          ...newData,
        };
        onFormDataChange(updatedData);
        return updatedData;
      });
    },
    [onFormDataChange]
  );

  // Collaborator File Handlers
  const handleCollaboratorFileChange = (e, field) => {
    const file = e.target.files[0];
    if (file && file.type === "application/pdf") {
      setCollaboratorFormData((prev) => ({
        ...prev,
        [field]: file,
        [`${field}Name`]: file.name,
      }));
    }
  };

  // Collaborator Form Handlers
  const handleCollaboratorChange = (e) => {
    const { name, value } = e.target;
    setCollaboratorFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCollaboratorSubmit = (e) => {
    e.preventDefault();
    const updatedCollaborators = [...formData.collaborators];
    if (editingIndex !== null) {
      updatedCollaborators[editingIndex] = collaboratorFormData;
    } else {
      updatedCollaborators.push(collaboratorFormData);
    }
    updateFormData({
      collaborators: updatedCollaborators,
    });
    resetCollaboratorForm();
  };

  const resetCollaboratorForm = () => {
    setCollaboratorFormData({
      contactPersonName: "",
      organizationName: "",
      organizationType: "",
      ttdfCompany: "",
      pan: "",
      mouFile: null,
      mouFileName: "",
      applicantType: "", // NEW FIELD
    });
    setEditingIndex(null);
    setFormVisible(false);
  };

  const handleEditCollaborator = (index) => {
    setCollaboratorFormData(formData.collaborators[index]);
    setEditingIndex(index);
    setFormVisible(true);
  };

  const handleDeleteCollaborator = (index) => {
    if (window.confirm("Are you sure you want to delete this Collaborator?")) {
      const updatedCollaborators = formData.collaborators.filter(
        (_, i) => i !== index
      );
      updateFormData({
        collaborators: updatedCollaborators,
      });
    }
  };

  // Principal Shareholder Handlers (only 1 allowed)
  const handleShareFormChange = (e) => {
    const { name, value } = e.target;
    setShareFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleShareFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type === "application/pdf") {
      setShareFormData((prev) => ({
        ...prev,
        identityDocument: file,
        identityDocumentName: file.name,
      }));
    }
  };

  // Update handleShareSubmit to allow multiple share holders
  const handleShareSubmit = (e) => {
    e.preventDefault();
    const updatedShareHolders = [...formData.shareHolders];
    if (editingShareIndex !== null) {
      updatedShareHolders[editingShareIndex] = shareFormData;
    } else {
      updatedShareHolders.push(shareFormData);
    }
    updateFormData({
      shareHolders: updatedShareHolders,
    });
    resetShareForm();
  };

  const resetShareForm = () => {
    setShareFormData({
      shareHolderName: "",
      sharePercentage: "",
      identityDocument: null,
      identityDocumentName: "",
    });
    setEditingShareIndex(null);
    setShareFormVisible(false);
  };

  // Update handleEditShare to accept index
  const handleEditShare = (index) => {
    setShareFormData(formData.shareHolders[index]);
    setEditingShareIndex(index);
    setShareFormVisible(true);
  };

  // Update handleDeleteShare to accept index
  const handleDeleteShare = (index) => {
    const updatedShareHolders = formData.shareHolders.filter(
      (_, i) => i !== index
    );
    updateFormData({
      shareHolders: updatedShareHolders,
    });
  };

  // Sub-Applicant Shareholder Handlers (multiple allowed)
  const handleSubShareFormChange = (e) => {
    const { name, value } = e.target;
    setSubShareFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubShareFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type === "application/pdf") {
      setSubShareFormData((prev) => ({
        ...prev,
        identityDocument: file,
        identityDocumentName: file.name,
      }));
    }
  };

  const handleSubShareSubmit = (e) => {
    e.preventDefault();
    const updatedSubShareHolders = [...formData.subShareHolders];
    if (editingSubShareIndex !== null) {
      updatedSubShareHolders[editingSubShareIndex] = subShareFormData;
    } else {
      updatedSubShareHolders.push(subShareFormData);
    }
    updateFormData({
      subShareHolders: updatedSubShareHolders,
    });
    resetSubShareForm();
  };

  const resetSubShareForm = () => {
    setSubShareFormData({
      organizationName: "", // NEW FIELD
      shareHolderName: "",
      sharePercentage: "",
      identityDocument: null,
      identityDocumentName: "",
    });
    setEditingSubShareIndex(null);
    setSubShareFormVisible(false);
  };

  const handleEditSubShare = (index) => {
    setSubShareFormData(formData.subShareHolders[index]);
    setEditingSubShareIndex(index);
    setSubShareFormVisible(true);
  };

  const handleDeleteSubShare = (index) => {
    const updated = formData.subShareHolders.filter((_, i) => i !== index);
    updateFormData({
      subShareHolders: updated,
    });
  };

  // R&D Staff Form Handlers
  const handleRdStaffChange = (e) => {
    const { name, value } = e.target;
    setRdStaffFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleRdStaffFileChange = (e) => {
    const file = e.target.files[0];
    const preview =
      file && file.type.startsWith("image/") ? URL.createObjectURL(file) : null;
    setRdStaffFormData((prev) => ({
      ...prev,
      resume: file,
      resumePreview: preview,
    }));
  };

  const handleRdStaffSubmit = (e) => {
    e.preventDefault();
    const updatedRdStaff = [...formData.rdStaff];
    if (rdStaffEditIndex !== null) {
      updatedRdStaff[rdStaffEditIndex] = rdStaffFormData;
    } else {
      updatedRdStaff.push(rdStaffFormData);
    }
    updateFormData({
      rdStaff: updatedRdStaff,
    });
    resetRdStaffForm();
  };

  const resetRdStaffForm = () => {
    setRdStaffFormData({
      name: "",
      designation: "",
      email: "",
      highestQualification: "",
      mobile: "",
      resume: null,
      resumePreview: null,
      epfDetails: "",
    });
    setRdStaffEditIndex(null);
    setRdStaffFormVisible(false);
  };

  const handleRdStaffEdit = (index) => {
    setRdStaffFormData(formData.rdStaff[index]);
    setRdStaffEditIndex(index);
    setRdStaffFormVisible(true);
  };

  const handleRdStaffDelete = (index) => {
    if (window.confirm("Are you sure you want to delete this staff?")) {
      const updatedRdStaff = formData.rdStaff.filter((_, i) => i !== index);
      updateFormData({
        rdStaff: updatedRdStaff,
      });
    }
  };

  // Equipment Form Handlers
  const handleEquipmentChange = (e) => {
    const { name, value } = e.target;
    setEquipmentFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleEquipmentSubmit = (e) => {
    e.preventDefault();
    const updatedEquipment = [...formData.equipments];
    if (equipmentEditIndex !== null) {
      updatedEquipment[equipmentEditIndex] = equipmentFormData;
    } else {
      updatedEquipment.push(equipmentFormData);
    }
    updateFormData({
      equipment: updatedEquipment,
    });
    resetEquipmentForm();
  };

  const resetEquipmentForm = () => {
    setEquipmentFormData({
      item: "",
      unitPrice: "",
      quantity: "",
      contributorType: "",
    });
    setEquipmentEditIndex(null);
    setEquipmentFormVisible(false);
  };

  const handleEquipmentEdit = (index) => {
    setEquipmentFormData(formData.equipments[index]);
    setEquipmentEditIndex(index);
    setEquipmentFormVisible(true);
  };

  const handleEquipmentDelete = (index) => {
    if (window.confirm("Are you sure you want to delete this entry?")) {
      const updatedEquipment = formData.equipments.filter((_, i) => i !== index);
      updateFormData({
        equipments: updatedEquipment,
      });
    }
  };

  // TTDF Applied Before Handler
  const handleTtdfAppliedBeforeChange = (e) => {
    updateFormData({
      ttdfAppliedBefore: e.target.value,
    });
  };

  // Equipment Totals
  const equipmentTotals = formData.equipments.reduce(
    (acc, row) => {
      const unitPrice = Number(row.unitPrice) || 0;
      const quantity = Number(row.quantity) || 0;
      const amount = unitPrice * quantity;
      acc.unitPrice += unitPrice;
      acc.quantity += quantity;
      acc.amount += amount;
      return acc;
    },
    { unitPrice: 0, quantity: 0, amount: 0 }
  );

  return (
    <motion.div
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      <div className="p-6">
        {/* Collaborator Table */}
        <h3 className="text-2xl font-semibold text-yellow-800 mb-8 flex flex-col items-center gap-2 border-b-2 border-amber-800">
          Consortium Partner Details
        </h3>
        <div className="overflow-auto rounded border border-amber-200 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-amber-100 text-yellow-800 border-y border-amber-200">
              <tr>
                <th className="px-3 py-2">S. No.</th>
                <th className="px-3 py-2">Contact Person Name</th>
                <th className="px-3 py-2">
                  Organization Name (Legal Entity Name)
                </th>
                <th className="px-3 py-2">Company as per CFP</th>
                <th className="px-3 py-2">Organization PAN No.</th>
                <th className="px-3 py-2">MoU</th>
                <th className="px-3 py-2">Type of Applicant</th>{" "}
                {/* NEW COLUMN */}
                <th className="px-3 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {formData.collaborators.length > 0 ? (
                formData.collaborators.map((row, index) => (
                  <tr
                    key={index}
                    className={index % 2 === 0 ? "bg-amber-50" : "bg-amber-100"}
                  >
                    <td className="px-3 py-2 border-y border-amber-200">
                      {index + 1}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {row.contactPersonName}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {row.organizationName}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {row.ttdfCompany}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {row.pan || "N/A"}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {row.mouFileName ? (
                        <span className="flex items-center gap-2 text-amber-700">
                          <FiFileText /> {row.mouFileName}
                        </span>
                      ) : (
                        "N/A"
                      )}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {row.applicantType || "N/A"}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200 text-yellow-800 font-medium flex gap-4">
                      <button
                        onClick={() => handleEditCollaborator(index)}
                        title="Edit"
                        className="hover:text-green-600"
                      >
                        <FiEdit size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteCollaborator(index)}
                        title="Delete"
                        className="hover:text-red-600"
                      >
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="8"
                    className="text-center text-amber-700 italic py-4"
                  >
                    No collaborators added yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-6">
          <button
            className="flex items-center gap-2 text-amber-700 hover:text-amber-900 font-medium"
            onClick={() => {
              setCollaboratorFormData({
                contactPersonName: "",
                organizationName: "",
                organizationType: "",
                ttdfCompany: "",
                pan: "",
                mouFile: null,
                mouFileName: "",
                applicantType: "", // NEW FIELD
              });
              setEditingIndex(null);
              setFormVisible(true);
            }}
          >
            <FiPlus className="text-lg" />
            Add Collaborator
          </button>
        </div>

        {/* Principal Share Holders Table */}
        <h3 className="text-2xl font-semibold text-yellow-800 mt-12 mb-8 flex flex-col items-center gap-2 border-b-2 border-amber-800">
          Share Holder Details of Principal Applicant
        </h3>
        <div className="overflow-auto rounded border border-amber-200 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-amber-100 text-yellow-800 border-y border-amber-200">
              <tr>
                <th className="px-3 py-2">S. No.</th>
                <th className="px-3 py-2">Share Holder Name</th>
                <th className="px-3 py-2">Percentage of Share</th>
                <th className="px-3 py-2">Passport/Aadhaar</th>
                <th className="px-3 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {formData.shareHolders.length > 0 ? (
                formData.shareHolders.map((holder, index) => (
                  <tr
                    key={index}
                    className={index % 2 === 0 ? "bg-amber-50" : "bg-amber-100"}
                  >
                    <td className="px-3 py-2 border-y border-amber-200">
                      {index + 1}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.shareHolderName}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.sharePercentage}%
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.identityDocumentName ? (
                        <span className="flex items-center gap-2 text-amber-700">
                          <FiFileText /> {holder.identityDocumentName}
                        </span>
                      ) : (
                        "N/A"
                      )}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200 flex gap-4 text-yellow-800 font-medium">
                      <button
                        onClick={() => handleEditShare(index)}
                        title="Edit"
                        className="hover:text-green-600"
                      >
                        <FiEdit size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteShare(index)}
                        title="Delete"
                        className="hover:text-red-600"
                      >
                        <FiTrash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="5"
                    className="text-center italic py-4 text-amber-700"
                  >
                    No share holders added yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-6">
          <button
            className={`flex items-center gap-2 font-medium px-4 py-2 rounded
    ${
      formData.shareHolders.length >= 20
        ? "text-gray-400 cursor-not-allowed bg-gray-100"
        : "text-amber-700 hover:text-amber-900"
    }
  `}
            onClick={() => {
              setShareFormData({
                shareHolderName: "",
                sharePercentage: "",
                identityDocument: null,
                identityDocumentName: "",
              });
              setEditingShareIndex(null);
              setShareFormVisible(true);
            }}
            disabled={formData.shareHolders.length >= 20}
            title={
              formData.shareHolders.length >= 20
                ? "Maximum 20 Share Holders allowed"
                : ""
            }
          >
            <FiPlus />
            Add Share Holder
          </button>
        </div>

        {/* Sub-Applicant Share Holders Table */}
        <h3 className="text-2xl font-semibold text-yellow-800 mt-12 mb-8 flex flex-col items-center gap-2 border-b-2 border-amber-800">
          Share Holder Details of Consortium Partners
        </h3>
        <div className="overflow-auto rounded border border-amber-200 shadow-sm">
          <table className="min-w-full text-sm text-left bg-white">
            <thead className="bg-amber-100 text-yellow-800 border-y border-amber-200">
              <tr>
                <th className="px-3 py-2">S. No.</th>
                <th className="px-3 py-2">Organization Name</th>{" "}
                {/* NEW COLUMN */}
                <th className="px-3 py-2">Share Holder Name</th>
                <th className="px-3 py-2">Percentage of Share</th>
                <th className="px-3 py-2">Passport/Aadhaar</th>
                <th className="px-3 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {(formData.subShareHolders || []).length > 0 ? (
                formData.subShareHolders.map((holder, index) => (
                  <tr
                    key={index}
                    className={index % 2 === 0 ? "bg-amber-50" : "bg-amber-100"}
                  >
                    <td className="px-3 py-2 border-y border-amber-200">
                      {index + 1}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.organizationName || "N/A"}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.shareHolderName}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.sharePercentage}%
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200">
                      {holder.identityDocumentName ? (
                        <span className="flex items-center gap-2 text-amber-700">
                          <FiFileText /> {holder.identityDocumentName}
                        </span>
                      ) : (
                        "N/A"
                      )}
                    </td>
                    <td className="px-3 py-2 border-y border-amber-200 flex gap-4 text-yellow-800 font-semibold">
                      <button
                        onClick={() => handleEditSubShare(index)}
                        title="Edit"
                        className="hover:text-green-600"
                      >
                        <FiEdit size={18} />
                      </button>
                      <button
                        onClick={() => handleDeleteSubShare(index)}
                        title="Delete"
                        className="hover:text-red-600"
                      >
                        <FiTrash2 />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan="6"
                    className="text-center italic py-4 text-amber-700"
                  >
                    No sub-applicants added yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-6">
          <button
            className="flex items-center gap-2 text-amber-700 hover:text-amber-900 font-medium"
            onClick={() => {
              setSubShareFormData({
                organizationName: "", // NEW FIELD
                shareHolderName: "",
                sharePercentage: "",
                identityDocument: null,
                identityDocumentName: "",
              });
              setEditingSubShareIndex(null);
              setSubShareFormVisible(true);
            }}
          >
            <FiPlus />
            Add Sub-Applicant Share Holder
          </button>
        </div>

        {/* Collaborator Modal */}
        {formVisible && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-2xl w-[500px] max-h-[90vh] overflow-y-auto relative border border-amber-200">
              <button
                onClick={() => setFormVisible(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>
              <form onSubmit={handleCollaboratorSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Contact Person Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="contactPersonName"
                    value={collaboratorFormData.contactPersonName}
                    onChange={handleCollaboratorChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Organization Name (Legal Entity Name){" "}
                    <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="organizationName"
                    value={collaboratorFormData.organizationName}
                    onChange={handleCollaboratorChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Company as per CFP <span className="text-red-600">*</span>
                  </label>
                  <select
                    required
                    className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
                    name="ttdfCompany"
                    value={collaboratorFormData.ttdfCompany}
                    onChange={handleCollaboratorChange}
                  >
                    <option value="" disabled>
                      Select
                    </option>
                    <option>
                      Domestic Company with focus on Telecom R&D, Use Case
                      Development
                    </option>
                    <option>Start-ups/MSMEs</option>
                    <option>Academic Institutions</option>
                    <option>
                      R&D Institutions, Section 8 Companies/Societies, Central &
                      State Government Entities/PSUs/Autonomous
                      Bodies/SPVs/Limited Liability Partnerships
                    </option>
                  </select>
                </div>
                {/* <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    PAN<span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="pan"
                    value={collaboratorFormData.pan}
                    onChange={handleCollaboratorChange}
                    required
                    pattern="[A-Za-z0-9]+"
                    title="Please enter alphanumeric characters only"
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div> */}
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Organization PAN No. <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="pan"
                    value={collaboratorFormData.pan}
                    onChange={(e) => {
                      const value = e.target.value.toUpperCase().slice(0, 10);
                      if (/^[A-Za-z0-9]*$/.test(value)) {
                        handleCollaboratorChange({
                          target: { name: "pan", value },
                        });
                      }
                    }}
                    required
                    pattern="[A-Za-z0-9]{1,10}"
                    title="Please enter up to 10 alphanumeric characters only"
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    MoU (.pdf) <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="file"
                    accept=".pdf"
                    required
                    onChange={(e) => handleCollaboratorFileChange(e, "mouFile")}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                  {collaboratorFormData.mouFileName && (
                    <span className="block mt-2 text-xs text-amber-700">
                      <FiFileText className="inline mr-1" />
                      {collaboratorFormData.mouFileName}
                    </span>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Type of Applicant <span className="text-red-600">*</span>
                  </label>
                  <select
                    name="applicantType"
                    value={collaboratorFormData.applicantType}
                    onChange={handleCollaboratorChange}
                    required
                    className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
                  >
                    <option value="" disabled>
                      Select
                    </option>
                    <option value="Principal Applicant">
                      Principal Applicant
                    </option>
                    <option value="Consortium Partner">
                      Consortium Partner
                    </option>
                  </select>
                </div>
                <div className="flex justify-end gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => setFormVisible(false)}
                    className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800"
                  >
                    {editingIndex !== null ? "Update" : "Add"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Principal Share Holder Modal */}
        {shareFormVisible && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-2xl w-[500px] max-h-[90vh] overflow-y-auto relative border border-amber-200">
              <button
                onClick={() => setShareFormVisible(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>
              <form onSubmit={handleShareSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Share Holder Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="shareHolderName"
                    value={shareFormData.shareHolderName}
                    onChange={handleShareFormChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Percentage of Share <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    name="sharePercentage"
                    value={shareFormData.sharePercentage}
                    onChange={handleShareFormChange}
                    required
                    min={0}
                    max={100}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Passport/Aadhaar (.pdf) <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="file"
                    accept=".pdf"
                    required
                    onChange={handleShareFileChange}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                  {shareFormData.identityDocumentName && (
                    <span className="block mt-2 text-xs text-amber-700">
                      <FiFileText className="inline mr-1" />
                      {shareFormData.identityDocumentName}
                    </span>
                  )}
                </div>
                <div className="flex justify-end gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => setShareFormVisible(false)}
                    className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800"
                  >
                    {editingShareIndex !== null ? "Update" : "Add"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Sub-Applicant Share Holder Modal */}
        {subShareFormVisible && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-2xl w-[500px] max-h-[90vh] overflow-y-auto relative border border-amber-200">
              <button
                onClick={() => setSubShareFormVisible(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>
              <form onSubmit={handleSubShareSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Organization Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="organizationName"
                    value={subShareFormData.organizationName}
                    onChange={handleSubShareFormChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Share Holder Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="shareHolderName"
                    value={subShareFormData.shareHolderName}
                    onChange={handleSubShareFormChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Percentage of Share <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    name="sharePercentage"
                    value={subShareFormData.sharePercentage}
                    onChange={handleSubShareFormChange}
                    required
                    min={0}
                    max={100}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Passport/Aadhaar (.pdf) <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="file"
                    accept=".pdf"
                    required
                    onChange={handleSubShareFileChange}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                  {subShareFormData.identityDocumentName && (
                    <span className="block mt-2 text-xs text-amber-700">
                      <FiFileText className="inline mr-1" />
                      {subShareFormData.identityDocumentName}
                    </span>
                  )}
                </div>
                <div className="flex justify-end gap-4 pt-2">
                  <button
                    type="button"
                    onClick={() => setSubShareFormVisible(false)}
                    className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800"
                  >
                    {editingSubShareIndex !== null ? "Update" : "Add"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* R&D Staff Modal */}
        {rdStaffFormVisible && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-2xl w-[700px] max-h-[90vh] overflow-y-auto relative border border-amber-200">
              <button
                onClick={() => setRdStaffFormVisible(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>
              <form
                onSubmit={handleRdStaffSubmit}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Name <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={rdStaffFormData.name}
                    onChange={handleRdStaffChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber.movie-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Designation <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="designation"
                    value={rdStaffFormData.designation}
                    onChange={handleRdStaffChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Email <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={rdStaffFormData.email}
                    onChange={handleRdStaffChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Highest Qualification{" "}
                    <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="highestQualification"
                    value={rdStaffFormData.highestQualification}
                    onChange={handleRdStaffChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Mobile No. <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="mobile"
                    value={rdStaffFormData.mobile}
                    onChange={handleRdStaffChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Resume (PDF/Image)
                  </label>
                  <input
                    type="file"
                    accept=".pdf,image/*"
                    onChange={handleRdStaffFileChange}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                  {rdStaffFormData.resumePreview && (
                    <span className="block mt-2 text-xs text-amber-700">
                      {rdStaffFormData.resume?.name || "File selected"}
                    </span>
                  )}
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Latest EPF Filing Details
                  </label>
                  <input
                    type="text"
                    name="epfDetails"
                    value={rdStaffFormData.epfDetails}
                    onChange={handleRdStaffChange}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div className="md:col-span-2 flex justify-end gap-4 mt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setRdStaffFormVisible(false);
                      setRdStaffEditIndex(null);
                      setRdStaffFormData({
                        name: "",
                        designation: "",
                        email: "",
                        highestQualification: "",
                        mobile: "",
                        resume: null,
                        resumePreview: null,
                        epfDetails: "",
                      });
                    }}
                    className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-amber-700 text-white px-4 py-2 rounded hover:bg-amber-800"
                  >
                    {rdStaffEditIndex !== null ? "Update" : "Add"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Equipment/Manpower/Consumable Modal */}
        {equipmentFormVisible && (
          <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
            <div className="bg-white p-6 rounded-lg shadow-2xl w-[600px] max-h-[90vh] overflow-y-auto relative border border-amber-200">
              <button
                onClick={() => setEquipmentFormVisible(false)}
                className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
              >
                <FiX className="text-xl" />
              </button>
              <form
                onSubmit={handleEquipmentSubmit}
                className="grid grid-cols-1 gap-4"
              >
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Item <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="text"
                    name="item"
                    value={equipmentFormData.item}
                    onChange={handleEquipmentChange}
                    required
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-yellow-800 mb-1">
                    Unit Price (INR) <span className="text-red-600">*</span>
                  </label>
                  <input
                    type="number"
                    name="unitPrice"
                    value={equipmentFormData.unitPrice}
                    onChange={handleEquipmentChange}
                    required
                    min={0}
                    className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                  />
                </div>
                <div>
                  <div>
                    <label className="block text-sm font-medium text-yellow-800 mb-1">
                      Quantity <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="number"
                      name="quantity"
                      value={equipmentFormData.quantity}
                      onChange={handleEquipmentChange}
                      required
                      min={0}
                      className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-yellow-800 mb-1">
                      Type of Contributor{" "}
                      <span className="text-red-600">*</span>
                    </label>
                    <input
                      type="text"
                      name="contributorType"
                      value={equipmentFormData.contributorType}
                      onChange={handleEquipmentChange}
                      required
                      className="w-full p-2 border border-amber-200 bg-amber-50 rounded"
                    />
                  </div>
                  <div className="flex justify-end gap-4 mt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setEquipmentFormVisible(false);
                        setEquipmentFormData(null);
                        setEquipmentFormData({
                          name: "",
                          unitPrice: "",
                          quantity: "",
                          equipmentType: "",
                        });
                      }}
                      className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-blue-amber-700 text-white px-4 py-2 rounded hover:bg-gray-300"
                    >
                      {editingEditIndex !== null ? "Update" : "Add"}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default Collaborator;
