import React, { useState } from "react";
import { FiUpload } from "react-icons/fi";
import { motion } from "framer-motion";

const LabelRequired = ({ label }) => (
  <label className="block text-sm font-medium mb-1 text-yellow-800">
    {label} <span className="text-red-600">*</span>
  </label>
);
const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};
const Declaration = () => {
  const [document, setDocument] = useState(null);
  const [checkboxes, setCheckboxes] = useState({
    statement1: false,
    statement2: false,
    statement3: false,
    statement4: false,
  });

  const handleCheckboxChange = (e) => {
    const { name, checked } = e.target;
    setCheckboxes((prev) => ({ ...prev, [name]: checked }));
  };

  const handleFileChange = (e) => {
    setDocument(e.target.files[0]);
  };

  const isFormValid = () =>
    document &&
    Object.values(checkboxes).every((value) => value === true);

  const handleSubmit = () => {
    if (!isFormValid()) {
      alert("Please upload the document and agree to all declarations.");
      return;
    }

    alert("Form submitted successfully!");
  };

  return (
    <motion.div className="p-6"
         variants={boxVariants}
        initial="hidden"
        animate="visible"
        transition={{ duration: 0.5 }}>
      <h3 className="text-yellow-800 border-b-2 border-yellow-900 flex justify-center mb-8 text-2xl font-semibold">Declaration</h3>

      <div className="mb-6">
        <LabelRequired label="Upload Declaration Document" />
        <div className="flex items-center gap-3 border border-yellow-100 bg-yellow-50 p-3 rounded cursor-pointer">
          <FiUpload className="text-xl text-yellow-600" />
          <input
            type="file"
            accept="image/*,.pdf"
            onChange={handleFileChange}
            className="w-full text-sm text-yellow-800 bg-transparent focus:outline-none"
          />
        </div>
        {document && (
          <p className="mt-2 text-sm text-yellow-700">Selected: {document.name}</p>
        )}
      </div>

      <div className="space-y-4 text-sm text-yellow-800">
        {[
          {
            name: "statement1",
            text: `I declare that all the information given by me in this application and documents attached hereto are true to the best of my knowledge and that I have not willfully suppressed any material fact.`,
          },
          {
            name: "statement2",
            text: `I accept that if any of the information given by me in this application is in any way false or incorrect, my application may be rejected, any offer of the grant may be withdrawn or my candidature may be rejected at any time during the scheme period.`,
          },
          {
            name: "statement3",
            text: `I agree that 'Terms and Conditions' and guidelines may be modified by the concerned authorities.`,
          },
          {
            name: "statement4",
            text: `I will provide the other necessary information related to the project to the TEC/ Implementing Agency as or when required by them on a timely basis.`,
          },
        ].map(({ name, text }) => (
          <label key={name} className="flex items-start gap-2">
            <input
              type="checkbox"
              name={name}
              checked={checkboxes[name]}
              onChange={handleCheckboxChange}
              className="mt-1"
            />
            <span>{text}</span>
          </label>
        ))}

        </div>
      </motion.div>
  );
};

export default Declaration;
