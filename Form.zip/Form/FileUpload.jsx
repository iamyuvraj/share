import React from "react";
import { FiUploadCloud, FiFileText } from "react-icons/fi";
import { motion } from "framer-motion";

// Utility function to construct file URLs
const constructFileUrl = (filePath) => {
  if (!filePath) return null;
  
  const getApiBaseUrl = () => {
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      return 'http://localhost:8000';
    }
    return window.location.origin;
  };
  
  const API_BASE_URL = getApiBaseUrl();
  
  // Handle different path formats
  if (filePath.startsWith('http://') || filePath.startsWith('https://')) {
    return filePath; // Already a full URL
  }
  
  if (filePath.startsWith('/')) {
    return `${API_BASE_URL}${filePath}`;
  }
  
  return `${API_BASE_URL}/${filePath}`;
};

const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

// File upload component with preview for images
const FileUpload = ({
  label,
  required = false,
  accept,
  height = "h-32",
  name,
  onFileChange,
  preview,
  file,
}) => {
  
  // Function to get the preview URL
  const getPreviewUrl = () => {
    if (!preview) return null;
    
    // Handle different preview formats
    if (typeof preview === 'string') {
      return constructFileUrl(preview);
    }
    
    if (preview && preview.url) {
      return constructFileUrl(preview.url);
    }
    
    return preview; // Fallback for blob URLs from new uploads
  };

  const previewUrl = getPreviewUrl();
  // Check if this is an image file based on accept attribute
  const isImageFile = accept && (accept.includes("image/") || accept.includes(".jpg") || accept.includes(".jpeg") || accept.includes(".png"));
  
  // Check if we have an existing image file (from API) or a new uploaded image
  const hasImagePreview = previewUrl && isImageFile;
  const hasFilePreview = previewUrl && !isImageFile;

  return (
    <motion.div
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      <label className="block text-sm font-medium mb-1 text-yellow-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      <div
        className={`relative w-full border-2 border-dashed border-yellow-500 rounded px-3 py-6 cursor-pointer text-yellow-700 text-sm bg-yellow-50 ${height}`}
      >
        <input
          type="file"
          required={required}
          accept={accept}
          onChange={(e) => onFileChange(name, e.target.files[0])}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
        
        {/* Show preview for images */}
        {hasImagePreview ? (
          <img
            src={previewUrl}
            alt="Preview"
            className="absolute top-1 left-1/3 right-1/3 bottom-1 object-contain rounded max-w-full max-h-[90%]"
            onError={(e) => {
              console.error('Image failed to load:', previewUrl);
              e.target.style.display = 'none';
              // Show fallback content
              const fallback = e.target.nextElementSibling;
              if (fallback) fallback.style.display = 'flex';
            }}
          />
        ) : 
        /* Show file name for newly uploaded non-image files */
        (file && !hasImagePreview) ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center bg-white/90 rounded border border-yellow-400 p-4 shadow">
            <FiFileText className="text-3xl text-yellow-700 mb-2" />
            <p className="text-yellow-800 text-sm font-medium mb-1 truncate w-full">
              {file.name}
            </p>
            <a
              href={URL.createObjectURL(file)}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 text-xs underline"
            >
              View file
            </a>
          </div>
        ) :
        /* Show file info for existing non-image files from API */
        (hasFilePreview) ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center bg-white/90 rounded border border-yellow-400 p-4 shadow">
            <FiFileText className="text-3xl text-yellow-700 mb-2" />
            <p className="text-yellow-800 text-sm font-medium mb-1">
              Uploaded Document
            </p>
            <a
              href={previewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 text-xs underline"
            >
              View file
            </a>
          </div>
        ) :
        /* Default upload area */
        (
          <div className="flex flex-col items-center justify-center text-yellow-700 select-none pointer-events-none h-full">
            <FiUploadCloud className="text-4xl mb-2" />
            <span>
              Click or drag{" "}
              {isImageFile ? "image" : "file"} to upload
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default FileUpload;