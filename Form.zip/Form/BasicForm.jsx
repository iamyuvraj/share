import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";

// Import the updated FileUpload component (make sure the path is correct)
import FileUpload from "./FileUpload"; // Adjust the path as needed

// Label with required asterisk
const LabelRequired = ({ label }) => (
  <label className="block text-sm font-medium mb-1 text-yellow-800">
    {label} <span className="text-red-600">*</span>
  </label>
);

// Reusable input component with optional label
const Input = ({
  label,
  placeholder,
  type = "text",
  required = false,
  name,
  value,
  onChange,
  maxLength,
}) => (
  <div>
    {label && (
      <label className="block text-sm font-medium mb-1 text-yellow-800">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
    )}
    <input
      type={type}
      placeholder={placeholder}
      required={required}
      name={name}
      value={value || ""}
      onChange={onChange}
      maxLength={maxLength}
      className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
    />
  </div>
);

const boxVariants = {
  hidden: { opacity: 0, x: -100 },
  visible: { opacity: 1, x: 0 },
};

const BasicForm = ({ initialFormData = {}, onFormDataChange }) => {
  const [formData, setFormData] = useState({
    applicantPhoto: null,
    applicantPhotoPreview: null,
    applicantName: "",
    gender: "",
    qualification: "",
    resume: null,
    resumePreview: null,
    mobile: "",
    email: "",
    individualPanAttachment: null,
    individualPanAttachmentPreview: null,
    companyAsPerCfp: "",
    individualPAN: "",
    organization: "",
    landline: "",
    website: "",
    proposalBy: "",
    panFile: null,
    panFilePreview: null,
    registrationCertificate: null,
    registrationCertificatePreview: null,
    ttdfCompany: "",
    shareHoldingPattern: null,
    shareHoldingPatternPreview: null,
    dsirCertificate: null,
    dsirCertificatePreview: null,
    addressLine1: "",
    addressLine2: "",
    streetVillage: "",
    city: "",
    country: "",
    state: "",
    pincode: "",
    ...initialFormData,
  });

  useEffect(() => {
    // Initialize form data with any provided initial values
    setFormData((prev) => ({
      ...prev,
      ...initialFormData,
    }));
  }, [initialFormData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let updatedValue = value;

    // PAN validation: allow only uppercase letters and digits, max 10 characters
    if (name === "individualPAN") {
      updatedValue = value
        .toUpperCase()
        .replace(/[^A-Z0-9]/g, "")
        .slice(0, 10);
    }

    // Enforce digit-only and length limits for specific fields
    else if (
      ["mobile", "companyMobile", "landline", "pincode"].includes(name)
    ) {
      const maxLengths = {
        mobile: 10,
        companyMobile: 10,
        landline: 12,
        pincode: 6,
      };
      const maxLength = maxLengths[name];
      updatedValue = value.replace(/\D/g, "").slice(0, maxLength);
    }

    const updatedFormData = {
      ...formData,
      [name]: updatedValue,
    };

    setFormData(updatedFormData);
    onFormDataChange(updatedFormData);
  };

  const handleFileChange = (name, file) => {
    // Clean up previous preview URL if it exists
    if (formData[`${name}Preview`] && typeof formData[`${name}Preview`] === 'string' && formData[`${name}Preview`].startsWith('blob:')) {
      URL.revokeObjectURL(formData[`${name}Preview`]);
    }

    const preview =
      file && file.type.startsWith("image/") ? URL.createObjectURL(file) : null;

    const updatedFormData = {
      ...formData,
      [name]: file, // Store the actual File object
      [`${name}Preview`]: preview,
    };

    setFormData(updatedFormData);
    onFormDataChange(updatedFormData);
  };

  return (
    <motion.div
      className="flex justify-center"
      variants={boxVariants}
      initial="hidden"
      animate="visible"
      transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-6xl bg-white rounded p-8">
        <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
          <h2 className="text-2xl font-semibold text-yellow-800 mb-6 border-b-2 border-yellow-800 pb-2 text-center">
            Basic Information
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-4">
              <FileUpload
                label="Applicant Photo"
                required
                accept="image/jpeg,image/jpg,.jpg,.jpeg"
                name="applicantPhoto"
                onFileChange={handleFileChange}
                preview={formData.applicantPhotoPreview}
                file={formData.applicantPhoto}
              />
              <Input
                label="Applicant Name"
                placeholder="Enter Full Name"
                required
                type="text"
                name="applicantName"
                value={formData.applicantName}
                onChange={handleChange}
              />
              <div>
                <LabelRequired label="Gender" />
                <div className="flex space-x-4 text-yellow-800">
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="Male"
                      checked={formData.gender === "Male"}
                      onChange={handleChange}
                      required
                    />{" "}
                    Male
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="Female"
                      checked={formData.gender === "Female"}
                      onChange={handleChange}
                    />{" "}
                    Female
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="Other"
                      checked={formData.gender === "Other"}
                      onChange={handleChange}
                    />{" "}
                    Other
                  </label>
                </div>
              </div>
              <h3 className="font-semibold text-yellow-800 mt-4">
                Qualification <span className="text-red-600">*</span>
              </h3>
              <Input
                placeholder="Enter Qualification"
                required
                name="qualification"
                value={formData.qualification}
                onChange={handleChange}
              />
              <FileUpload
                label="Resume"
                required
                accept=".pdf"
                name="resume"
                onFileChange={handleFileChange}
                preview={formData.resumePreview}
                file={formData.resume}
              />
              <Input
                label="Mobile No."
                placeholder="+91-XXXXXXXXXX"
                required
                type="text"
                name="mobile"
                maxLength={10}
                value={formData.mobile}
                onChange={handleChange}
              />
              <Input
                label="E-Mail"
                placeholder="your.email@example.com"
                type="email"
                required
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
              <Input
                label="Applicant PAN Number"
                placeholder="Enter your PAN (e.g., ABCDE1234F)"
                required
                type="text"
                name="individualPAN"
                value={formData.individualPAN}
                onChange={handleChange}
              />
              
              <FileUpload
                label="Applicant PAN Attachment"
                accept=".pdf"
                name="individualPanAttachment"
                required
                onFileChange={handleFileChange}
                preview={formData.individualPanAttachmentPreview}
                file={formData.individualPanAttachment}
              />

              <h3 className="font-semibold text-yellow-800 mt-4">
                Address <span className="text-red-600">*</span>
              </h3>
              <Input
                placeholder="Address Line 1"
                required
                name="addressLine1"
                value={formData.addressLine1}
                onChange={handleChange}
              />
              <Input
                placeholder="Address Line 2"
                required
                name="addressLine2"
                value={formData.addressLine2}
                onChange={handleChange}
              />
              <Input
                placeholder="Street/Village"
                required
                name="streetVillage"
                value={formData.streetVillage}
                onChange={handleChange}
              />
              <div className="grid grid-cols-2 gap-4">
                <Input
                  placeholder="City"
                  required
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Country"
                  required
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                />
                <Input
                  placeholder="State"
                  required
                  name="state"
                  value={formData.state}
                  onChange={handleChange}
                />
                <Input
                  placeholder="Pin Code"
                  required
                  type="number"
                  name="pincode"
                  value={formData.pincode}
                  onChange={handleChange}
                />
              </div>
            </div>
            {/* Right Column */}
            <div className="space-y-4">
              <Input
                label="Organization Name"
                placeholder="Enter Organization Name"
                required
                name="organization"
                value={formData.organization}
                onChange={handleChange}
              />

              <Input
                label="Landline No. (with STD Code)"
                placeholder="Enter your Landline Number"
                required
                type="text"
                name="landline"
                value={formData.landline}
                onChange={handleChange}
                maxLength={12}
              />

              <Input
                label="Website"
                placeholder="www.example.com"
                name="website"
                value={formData.website}
                onChange={handleChange}
              />
              <Input
                label="Proposal Submitted By"
                placeholder="Primary Applicant (not consortium partners)"
                required
                name="proposalBy"
                value={formData.proposalBy}
                onChange={handleChange}
              />
              <FileUpload
                label="Company/Organization TAN/PAN/CIN"
                required
                accept=".pdf"
                name="panFile"
                onFileChange={handleFileChange}
                preview={formData.panFilePreview}
                file={formData.panFile}
              />
              <FileUpload
                label="Registration Certificate"
                accept=".pdf"
                name="registrationCertificate"
                required
                onFileChange={handleFileChange}
                preview={formData.registrationCertificatePreview}
                file={formData.registrationCertificate}
              />
              <div>
                <LabelRequired label="Company as per CFP" />
                <select
                  required
                  className="w-full p-2 border border-yellow-500 rounded focus:outline-none focus:ring-2 focus:ring-yellow-600"
                  name="ttdfCompany"
                  value={formData.ttdfCompany}
                  onChange={handleChange}
                >
                  <option value="" disabled>
                    Select
                  </option>
                  <option>
                    Domestic Company with focus on Telecom R&D, Use Case
                    Development
                  </option>
                  <option>Start-ups/MSMEs</option>
                  <option>Academic Institutions</option>
                  <option>
                    R&D Institutions, Section 8 Companies/Societies, Central &
                    State Government Entities/PSUs/Autonomous
                    Bodies/SPVs/Limited Liability Partnerships
                  </option>
                </select>
              </div>
              <FileUpload
                label="CA Certified Shareholding Pattern"
                accept=".pdf"
                name="shareHoldingPattern"
                required
                onFileChange={handleFileChange}
                preview={formData.shareHoldingPatternPreview}
                file={formData.shareHoldingPattern}
              />
              <FileUpload
                label="DSIR Certificate"
                accept=".pdf"
                name="dsirCertificate"
                onFileChange={handleFileChange}
                preview={formData.dsirCertificatePreview}
                file={formData.dsirCertificate}
              />
            </div>
          </div>
        </form>
      </div>
    </motion.div>
  );
};

export default BasicForm;